/*****************************************
	SERVER에 위치 하면서 엘도라도 KT향
	레벨링을 조정하는 파일
	2016.02.04 제작 ywlee@busidol.com
******************************************/


/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// STAGE DESIGN
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

// var MAX_STAGE_NUM = 220;		//게임에서 사용하는 맵의 번호, 현재 100가지 임.
//20210222_yhlee 240스테이지 추가
var MAX_STAGE_NUM = 260;		//게임에서 사용하는 맵의 번호

//20191119_yhlee 하드모드 추가
// var MAX_STAGE_NUM_HARD = 100;	//게임에서 사용하는 맵의 번호, 현재 100가지 임.
var MAX_STAGE_NUM_HARD = 200;	//게임에서 사용하는 맵의 번호
var CUR_HARD_STAGE_NUM = -1;//현재 도전중이 하드모드 스테이지 번호
var HARD_MODE_JEWEL = "";//하드모드에서 획득한 보석 정보
// var HARD_MODE_UP_NUM = 6;//노말모드에 비례하여 증가하는 수치 값  HP,AP만 증가합니다.  x6
//20200406_yhlee 하드모드 난이도 조정
var HARD_MODE_UP_NUM = 4; // 20211119_dblee 하드모드 난이도 조정 5 > 4
var HARD_MODE_JEWEL_GET_PROBABILITY = ["",//하드모드에서 20스테이지 마다 보석 획득 확률
	50,//20스테이지에서 보석 획득확률
	45,//40스테이지에서 보석 획득확률
	40,//60스테이지에서 보석 획득확률
	35,//80스테이지에서 보석 획득확률
	30,//100스테이지에서 보석 획득확률
	25,//120스테이지에서 보석 획득확률
	20,//140스테이지에서 보석 획득확률
	15,//160스테이지에서 보석 획득확률
	10,//180스테이지에서 보석 획득확률
	10  //200스테이지에서 보석 획득확률     20200424_yhlee  5->10 로 상향
];


var STAGE_DESIGN =
	[
		{},//연산편의를 위해 0번 배열은 사용하지 않음.
		//스테이지	//가장낮은레벨	//가장높은레벨	//마지막
		{ num: 1, char_start: 1, char_end: 1, char_last: 1, },
		{ num: 2, char_start: 1, char_end: 1, char_last: 1, },
		{ num: 3, char_start: 1, char_end: 2, char_last: 2, },
		{ num: 4, char_start: 1, char_end: 3, char_last: 3, },
		{ num: 5, char_start: 1, char_end: 3, char_last: 3, },
		{ num: 6, char_start: 2, char_end: 4, char_last: 4, },
		{ num: 7, char_start: 3, char_end: 4, char_last: 4, },
		{ num: 8, char_start: 2, char_end: 5, char_last: 5, },
		{ num: 9, char_start: 3, char_end: 5, char_last: 5, },
		{ num: 10, char_start: 4, char_end: 5, char_last: 5, },

		{ num: 11, char_start: 2, char_end: 6, char_last: 5, },
		{ num: 12, char_start: 3, char_end: 6, char_last: 5, },
		{ num: 13, char_start: 3, char_end: 6, char_last: 6, },
		{ num: 14, char_start: 4, char_end: 6, char_last: 6, },
		{ num: 15, char_start: 5, char_end: 6, char_last: 6, },
		{ num: 16, char_start: 3, char_end: 7, char_last: 7, },
		{ num: 17, char_start: 3, char_end: 7, char_last: 7, },
		{ num: 18, char_start: 4, char_end: 7, char_last: 7, },
		{ num: 19, char_start: 5, char_end: 8, char_last: 8, },
		{ num: 20, char_start: 6, char_end: 8, char_last: 8, },

		{ num: 21, char_start: 8, char_end: 9, char_last: 9, },
		{ num: 22, char_start: 8, char_end: 9, char_last: 9, },
		{ num: 23, char_start: 7, char_end: 9, char_last: 9, },
		{ num: 24, char_start: 7, char_end: 9, char_last: 9, },
		{ num: 25, char_start: 8, char_end: 9, char_last: 9, },
		{ num: 26, char_start: 8, char_end: 10, char_last: 10, },
		{ num: 27, char_start: 8, char_end: 10, char_last: 10, },
		{ num: 28, char_start: 8, char_end: 10, char_last: 10, },
		{ num: 29, char_start: 9, char_end: 10, char_last: 10, },
		{ num: 30, char_start: 9, char_end: 10, char_last: 10, },

		{ num: 31, char_start: 8, char_end: 11, char_last: 11, },
		{ num: 32, char_start: 8, char_end: 11, char_last: 11, },
		{ num: 33, char_start: 9, char_end: 11, char_last: 11, },
		{ num: 34, char_start: 9, char_end: 11, char_last: 11, },
		{ num: 35, char_start: 10, char_end: 11, char_last: 11, },
		{ num: 36, char_start: 9, char_end: 12, char_last: 12, },
		{ num: 37, char_start: 9, char_end: 12, char_last: 12, },
		{ num: 38, char_start: 10, char_end: 12, char_last: 12, },
		{ num: 39, char_start: 10, char_end: 12, char_last: 12, },
		{ num: 40, char_start: 11, char_end: 12, char_last: 12, },

		{ num: 41, char_start: 10, char_end: 13, char_last: 13, },
		{ num: 42, char_start: 10, char_end: 13, char_last: 13, },
		{ num: 43, char_start: 11, char_end: 13, char_last: 13, },
		{ num: 44, char_start: 11, char_end: 13, char_last: 13, },
		{ num: 45, char_start: 11, char_end: 14, char_last: 14, },
		{ num: 46, char_start: 11, char_end: 14, char_last: 14, },
		{ num: 47, char_start: 12, char_end: 14, char_last: 14, },
		{ num: 48, char_start: 12, char_end: 14, char_last: 14, },
		{ num: 49, char_start: 13, char_end: 15, char_last: 15, },
		{ num: 50, char_start: 13, char_end: 15, char_last: 15, },

		{ num: 51, char_start: 14, char_end: 15, char_last: 15, },
		{ num: 52, char_start: 14, char_end: 15, char_last: 15, },
		{ num: 53, char_start: 13, char_end: 16, char_last: 16, },
		{ num: 54, char_start: 13, char_end: 16, char_last: 16, },
		{ num: 55, char_start: 14, char_end: 16, char_last: 16, },
		{ num: 56, char_start: 15, char_end: 16, char_last: 16, },
		{ num: 57, char_start: 13, char_end: 17, char_last: 17, },
		{ num: 58, char_start: 14, char_end: 17, char_last: 17, },
		{ num: 59, char_start: 15, char_end: 17, char_last: 17, },
		{ num: 60, char_start: 16, char_end: 17, char_last: 17, },

		{ num: 61, char_start: 15, char_end: 18, char_last: 18, },
		{ num: 62, char_start: 15, char_end: 18, char_last: 18, },
		{ num: 63, char_start: 16, char_end: 18, char_last: 18, },
		{ num: 64, char_start: 16, char_end: 18, char_last: 18, },
		{ num: 65, char_start: 16, char_end: 19, char_last: 19, },
		{ num: 66, char_start: 17, char_end: 19, char_last: 19, },
		{ num: 67, char_start: 17, char_end: 19, char_last: 19, },
		{ num: 68, char_start: 17, char_end: 20, char_last: 20, },
		{ num: 69, char_start: 18, char_end: 20, char_last: 20, },
		{ num: 70, char_start: 18, char_end: 20, char_last: 20, },

		{ num: 71, char_start: 19, char_end: 20, char_last: 20, },
		{ num: 72, char_start: 18, char_end: 21, char_last: 21, },
		{ num: 73, char_start: 19, char_end: 21, char_last: 21, },
		{ num: 74, char_start: 20, char_end: 21, char_last: 21, },
		{ num: 75, char_start: 19, char_end: 22, char_last: 22, },
		{ num: 76, char_start: 20, char_end: 22, char_last: 22, },
		{ num: 77, char_start: 21, char_end: 22, char_last: 22, },
		{ num: 78, char_start: 20, char_end: 23, char_last: 23, },
		{ num: 79, char_start: 21, char_end: 23, char_last: 23, },
		{ num: 80, char_start: 22, char_end: 23, char_last: 23, },

		{ num: 81, char_start: 22, char_end: 24, char_last: 24, },
		{ num: 82, char_start: 22, char_end: 24, char_last: 24, },
		{ num: 83, char_start: 23, char_end: 25, char_last: 25, },
		{ num: 84, char_start: 24, char_end: 25, char_last: 24, },
		{ num: 85, char_start: 24, char_end: 25, char_last: 25, },
		{ num: 86, char_start: 24, char_end: 26, char_last: 26, },
		{ num: 87, char_start: 25, char_end: 26, char_last: 25, },
		{ num: 88, char_start: 25, char_end: 26, char_last: 26, },
		{ num: 89, char_start: 25, char_end: 27, char_last: 27, },
		{ num: 90, char_start: 26, char_end: 27, char_last: 27, },

		{ num: 91, char_start: 25, char_end: 27, char_last: 27, },
		{ num: 92, char_start: 26, char_end: 28, char_last: 28, },
		{ num: 93, char_start: 26, char_end: 28, char_last: 28, },
		{ num: 94, char_start: 27, char_end: 28, char_last: 28, },
		{ num: 95, char_start: 27, char_end: 29, char_last: 29, },
		{ num: 96, char_start: 26, char_end: 29, char_last: 29, },
		{ num: 97, char_start: 26, char_end: 29, char_last: 29, },
		{ num: 98, char_start: 27, char_end: 30, char_last: 30, },
		{ num: 99, char_start: 28, char_end: 30, char_last: 29, },
		{ num: 100, char_start: 29, char_end: 30, char_last: 30, },

		//101~200 stage 추가 ywlee_20160709
		{ num: 101, char_start: 31, char_end: 31, char_last: 31, },
		{ num: 102, char_start: 31, char_end: 31, char_last: 31, },
		{ num: 103, char_start: 31, char_end: 32, char_last: 32, },
		{ num: 104, char_start: 31, char_end: 33, char_last: 33, },
		{ num: 105, char_start: 31, char_end: 33, char_last: 33, },
		{ num: 106, char_start: 32, char_end: 34, char_last: 34, },
		{ num: 107, char_start: 33, char_end: 34, char_last: 34, },
		{ num: 108, char_start: 32, char_end: 35, char_last: 35, },
		{ num: 109, char_start: 33, char_end: 35, char_last: 35, },
		{ num: 110, char_start: 35, char_end: 35, char_last: 35, }, //KT에서 110 stage는 고슴도치 3 만 나오게

		{ num: 111, char_start: 32, char_end: 36, char_last: 35, },
		{ num: 112, char_start: 33, char_end: 36, char_last: 35, },
		{ num: 113, char_start: 33, char_end: 36, char_last: 36, },
		{ num: 114, char_start: 34, char_end: 36, char_last: 36, },
		{ num: 115, char_start: 35, char_end: 36, char_last: 36, },
		{ num: 116, char_start: 33, char_end: 37, char_last: 37, },
		{ num: 117, char_start: 33, char_end: 37, char_last: 37, },
		{ num: 118, char_start: 34, char_end: 37, char_last: 37, },
		{ num: 119, char_start: 35, char_end: 38, char_last: 38, },
		{ num: 120, char_start: 36, char_end: 38, char_last: 36, }, //KT에서 120 stage는 설인(36)만 나오게 해서 힘들게 만들기 //--> 140open이후, 36~38로 변경함 (20180220)

		{ num: 121, char_start: 38, char_end: 39, char_last: 39, },
		{ num: 122, char_start: 38, char_end: 39, char_last: 39, },
		{ num: 123, char_start: 37, char_end: 39, char_last: 39, },
		{ num: 124, char_start: 37, char_end: 39, char_last: 39, },
		{ num: 125, char_start: 36, char_end: 39, char_last: 39, },
		{ num: 126, char_start: 38, char_end: 40, char_last: 40, },
		{ num: 127, char_start: 38, char_end: 40, char_last: 40, },
		{ num: 128, char_start: 38, char_end: 40, char_last: 40, },
		{ num: 129, char_start: 39, char_end: 40, char_last: 40, },
		{ num: 130, char_start: 40, char_end: 40, char_last: 40, },

		{ num: 131, char_start: 38, char_end: 41, char_last: 41, },
		{ num: 132, char_start: 38, char_end: 41, char_last: 41, },
		{ num: 133, char_start: 39, char_end: 41, char_last: 41, },
		{ num: 134, char_start: 39, char_end: 41, char_last: 41, },
		{ num: 135, char_start: 40, char_end: 41, char_last: 41, },
		{ num: 136, char_start: 39, char_end: 42, char_last: 42, },
		{ num: 137, char_start: 39, char_end: 42, char_last: 42, },
		{ num: 138, char_start: 41, char_end: 42, char_last: 41, }, //20220901_twkim... 131스테이지에 나온 신규몹 알림이 다시 138에서 뜸, char_end:41 로 되어있던것 수정
		{ num: 139, char_start: 41, char_end: 42, char_last: 42, },
		{ num: 140, char_start: 42, char_end: 42, char_last: 42, },

		{ num: 141, char_start: 43, char_end: 43, char_last: 43, },
		{ num: 142, char_start: 40, char_end: 43, char_last: 43, },
		{ num: 143, char_start: 41, char_end: 43, char_last: 43, },
		{ num: 144, char_start: 41, char_end: 43, char_last: 43, },
		{ num: 145, char_start: 43, char_end: 44, char_last: 44, },
		{ num: 146, char_start: 43, char_end: 44, char_last: 44, },
		{ num: 147, char_start: 43, char_end: 44, char_last: 44, },
		{ num: 148, char_start: 44, char_end: 44, char_last: 44, },
		{ num: 149, char_start: 43, char_end: 45, char_last: 45, },
		{ num: 150, char_start: 44, char_end: 45, char_last: 45, },

		{ num: 151, char_start: 44, char_end: 45, char_last: 45, },
		{ num: 152, char_start: 45, char_end: 45, char_last: 45, },
		{ num: 153, char_start: 43, char_end: 46, char_last: 46, },
		{ num: 154, char_start: 43, char_end: 46, char_last: 46, },
		{ num: 155, char_start: 44, char_end: 46, char_last: 46, },
		{ num: 156, char_start: 45, char_end: 46, char_last: 46, },
		{ num: 157, char_start: 43, char_end: 47, char_last: 47, },
		// {	num:158		,char_start:44	,char_end:47	,char_last:47, },
		{ num: 158, char_start: 46, char_end: 47, char_last: 46, }, //20220901_twkim... 157스테이지에 나온 신규몹 알림이 다시 159에서 뜸, char_end:46 로 되어있던것 수정
		{ num: 159, char_start: 45, char_end: 47, char_last: 47, },
		{ num: 160, char_start: 46, char_end: 47, char_last: 47, },

		{ num: 161, char_start: 45, char_end: 48, char_last: 48, },
		{ num: 162, char_start: 46, char_end: 48, char_last: 48, },
		{ num: 163, char_start: 47, char_end: 47, char_last: 47, },
		{ num: 164, char_start: 47, char_end: 48, char_last: 48, },
		{ num: 165, char_start: 48, char_end: 48, char_last: 48, }, //트롤만 등장

		{ num: 166, char_start: 47, char_end: 49, char_last: 49, },
		{ num: 167, char_start: 48, char_end: 49, char_last: 49, },
		{ num: 168, char_start: 49, char_end: 49, char_last: 49, }, //해골만 등장
		{ num: 169, char_start: 48, char_end: 50, char_last: 50, },
		{ num: 170, char_start: 49, char_end: 50, char_last: 50, },

		{ num: 171, char_start: 47, char_end: 50, char_last: 50, },
		{ num: 172, char_start: 48, char_end: 50, char_last: 50, },
		{ num: 173, char_start: 49, char_end: 50, char_last: 50, },
		{ num: 174, char_start: 50, char_end: 51, char_last: 51, },
		{ num: 175, char_start: 51, char_end: 51, char_last: 51, }, //해골2만 등장

		{ num: 176, char_start: 50, char_end: 52, char_last: 52, },
		{ num: 177, char_start: 51, char_end: 52, char_last: 52, },
		{ num: 178, char_start: 50, char_end: 53, char_last: 53, },
		{ num: 179, char_start: 51, char_end: 53, char_last: 53, },
		{ num: 180, char_start: 52, char_end: 53, char_last: 53, }, //해골 좀비 두개만 등장

		{ num: 181, char_start: 52, char_end: 54, char_last: 54, }, //좀비 3등장
		{ num: 182, char_start: 52, char_end: 54, char_last: 54, },
		{ num: 183, char_start: 53, char_end: 55, char_last: 55, }, //인어1 등장
		{ num: 184, char_start: 54, char_end: 55, char_last: 54, },
		{ num: 185, char_start: 54, char_end: 55, char_last: 55, },

		{ num: 186, char_start: 54, char_end: 56, char_last: 56, }, //문어1 등장
		{ num: 187, char_start: 55, char_end: 56, char_last: 55, },
		{ num: 188, char_start: 55, char_end: 56, char_last: 56, },
		{ num: 189, char_start: 55, char_end: 57, char_last: 57, }, //인어2 등장
		{ num: 190, char_start: 56, char_end: 57, char_last: 57, },

		{ num: 191, char_start: 55, char_end: 57, char_last: 57, },
		{ num: 192, char_start: 56, char_end: 58, char_last: 58, }, //문어2 등장
		{ num: 193, char_start: 56, char_end: 58, char_last: 58, },
		{ num: 194, char_start: 57, char_end: 58, char_last: 58, },
		{ num: 195, char_start: 57, char_end: 59, char_last: 59, }, //인어3 등장

		{ num: 196, char_start: 56, char_end: 59, char_last: 59, },
		{ num: 197, char_start: 57, char_end: 59, char_last: 59, },
		{ num: 198, char_start: 58, char_end: 60, char_last: 60, }, //문어3 등장
		{ num: 199, char_start: 59, char_end: 60, char_last: 60, },
		{ num: 200, char_start: 60, char_end: 60, char_last: 60, }, //문어3만 나옴

		//20200424_yhlee 201스테이지 추가
		{ num: 201, char_start: 61, char_end: 61, char_last: 61, }, // 스컬독 1 등장
		{ num: 202, char_start: 61, char_end: 62, char_last: 62, }, // 시크릿 1 등장
		{ num: 203, char_start: 61, char_end: 63, char_last: 63, }, // 스컬독 2 등장
		{ num: 204, char_start: 62, char_end: 63, char_last: 63, },
		{ num: 205, char_start: 67, char_end: 67, char_last: 67, }, // 보스 1 등장

		{ num: 206, char_start: 62, char_end: 63, char_last: 63, },
		{ num: 207, char_start: 62, char_end: 63, char_last: 63, },
		{ num: 208, char_start: 62, char_end: 64, char_last: 64, },  // 시크릿 2 등장
		{ num: 209, char_start: 64, char_end: 64, char_last: 64, },
		{ num: 210, char_start: 68, char_end: 68, char_last: 68, }, // 보스 2 등장

		{ num: 211, char_start: 63, char_end: 64, char_last: 64, },
		{ num: 212, char_start: 63, char_end: 64, char_last: 64, },
		{ num: 213, char_start: 63, char_end: 65, char_last: 65, }, // 스컬독 3 등장
		{ num: 214, char_start: 66, char_end: 66, char_last: 66, }, // 시크릿 3 등장
		{ num: 215, char_start: 69, char_end: 69, char_last: 69, }, // 보스 3 등장

		{ num: 216, char_start: 64, char_end: 65, char_last: 65, },
		{ num: 217, char_start: 65, char_end: 66, char_last: 66, },
		{ num: 218, char_start: 65, char_end: 66, char_last: 66, },
		{ num: 219, char_start: 66, char_end: 66, char_last: 66, },
		{ num: 220, char_start: 70, char_end: 70, char_last: 70, }, // 보스 4 등장

		//20210222_yhlee 240스테이지 추가
		{ num: 221, char_start: 71, char_end: 71, char_last: 71, },//젤리1 등장
		{ num: 222, char_start: 71, char_end: 71, char_last: 71, },
		{ num: 223, char_start: 71, char_end: 72, char_last: 72, },//프로그1 등장
		{ num: 224, char_start: 71, char_end: 72, char_last: 72, },
		{ num: 225, char_start: 71, char_end: 73, char_last: 73, },//젤리2 등장

		{ num: 226, char_start: 72, char_end: 73, char_last: 73, },
		{ num: 227, char_start: 72, char_end: 73, char_last: 73, },
		{ num: 228, char_start: 72, char_end: 74, char_last: 74, },//프로그2 등장
		{ num: 229, char_start: 73, char_end: 74, char_last: 74, },
		{ num: 230, char_start: 73, char_end: 74, char_last: 74, },

		{ num: 231, char_start: 73, char_end: 75, char_last: 75, },//젤리3 등장
		{ num: 232, char_start: 74, char_end: 75, char_last: 75, },
		{ num: 233, char_start: 74, char_end: 75, char_last: 75, },
		{ num: 234, char_start: 74, char_end: 76, char_last: 76, },//프로그3 등장
		{ num: 235, char_start: 75, char_end: 76, char_last: 76, },

		{ num: 236, char_start: 75, char_end: 76, char_last: 76, },
		{ num: 237, char_start: 74, char_end: 76, char_last: 76, },
		{ num: 238, char_start: 74, char_end: 76, char_last: 76, },
		{ num: 239, char_start: 75, char_end: 76, char_last: 76, },
		{ num: 240, char_start: 76, char_end: 76, char_last: 76, },

		{ num: 241, char_start: 81, char_end: 81, char_last: 81, },
		{ num: 242, char_start: 81, char_end: 81, char_last: 81, },
		{ num: 243, char_start: 82, char_end: 82, char_last: 82, },
		{ num: 244, char_start: 81, char_end: 82, char_last: 82, },
		{ num: 245, char_start: 87, char_end: 87, char_last: 87, },

		{ num: 246, char_start: 83, char_end: 83, char_last: 83, },
		{ num: 247, char_start: 81, char_end: 82, char_last: 82, },
		{ num: 248, char_start: 83, char_end: 83, char_last: 83, },
		{ num: 249, char_start: 82, char_end: 83, char_last: 83, },
		{ num: 250, char_start: 88, char_end: 88, char_last: 88, },

		{ num: 251, char_start: 84, char_end: 84, char_last: 84, },
		{ num: 252, char_start: 83, char_end: 84, char_last: 84, },
		{ num: 253, char_start: 85, char_end: 85, char_last: 85, },
		{ num: 254, char_start: 84, char_end: 85, char_last: 85, },
		{ num: 255, char_start: 89, char_end: 89, char_last: 89, },

		{ num: 256, char_start: 86, char_end: 86, char_last: 86, },
		{ num: 257, char_start: 84, char_end: 85, char_last: 85, },
		{ num: 258, char_start: 85, char_end: 85, char_last: 85, },
		{ num: 259, char_start: 85, char_end: 86, char_last: 86, },
		{ num: 260, char_start: 90, char_end: 90, char_last: 90, },

		{ num: 261, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 262, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 263, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 264, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 265, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 266, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 267, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 268, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 269, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 270, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 271, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 272, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 273, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 274, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 275, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 276, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 277, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 278, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 279, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 280, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 281, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 282, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 283, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 284, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 285, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 286, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 287, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 288, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 289, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 290, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 291, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 292, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 293, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 294, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 295, char_start: 60, char_end: 60, char_last: 60, },

		{ num: 296, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 297, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 298, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 299, char_start: 60, char_end: 60, char_last: 60, },
		{ num: 300, char_start: 60, char_end: 60, char_last: 60, },
	];

// Ranking mode에서의 WAVE디자인
var RANKING_STAGE_DESIGN =
{
	wave: 1,									// WAVE 1
	char_num: 8,							// 이번 레벨에 나타날 캐릭터 숫자				// 특징
	char_start: 1,							// 등장할 가장 낮은 레벨
	char_end: 4,								// 등장할 가장 높은 레벨
	char_last: 4,							// 가장 마지막에 나올 last 캐릭 0이면 없다.
	char_interval: 200,						// 캐릭터 나오는 시간
	len_from_our_to_your: 1240,				// 아군성과 적군성의 거리 pixel 나타내기
	bg_filename: "map2_bg2.png",			// 게임 백그라운드 파일
	bg_filename_w: 960,						// 백그라운드 이미지의 width 값. 이 값은 바로위의 len_from_our_to_your 보다 항상 커야 말이 됨.
	bg_filename_h: 1095,					// 백그라운드 이미지의 높이값

	castle_our_filename: "allyHome01",		// 아군 성의 file이름 접두어	==> wave_design함수에서 재정의
	castle_our_w: 192,						// 아군 성의 넓이				==> wave_design함수에서 재정의
	castle_our_h: 203,						// 아군 성의 높이				==> wave_design함수에서 재정의
	castle_our_frame_num_attack: 4,			// 미사일 발사시 성의 frame수
	castle_our_frame_num_beattack: 2,		// 공격당할때의 frame수
	castle_our_frame_num_wait: 1,			// 대기의 frame 수
	castle_our_frame_num_destroy: 1,		// 파괴 되었을 경우의 frame수.

	castle_your_filename: "enemyHome01",	// 아군 성의 file이름 접두어
	castle_your_x: 700,						// 성의 위치
	castle_your_y: 250,						// 성의 위치
	castle_your_w: 203,						// 성의 가로 크기
	castle_your_h: 208,						// 성의 세로 크기
	castle_your_frame_num_beattack: 2,		// 공격당할때의 frame수
	castle_your_frame_num_wait: 1,			// 대기의 frame 수
	castle_your_frame_num_destroy: 1,		// 파괴 되었을 경우의 frame수.
	nose_x: 134,							// 성의 레이저 쏠 위치 x 좌표.
	nose_y: 105,							// 성의 레이저 쏠 위치 y 좌표.
	castle_your_max_hp: 10000000
}

var STAGE =
{
	enemy_socket: new Array(),					//적군의 소켓 개념임

	set_enemy_socket: function () {

	},

	char_num:  //각 스테이지별 나타날 캐릭터 숫자 // last num이 있어서 +1됨, 그리고 특정시간 지나면 wave 2 나감.
		/*  1 ~ 20 */[-1, 1, 5, 6, 8, 8, 9, 8, 10, 10, 11, 12, 13, 14, 15, 16, 17, 18, 18, 17, 18
		/* 21 ~ 40 */, 7, 8, 9, 10, 11, 12, 13, 13, 14, 14, 12, 12, 13, 13, 12, 14, 15, 15, 15, 18
		/* 41 ~ 60 */, 12, 10, 11, 10, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 16, 18, 18, 19, 20
		/* 61 ~ 80 */, 10, 9, 11, 11, 12, 12, 13, 13, 14, 13, 15, 15, 16, 16, 17, 17, 17, 18, 19, 20
		/* 81 ~ 100*/, 10, 10, 11, 11, 11, 12, 13, 12, 14, 14, 15, 15, 16, 16, 17, 20, 20, 20, 23, 25

		/* 101 ~120*/, 1, 5, 6, 8, 8, 9, 8, 10, 10, 11, 12, 13, 14, 15, 16, 17, 18, 18, 18, 19
		/* 121 ~140*/, 7, 8, 9, 10, 11, 12, 13, 13, 14, 14, 11, 12, 13, 13, 12, 14, 15, 15, 15, 18

		///* 141 ~160*/		,12	,10	,11	,11	,12	,12	,13	,13	,14	,14	,15	,15	,16	,16	,17	,17	,18	,18	,19	,20
		/* 141 ~160*/, 5, 9, 11, 11, 11, 12, 13, 12, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18, 19, 20

		///* 161 ~180*/		,10	,10	,11	,11	,12	,12	,13	,13	,14	,14	,15	,15	,16	,16	,17	,17	,18	,18	,19	,20
		/* 161 ~180*/, 10, 6, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18, 19, 20

		/* 181 ~200*/, 15, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 18, 18, 19, 20, 21, 22, 24, 27

		//20200424_yhlee 201스테이지 추가
		/* 201 ~220*/, 14, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 18, 18, 19, 20, 21, 22, 24, 27
		/* 221 ~240*/, 15, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 18, 18, 19, 20, 21, 22, 24, 27
		// 20220707_dblee 거인 출현 스테이지 0 -> 1로 변경함
		/* 241 ~260*/, 27, 27, 32, 27, 1, 27, 27, 27, 27, 1, 32, 27, 27, 27, 1, 32, 27, 27, 27, 1

		/* 261 ~280*/, 15, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 18, 18, 19, 20, 21, 22, 24, 27
		/* 281 ~300*/, 15, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 18, 18, 19, 20, 21, 22, 24, 27
		],

	//20171227_ywlee 난이도 조정을 위해 특정 구간 interval 2배 함.
	char_interval:// 캐릭터 나오는 시간 , 이 값에 곱하기 TIMER_INTERVAL 함.
		/*  1 ~ 20 */[-1, 400, 360, 340, 320, 320, 300, 280, 260, 240, 220, 200, 180, 160, 140, 120, 110, 100, 110, 100, 90
		/* 21 ~ 40 */, 300, 250, 250, 200, 200, 200, 180, 180, 180, 150, 300, 250, 250, 200, 150 * 2, 300, 250, 250, 200, 150 * 2
		/* 41 ~ 60 */, 250, 250, 250, 100, 300, 250, 200, 150 * 2, 300, 250, 200, 150, 300, 200, 150, 100, 300, 200, 150, 100
		/* 61 ~ 80 */, 200, 150, 100, 80, 200, 150, 80, 200, 150, 100, 80, 200, 150, 100 * 2, 200, 150, 100, 200, 120, 50
		/* 81 ~ 100*/, 150, 80, 150, 100 * 2, 80, 150, 100, 70, 200, 150, 70, 200, 100, 70 * 2, 200, 100, 60, 100, 70, 70

		/* 101 ~120*/, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 100, 100, 100, 100 * 2, 100, 100, 100, 100, 100
		/* 121 ~140*/, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80
		/* 141 ~160*/, 100, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70
		/* 161 ~180*/, 60, 70, 60, 60, 55, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 30, 60, 60, 60
		/* 181 ~200*/, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40

		//20200424_yhlee 201스테이지 추가
		/* 201 ~220*/, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40
		/* 221 ~240*/, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40
		/* 241 ~260*/, 40, 40, 40, 40, 60000, 40, 40, 40, 40, 60000, 40, 40, 40, 40, 60000, 40, 40, 40, 40, 60000

		/* 261 ~280*/, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40
		/* 281 ~300*/, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40
		],

	len_from_our_to_your:	// 아군성과 적군성의 거리 pixel 나타내기
		/*  1 ~ 20 */[-1, 1000, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500
		/* 21 ~ 40 */, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500
		/* 41 ~ 60 */, 1200, 1500, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500
		/* 61 ~ 80 */, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500
		/* 81 ~ 100*/, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500, 1200, 1200, 1200, 1200, 1500, 1200, 1200, 800, 1200, 1500

		/* 101 ~120 */, 1600, 1200, 1200, 1800, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1800
		/* 121 ~140 */, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1800
		/* 141 ~160 */, 1600, 1500, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1800

		//20180502_ywlee 180 stage확장하면서 아래 컨셉 조정함. 해골과 좀비는 긴맵에서 공격이 유리함.
		/* 161 ~180 */, 1200, 1500, 1800, 1800, 1600, 1800, 1000, 1800, 1800, 1800, 1800, 1600, 1800, 1800, 1400, 1800, 1800, 1600, 1800, 1800

		/* 181 ~200*/, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1500, 800, 1600, 1800

		//20200424_yhlee 201스테이지 추가
		/* 201 ~220*/, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1500, 800, 1600, 1800
		//20210222_yhlee 240스테이지 추가
		/* 221 ~240*/, 1200, 1200, 800, 1200, 1800, 1200, 1200, 800, 1200, 1800, 1200, 1200, 800, 1200, 1800, 1200, 1200, 800, 1200, 1800
		/* 241 ~260*/, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800
		/* 261 ~280*/, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1500, 800, 1600, 1800
		/* 281 ~300*/, 1200, 1200, 1200, 1200, 1600, 1200, 1200, 800, 1200, 1700, 1200, 1200, 1200, 1200, 1600, 1200, 1500, 800, 1600, 1800
		],
};

/* len from our to your 에 대하여 한을 풀다 */
/*
  2015-11-21 토요일 LG QA에 화면 노이즈 현상 해결을 위해 출근 했다.
  3일 분석결과 TV의 메모리 full로 redraw할때 이상현상을 보인다.
  그것도 맵이 1800 짜리 이상 되는 놈들은 모두 그렇게 보인다.
  그래서 결국은 맵을 1800을 1500으로 강제 변경 했다.

*/


/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// 아군 캐릭터 정의
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

//var MAX_OUR_TEAM_NUM = 42; //아군 캐릭터의 수 -- 루비(37 ~ 42)  --- 2월 말 오픈 예정 -- 이거 주석 해지 할때 아래 g.STAR 부분도 함께 주석 연결해야 함.
//var MAX_OUR_TEAM_NUM = 50; //아군 캐릭터의 수 --황금맨 43 ~48 -.
// var MAX_OUR_TEAM_NUM = 56; //진저맨추가 51~56
// var MAX_OUR_TEAM_NUM = 62; //벤시 추가 57~62 20190109_yhlee 벤시 추가
// var MAX_OUR_TEAM_NUM = 63; //에이스 7성 추가 63 20190215_yhlee 에이스 7성 추가
// var MAX_OUR_TEAM_NUM = 65; //20190624_yhlee  루비,비비 7성 추가
// var MAX_OUR_TEAM_NUM = 68; //20190704_yhlee  에코,스마티,칸 7성 추가
// var MAX_OUR_TEAM_NUM = 75; //20200113_yhlee 제이 캐릭터 추가
var MAX_OUR_TEAM_NUM = 94; //20210603_yhlee 소캐릭터 추가



// var MAX_YOUR_TEAM_NUM = 60; //적군 캐릭터의 수
//20210222_yhlee 240스테이지 추가
var MAX_YOUR_TEAM_NUM = 80; //적군 캐릭터의 수

var ATTACK_LEN = //공격거리 pixel로 나타내기
{
	VL: -35,		// 아주짧다	Very Low
	LO: 40,	// 짧다		Low
	MI: 90,	// 보통		Middle
	HI: 200,	// 길다		High
	VH: 350,	// 매우길다	Very High
}
var ATTACK_SPEED = //공격속도 초로 나타내기(대기시간)
{
	VL: 50,	// 아주느림	Very Low
	LO: 40,	// 느림		Low
	MI: 30,// 보통		Middle
	HI: 20,// 빠르다		High
	VH: 10,// 매우빠르다	Very High
}
var E_ATTACK_SPEED = //공격속도 초로 나타내기(대기시간)
{
	VL: 50,//45,	// 아주느림	Very Low
	LO: 40,//35,	// 느림		Low
	MI: 30,//25,// 보통		Middle
	HI: 20,//15,// 빠르다		High
	VH: 10,//8,// 매우빠르다	Very High
}

var MOVE_SPEED = //이동속도 pixel로 나타내기
{
	VL: 1,	// 아주느림	Very Low
	LO: 2,	// 느림		Low
	MI: 4,// 보통		Middle
	HI: 6,// 빠르다		High
	VH: 7,// 매우빠르다	Very High
}
var E_MOVE_SPEED = //적의 이동속도 pixel로 나타내기
{
	VL: 1,//3,	// 아주느림	Very Low
	LO: 2,//4,	// 느림		Low
	MI: 4,//6,// 보통		Middle
	HI: 6,//8,// 빠르다		High
	VH: 7,//9,// 매우빠르다	Very High
}

var FEATURE =
{
	SPEED: 1, // 스피드형
	WIDE: 2, // 범위형
	HP: 3, // 체력형
	ATTACK: 4  // 공격형
}

var BALANCE =
{
	ACE_AP: 1.0,
	ACE_HP: 1.5,

	ECHO_AP: 1.5,
	ECHO_HP: 1.0,

	SMARTY_AP: 1.2,
	SMARTY_HP: 1.0,

	KHAN_AP: 1.0,
	KHAN_HP: 1.8,

	RUSY_AP: 1.5,
	RUSY_HP: 1.0,

	RUBY_AP: 1.0,
	RUBY_HP: 1.0,

	GOLDMAN_AP: 1.0,
	GOLDMAN_HP: 1.0
}

var CHAR_OUR_TEAM =
	[
		{},//연산편의를 위해 0번 배열은 사용하지 않음.
		{
			name: "ACE",			//캐릭 이름, //초기화 후 한글/영문 등으로 바뀐다.
			filename: "ally_01",	//캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,		//특징
			star: 1,						//별몇개(1~8성),

			w: 97, h: 110,					// 이미지의 크기 (width, height)
			move_frame_num: 4,//8			// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//8			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 미사일 발사 프레임수 실제 미사일...
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 6,	//8		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len),
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2 * BALANCE.ACE_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 35 * BALANCE.ACE_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 10 * BALANCE.ACE_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 200 * BALANCE.ACE_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)


			nm_start: 30,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 110,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...
			center_gap_x: 7,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 11,					//게이지 bar 표기 x좌표
			gagebar_y: -6,					//게이지 bar 표기 y좌표
		},
		{
			name: "ECHO",				// 캐릭 이름
			filename: "ally_02",		// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,				// 특징
			star: 1,						//별몇개(1~8성),

			w: 116, h: 110,				// 이미지의 크기 (width, height)
			move_frame_num: 4,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//8		// 대기시 사용되는 frame의 수
			attack_frame_num: 8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,		// 당할때 사용되는 frame의 수

			fire_frame_num: 8,			// 발사시 사용되는 미사일 발사 프레임수 실제 미사일..
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,		//9// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,	//  공격거리(attack_len),
			move_speed: MOVE_SPEED.VH, // 이동 속도, very high
			attack_speed: ATTACK_SPEED.MI,				// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1 * BALANCE.ECHO_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 20 * BALANCE.ECHO_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 10 * BALANCE.ECHO_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 180 * BALANCE.ECHO_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 20,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 80,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: -13,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 43,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표
		},
		{
			name: "SMARTY",				// 캐릭 이름
			filename: "ally_03",		// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,				// 특징
			star: 1,						//별몇개(1~8성),

			w: 104, h: 109,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //10,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //10,			// 대기시 사용되는 frame의 수
			attack_frame_num: 10,//11		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수 +3은 후폭풍 프레임 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,//9			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			need_ch_time: 30,	// 충전에 필요한 시간 need chage time
			attack_power: 150, 	// 공격력(attack_power),

			ap_start: 3 * BALANCE.SMARTY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 30 * BALANCE.SMARTY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 13 * BALANCE.SMARTY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 260 * BALANCE.SMARTY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 40,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 100,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: -3,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 17,					//게이지 bar 표기 x좌표
			gagebar_y: -10,					//게이지 bar 표기 y좌표
		},
		{
			name: "KHAN",				// 캐릭 이름
			filename: "ally_04",		// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			star: 1,						//별몇개(1~8성),

			w: 116, h: 116,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.LO,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2 * BALANCE.KHAN_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 25 * BALANCE.KHAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 30 * BALANCE.KHAN_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 600 * BALANCE.KHAN_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 30,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 110,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: -10,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 30,					//게이지 bar 표기 x좌표
			gagebar_y: -6,					//게이지 bar 표기 y좌표
		},
		{
			name: "ACE II",					//캐릭 이름
			filename: "ally_05",			//캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			//특징
			star: 2,							//별몇개(1~8성),

			w: 98, h: 110,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 미사일 발사 프레임수 실제 미사일...
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len),
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 18,						// 캐릭터 level 1일때의 attack power임
			ap_end: 70 * BALANCE.ACE_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 13,					// 캐릭터 level 1일때의 hp
			hp_end: 400 * BALANCE.ACE_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 70,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 220,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...
			center_gap_x: 7,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 11,					//게이지 bar 표기 x좌표
			gagebar_y: -6,					//게이지 bar 표기 y좌표
		},
		{
			name: "ACE III",					//캐릭 이름
			filename: "ally_06",			//캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			//특징
			star: 3,							//별몇개(1~8성),
			w: 106, h: 119,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 미사일 발사 프레임수 실제 미사일...
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 44 * BALANCE.ACE_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 210 * BALANCE.ACE_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 30 * BALANCE.ACE_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 1200 * BALANCE.ACE_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 160,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 440,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...
			center_gap_x: 4,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 20,					//게이지 bar 표기 x좌표
			gagebar_y: -4,					//게이지 bar 표기 y좌표
		},
		{
			name: "ACE IV",					//캐릭 이름
			filename: "ally_07",			//캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			//특징
			star: 4,							//별몇개(1~8성),
			w: 104, h: 110,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 미사일 발사 프레임수 실제 미사일...
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 127 * BALANCE.ACE_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 840 * BALANCE.ACE_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 96 * BALANCE.ACE_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 4800 * BALANCE.ACE_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 360,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 810,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...
			center_gap_x: 5,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 18,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표
		},
		{
			name: "ACE V",					//캐릭 이름
			filename: "ally_08",			//캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			//특징
			star: 5,							//별몇개(1~8성),
			w: 99, h: 118,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 11, //12,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 미사일 발사 프레임수 실제 미사일...
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,//7			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len),
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 484 * BALANCE.ACE_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 4200 * BALANCE.ACE_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 40 * BALANCE.ACE_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 24000 * BALANCE.ACE_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 710,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1370,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...
			center_gap_x: 7,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 13,					//게이지 bar 표기 x좌표
			gagebar_y: -1,					//게이지 bar 표기 y좌표
		},
		{
			name: "ACE VI",					//캐릭 이름
			filename: "ally_09",			//캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			//특징
			star: 6,							//별몇개(1~8성),
			w: 107, h: 126,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 11, //12,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 미사일 발사 프레임수 실제 미사일...
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,		//7	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len),
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2342 * BALANCE.ACE_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 25200 * BALANCE.ACE_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2057 * BALANCE.ACE_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 144000 * BALANCE.ACE_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1250,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2160,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...
			center_gap_x: 2,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 20,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표
		},
		{
			name: "ECHO II",			// 캐릭 이름
			filename: "ally_10",		// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,		// 특징
			star: 2,						//별몇개(1~8성),

			w: 124, h: 114,				// 이미지의 크기 (width, height)
			move_frame_num: 4,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,		// 대기시 사용되는 frame의 수
			attack_frame_num: 8,//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,		// 당할때 사용되는 frame의 수

			fire_frame_num: 8,			// 발사시 사용되는 미사일 발사 프레임수 실제 미사일..
			fire_img_frame_num: 1,		// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,	//  공격거리(attack_len),
			move_speed: MOVE_SPEED.VH, // 이동 속도, very high
			attack_speed: ATTACK_SPEED.MI,				// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 10 * BALANCE.ECHO_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 40 * BALANCE.ECHO_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 12 * BALANCE.ECHO_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 360 * BALANCE.ECHO_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 40,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 190,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: -14,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 48,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표
		},
		{
			name: "ECHO III",			// 캐릭 이름
			filename: "ally_11",		// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,		// 특징
			star: 3,						//별몇개(1~8성),

			w: 137, h: 117,				// 이미지의 크기 (width, height)
			move_frame_num: 4,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,		// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,		// 당할때 사용되는 frame의 수

			fire_frame_num: 8,			// 발사시 사용되는 미사일 발사 프레임수 실제 미사일..
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,	//  공격거리(attack_len),
			move_speed: MOVE_SPEED.VH, // 이동 속도, very high
			attack_speed: ATTACK_SPEED.MI,				// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 25 * BALANCE.ECHO_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 120 * BALANCE.ECHO_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 27 * BALANCE.ECHO_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 1080 * BALANCE.ECHO_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 130,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 410,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: -14,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 59,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표
		},
		{
			name: "ECHO IV",			// 캐릭 이름
			filename: "ally_12",		// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,		// 특징
			star: 4,						//별몇개(1~8성),

			w: 141, h: 119,				// 이미지의 크기 (width, height)
			move_frame_num: 4,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,		// 대기시 사용되는 frame의 수
			attack_frame_num: 8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,		// 당할때 사용되는 frame의 수

			fire_frame_num: 8,			// 발사시 사용되는 미사일 발사 프레임수 실제 미사일..
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,	//  공격거리(attack_len),
			move_speed: MOVE_SPEED.VH, // 이동 속도, very high
			attack_speed: ATTACK_SPEED.MI,				// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 73 * BALANCE.ECHO_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 480 * BALANCE.ECHO_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 86 * BALANCE.ECHO_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 4320 * BALANCE.ECHO_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 330,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 780,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: -14,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 59,					//게이지 bar 표기 x좌표
			gagebar_y: -5,					//게이지 bar 표기 y좌표
		},
		{
			name: "ECHO V",				// 캐릭 이름
			filename: "ally_13",		// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,		// 특징
			star: 5,						//별몇개(1~8성),

			w: 155, h: 137,				// 이미지의 크기 (width, height)
			move_frame_num: 4,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,		// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,		// 당할때 사용되는 frame의 수

			fire_frame_num: 8,			// 발사시 사용되는 미사일 발사 프레임수 실제 미사일..
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,	//  공격거리(attack_len),
			move_speed: MOVE_SPEED.VH, // 이동 속도, very high
			attack_speed: ATTACK_SPEED.MI,				// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 276 * BALANCE.ECHO_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 2400 * BALANCE.ECHO_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 360 * BALANCE.ECHO_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 21600 * BALANCE.ECHO_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 680,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1340,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: -35,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 82,					//게이지 bar 표기 x좌표
			gagebar_y: 25,					//게이지 bar 표기 y좌표
		},
		{
			name: "ECHO VI",				// 캐릭 이름
			filename: "ally_14",		// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,		// 특징
			star: 6,						//별몇개(1~8성),

			w: 160, h: 137,				// 이미지의 크기 (width, height)
			move_frame_num: 4,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,		// 대기시 사용되는 frame의 수
			attack_frame_num: 8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,		// 당할때 사용되는 frame의 수

			fire_frame_num: 8,			// 발사시 사용되는 미사일 발사 프레임수 실제 미사일..
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,	//  공격거리(attack_len),
			move_speed: MOVE_SPEED.VH, // 이동 속도, very high
			attack_speed: ATTACK_SPEED.MI,				// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1338 * BALANCE.ECHO_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 14400 * BALANCE.ECHO_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1851 * BALANCE.ECHO_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 129600 * BALANCE.ECHO_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1220,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2130,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level
			center_gap_x: -34,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 82,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표
		},
		{
			name: "SMARTY II",			// 캐릭 이름
			filename: "ally_15",		// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,		// 특징
			star: 2,						//별몇개(1~8성),

			w: 112, h: 126,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //10,			// 이동시 사용되는 frame의 수
			wait_frame_num: 8, //10,			// 대기시 사용되는 frame의 수
			attack_frame_num: 10,	//14		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3, //5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,			// 발사시 사용되는 frame의 수 +3은 후폭풍 프레임 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 15 * BALANCE.SMARTY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 60 * BALANCE.SMARTY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 17 * BALANCE.SMARTY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 520 * BALANCE.SMARTY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 60,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 210,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: 3,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 16,					//게이지 bar 표기 x좌표
			gagebar_y: -6,					//게이지 bar 표기 y좌표

		},
		{
			name: "SMARTY III",			// 캐릭 이름
			filename: "ally_16",		// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,		// 특징
			star: 3,						//별몇개(1~8성),

			w: 133, h: 156,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //10,			// 이동시 사용되는 frame의 수
			wait_frame_num: 8, //10,			// 대기시 사용되는 frame의 수
			attack_frame_num: 10,//14			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3, //5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수 +3은 후폭풍 프레임 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 38 * BALANCE.SMARTY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 180 * BALANCE.SMARTY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 39 * BALANCE.SMARTY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 1560 * BALANCE.SMARTY_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 150,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 430,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: 13,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 17,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표

		},
		{
			name: "SMARTY IV",			// 캐릭 이름
			filename: "ally_17",		// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,		// 특징
			star: 4,						//별몇개(1~8성),

			w: 145, h: 163,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //10,			// 이동시 사용되는 frame의 수
			wait_frame_num: 8, //10,			// 대기시 사용되는 frame의 수
			attack_frame_num: 10,	//14		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3, //5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수 +3은 후폭풍 프레임 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.VL,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 109 * BALANCE.SMARTY_AP,					// 캐릭터 level 1일때의 attack power임
			ap_end: 720 * BALANCE.SMARTY_AP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 125 * BALANCE.SMARTY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 6240 * BALANCE.SMARTY_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 350,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 800,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 6,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 28,					//게이지 bar 표기 x좌표
			gagebar_y: 40,					//게이지 bar 표기 y좌표

		},
		{
			name: "SMARTY V",			// 캐릭 이름
			filename: "ally_18",		// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,		// 특징
			star: 5,						//별몇개(1~8성),

			w: 140, h: 170,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 8, //10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,	//14		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3, //5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수 +3은 후폭풍 프레임 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,		//9	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.VL,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 414 * BALANCE.SMARTY_AP,					// 캐릭터 level 1일때의 attack power임
			ap_end: 3600 * BALANCE.SMARTY_AP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 520 * BALANCE.SMARTY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 31200 * BALANCE.SMARTY_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 700,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1360,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: 18,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 17,					//게이지 bar 표기 x좌표
			gagebar_y: 47,					//게이지 bar 표기 y좌표

		},
		{
			name: "SMARTY VI",			// 캐릭 이름
			filename: "ally_19",		// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,		// 특징
			star: 6,						//별몇개(1~8성),

			w: 139, h: 173,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 8, //10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,	//14		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3, //5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수 +3은 후폭풍 프레임 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//9		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2007 * BALANCE.SMARTY_AP,					// 캐릭터 level 1일때의 attack power임
			ap_end: 21600 * BALANCE.SMARTY_AP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2674 * BALANCE.SMARTY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 187200 * BALANCE.SMARTY_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 1240,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level
			center_gap_x: 18,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 19,					//게이지 bar 표기 x좌표
			gagebar_y: 37,					//게이지 bar 표기 y좌표

		},
		{
			name: "KHAN II",				// 캐릭 이름
			filename: "ally_20",		// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			star: 2,						//별몇개(1~8성),

			w: 127, h: 127,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.LO,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 13 * BALANCE.KHAN_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 50 * BALANCE.KHAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 40 * BALANCE.KHAN_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 1200 * BALANCE.KHAN_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 70,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 220,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: -6,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 32,					//게이지 bar 표기 x좌표
			gagebar_y: -1,					//게이지 bar 표기 y좌표

		},
		{
			name: "KHAN III",				// 캐릭 이름
			filename: "ally_21",		// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			star: 3,						//별몇개(1~8성),

			w: 122, h: 121,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.LO,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 31 * BALANCE.KHAN_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 150 * BALANCE.KHAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 90 * BALANCE.KHAN_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 3600 * BALANCE.KHAN_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 160,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 440,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: -7,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 29,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표

		},
		{
			name: "KHAN IV",				// 캐릭 이름
			filename: "ally_22",		// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			star: 4,						//별몇개(1~8성),

			w: 135, h: 123,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.LO,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 91 * BALANCE.KHAN_AP,					// 캐릭터 level 1일때의 attack power임
			ap_end: 600 * BALANCE.KHAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 288 * BALANCE.KHAN_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 14400 * BALANCE.KHAN_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 360,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 810,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: -4,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 34,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표

		},
		{
			name: "KHAN V",				// 캐릭 이름
			filename: "ally_23",		// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			star: 5,						//별몇개(1~8성),

			w: 121, h: 121,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.LO,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 345 * BALANCE.KHAN_AP,					// 캐릭터 level 1일때의 attack power임
			ap_end: 3000 * BALANCE.KHAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1200 * BALANCE.KHAN_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 72000 * BALANCE.KHAN_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 710,						// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1370,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: -8,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 29,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표

		},
		{
			name: "KHAN VI",				// 캐릭 이름
			filename: "ally_24",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			star: 6,							//별몇개(1~8성),

			w: 127, h: 134,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.LO,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1673 * BALANCE.KHAN_AP,					// 캐릭터 level 1일때의 attack power임
			ap_end: 18000 * BALANCE.KHAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 6171 * BALANCE.KHAN_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 432000 * BALANCE.KHAN_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1250,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2160,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level
			center_gap_x: -8,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 33,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "LODY I",					// 캐릭 이름
			filename: "ally_25",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 1,							//별몇개(1~8성),

			w: 90, h: 116,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 6,	//8			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 3 * BALANCE.RUSY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 40 * BALANCE.RUSY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 12 * BALANCE.RUSY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 240 * BALANCE.RUSY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 40,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 100,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: -1,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 10,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "LODY II",					// 캐릭 이름
			filename: "ally_26",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 90, h: 116,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,	//8			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4, //6			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 20 * BALANCE.RUSY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 80 * BALANCE.RUSY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 16 * BALANCE.RUSY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 480 * BALANCE.RUSY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 60,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 210,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: -1,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 10,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "LODY III",				// 캐릭 이름
			filename: "ally_27",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 143, h: 116,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 6,	//8			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 2,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 50 * BALANCE.RUSY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 240 * BALANCE.RUSY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 36 * BALANCE.RUSY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 1440 * BALANCE.RUSY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 150,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 430,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: 30,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 11,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "LODY IV",					// 캐릭 이름
			filename: "ally_28",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 143, h: 116,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 6,	//8			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,//6			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 145 * BALANCE.RUSY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 1440 * BALANCE.RUSY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 173 * BALANCE.RUSY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 8640 * BALANCE.RUSY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 350,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 800,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 30,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 11,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "LODY V",					// 캐릭 이름
			filename: "ally_29",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 75, h: 116,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,	//8			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 793 * BALANCE.RUSY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 5760 * BALANCE.RUSY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 576 * BALANCE.RUSY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 34560 * BALANCE.RUSY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 700,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1360,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: -8,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 8,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "LODY VI",					// 캐릭 이름
			filename: "ally_30",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 94, h: 122,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 6,	//8			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 3276 * BALANCE.RUSY_AP,						// 캐릭터 level 1일때의 attack power임
			ap_end: 28800 * BALANCE.RUSY_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2469 * BALANCE.RUSY_HP,					// 캐릭터 level 1일때의 hp
			hp_end: 172800 * BALANCE.RUSY_HP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1240,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level
			center_gap_x: -11,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 18,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "BEBEE I",					// 캐릭 이름
			filename: "ally_31",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 1,							//별몇개(1~8성),

			w: 92, h: 139,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 5, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 11,	//15		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,	//8		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2,						// 캐릭터 level 1일때의 attack power임
			ap_end: 35,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 10,					// 캐릭터 level 1일때의 hp
			hp_end: 200,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 30,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 110,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: -15,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 22,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표

		},
		{
			name: "BEBEE II",					// 캐릭 이름
			filename: "ally_32",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 115, h: 135,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,	//12		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,	//7		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 18,						// 캐릭터 level 1일때의 attack power임
			ap_end: 70,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 13,					// 캐릭터 level 1일때의 hp
			hp_end: 400,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 70,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 220,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: -10,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 26,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		{
			name: "BEBEE III",					// 캐릭 이름
			filename: "ally_33",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 149, h: 126,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 11,	//16	// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 미사일이 몇번에 끊어서 날아 갈까.
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,	//12	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 44,						// 캐릭터 level 1일때의 attack power임
			ap_end: 210,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 30,					// 캐릭터 level 1일때의 hp
			hp_end: 1200,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 160,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 440,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: 0,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 40,					//게이지 bar 표기 x좌표
			gagebar_y: -13,					//게이지 bar 표기 y좌표

		},
		{
			name: "BEBEE IV",					// 캐릭 이름
			filename: "ally_34",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 134, h: 134,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 17,	//20	// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 24,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 12,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 6,	//8		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 127,						// 캐릭터 level 1일때의 attack power임
			ap_end: 840,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 96,					// 캐릭터 level 1일때의 hp
			hp_end: 4800,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 360,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 810,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: -40,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 62,					//게이지 bar 표기 x좌표
			gagebar_y: -7,					//게이지 bar 표기 y좌표

		},
		{
			name: "BEBEE V",					// 캐릭 이름
			filename: "ally_35",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징		//ywlee_20160511
			//feature:FEATURE.ATTACK,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 204, h: 168,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수
			attack_frame_num: 9,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 9,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 9,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 328,						// 캐릭터 level 1일때의 attack power임
			ap_end: 2850,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1200,					// 캐릭터 level 1일때의 hp
			hp_end: 72000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 710,				// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1370,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...

			center_gap_x: 25,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 46,					//게이지 bar 표기 x좌표
			gagebar_y: 29,					//게이지 bar 표기 y좌표

		},
		{
			name: "BEBEE VI",					// 캐릭 이름
			filename: "ally_36",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 254, h: 210,						// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수
			attack_frame_num: 9,	//11		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			//ywlee_20160511
			//fire_frame_num:4,				// 발사시 사용되는 frame의 수
			fire_frame_num: 4,				// 발사시 사용되는 frame의 수

			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 9,	//10	// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VL,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1589,						// 캐릭터 level 1일때의 attack power임
			ap_end: 17100,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 6171,					// 캐릭터 level 1일때의 hp
			hp_end: 432000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1250,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2160,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level, 필요 없을 수도 있겠다. star로 부터 유추 할 수 있으니...

			center_gap_x: 0,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 46,					//게이지 bar 표기 x좌표
			gagebar_y: -12,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY I",					// 캐릭 이름
			filename: "ally_37",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 1,							//별몇개(1~8성),

			w: 81, h: 115,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //7,			// 이동시 사용되는 frame의 수
			wait_frame_num: 5, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7, //8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수+5 후폭풍수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5, //6,		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VL,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 3,						// 캐릭터 level 1일때의 attack power임
			ap_end: 30,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 13,					// 캐릭터 level 1일때의 hp
			hp_end: 260,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 40,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 100,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: -20,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 20,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY II",					// 캐릭 이름
			filename: "ally_38",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 96, h: 116,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 6,		//9		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수+5 후폭풍수
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//8		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 15,						// 캐릭터 level 1일때의 attack power임
			ap_end: 60,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 17,					// 캐릭터 level 1일때의 hp
			hp_end: 520,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 60,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 210,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: -10,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 20,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY III",					// 캐릭 이름
			filename: "ally_39",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 116, h: 139,						// 이미지의 크기 (width, height)
			move_frame_num: 5, //6,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//9			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 17,				// 발사시 사용되는 frame의 수+7 후폭풍수
			fire_img_frame_num: 10,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 6,	//8		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 38,						// 캐릭터 level 1일때의 attack power임
			ap_end: 180,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 39,					// 캐릭터 level 1일때의 hp
			hp_end: 1560,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 150,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 430,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: -15,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 35,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY IV",					// 캐릭 이름
			filename: "ally_40",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 126, h: 119,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 7,	//9			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			//fire_frame_num:30,				// 발사시 사용되는 frame의 수+24 후폭풍수
			fire_frame_num: 36,				// 발사시 사용되는 frame의 수+24 후폭풍수
			fire_img_frame_num: 12,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 6,	//8		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH * 1.2,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VL * 2,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 109,						// 캐릭터 level 1일때의 attack power임
			ap_end: 720,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 125,					// 캐릭터 level 1일때의 hp
			hp_end: 6240,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 350,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 800,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: -40,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 53,					//게이지 bar 표기 x좌표
			gagebar_y: -13,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY V",					// 캐릭 이름
			filename: "ally_41",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 123, h: 150,					// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 10,	//14	// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수
			/*
					fire_frame_num:25,				// 발사시 사용되는 frame의 수+24 후폭풍수
					fire_img_frame_num:1,			// 미사일 이미지 프레임수 (이미지 갯수 )
					attack_fire_frame:12,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
					attack_len:ATTACK_LEN.VH*1.2,		// 공격거리(attack_len)
					move_speed:MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
					attack_speed:ATTACK_SPEED.VL*2,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.
			*/

			fire_frame_num: 7,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 10,	//12		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 414,						// 캐릭터 level 1일때의 attack power임
			ap_end: 3600,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 520,					// 캐릭터 level 1일때의 hp
			hp_end: 31200,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 700,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1360,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: -15,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 33,					//게이지 bar 표기 x좌표
			gagebar_y: 20,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY VI",					// 캐릭 이름
			filename: "ally_42",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 265, h: 254,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수
			attack_frame_num: 8,	//10		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 19,				// 발사시 사용되는 frame의 수   실제 미사일 frame의 수 +8 , 포물선 frame 추가 +2 , 후폭풍 +9  포함 총합 19
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,	//6		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2007,						// 캐릭터 level 1일때의 attack power임
			ap_end: 21600,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2674,					// 캐릭터 level 1일때의 hp
			hp_end: 350000,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1240,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level
			center_gap_x: 28,					// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 81,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		/// 황금맨 추가	/////
		{
			name: "GOLDMAN II",				// 캐릭 이름
			filename: "ally_43",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 202, h: 176,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 0,			// 미사일 이미지 프레임수 (이미지 갯수 ) - 몸빵임
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 18,						// 캐릭터 level 1일때의 attack power임
			ap_end: 70 * BALANCE.GOLDMAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 13,					// 캐릭터 level 1일때의 hp
			hp_end: 400 * BALANCE.GOLDMAN_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 70,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 220,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: 20,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 50,					//게이지 bar 표기 x좌표
			gagebar_y: 15,					//게이지 bar 표기 y좌표

		},
		{
			name: "GOLDMAN III",			// 캐릭 이름
			filename: "ally_44",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 196, h: 162,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 0,			// 미사일 이미지 프레임수 (이미지 갯수 ) - 몸빵임
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 44,						// 캐릭터 level 1일때의 attack power임
			ap_end: 210 * BALANCE.GOLDMAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 30,					// 캐릭터 level 1일때의 hp
			hp_end: 1200 * BALANCE.GOLDMAN_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 160,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 440,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level
			center_gap_x: 20,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 50,					//게이지 bar 표기 x좌표
			gagebar_y: 5,					//게이지 bar 표기 y좌표

		},
		{
			name: "GOLDMAN IV",				// 캐릭 이름
			filename: "ally_45",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 254, h: 187,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 0,			// 미사일 이미지 프레임수 (이미지 갯수 ) - 몸빵임
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 127,						// 캐릭터 level 1일때의 attack power임
			ap_end: 840 * BALANCE.GOLDMAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 96,					// 캐릭터 level 1일때의 hp
			hp_end: 4800 * BALANCE.GOLDMAN_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 360,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 810,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 30,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: -90,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 66,					//게이지 bar 표기 x좌표
			gagebar_y: 30,					//게이지 bar 표기 y좌표
		},
		{
			name: "GOLDMAN V",				// 캐릭 이름
			filename: "ally_46",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 254, h: 187,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 0,			// 미사일 이미지 프레임수 (이미지 갯수 ) - 몸빵임
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 600,						// 캐릭터 level 1일때의 attack power임
			ap_end: 3500 * BALANCE.GOLDMAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 600,					// 캐릭터 level 1일때의 hp
			hp_end: 24000 * BALANCE.GOLDMAN_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 710,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1370,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: 30,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: -20,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 70,					//게이지 bar 표기 x좌표
			gagebar_y: 35,					//게이지 bar 표기 y좌표
		},
		{
			name: "GOLDMAN VI",				// 캐릭 이름
			filename: "ally_47",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 296, h: 242,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 18,				// 발사시 사용되는 frame의 수   //20이지만 18번쯤 날라 갈때 정산하는 것도 나쁘지 않다.
			fire_img_frame_num: 3,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH * 1.5,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 20000 * BALANCE.GOLDMAN_AP,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2057,					// 캐릭터 level 1일때의 hp
			hp_end: 124000 * BALANCE.GOLDMAN_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1250,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2160,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level
			center_gap_x: 12,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 90,					//게이지 bar 표기 x좌표
			gagebar_y: 35,					//게이지 bar 표기 y좌표
		},
		{
			name: "GOLDMAN VII",				// 캐릭 이름
			filename: "ally_48",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 311, h: 299,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,//10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수   //20이지만 18번쯤 날라 갈때 정산하는 것도 나쁘지 않다.
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH * 1.5,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.VL,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VL * 1.2,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 10000,//10000						// 캐릭터 level 1일때의 attack power임
			ap_end: 200000 * BALANCE.GOLDMAN_AP,//100000						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 10000,					// 캐릭터 level 1일때의 hp
			hp_end: 450000 * BALANCE.GOLDMAN_HP,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 2700,//1800					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 4000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: -6,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -3,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 130,					//게이지 bar 표기 x좌표
			gagebar_y: 35,					//게이지 bar 표기 y좌표
		},
		/// 황금맨 추가 -- 끝 -- ////


		{
			name: "RUSY VII",				// 루시7성 - 대천사루시 - 특수기능:힐러 -- 힐러가 발동되면 우리 아군의 피를 10%씩 올려 준다.
			filename: "ally_49",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 384, h: 331,						// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 9,			// 공격 모션에 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,//10,			// 발사시 사용되는 frame의 수 //몇frame으로 몇 단계로 날아 가겠느냐. 주로 아래 fire_img_frmae_num과 같다.
			fire_img_frame_num: 6,//10,			// 미사일 이미지 프레임수 (이미지 갯수 )

			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH * 2.0,	// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 8000,                     // 캐릭터 level 1일때의 attack power임
			ap_end: 50000,                      // 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 10000,                    // 캐릭터 level 1일때의 hp
			hp_end: 380000,                     // 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1900,                    // 캐릭터 level 1일때의 Need Mineral임
			nm_end: 6000,                      // 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,                   // 성장할 수 있는 최고 level
			center_gap_x: 8,               // wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,                // wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,           // 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 150,                  //게이지 bar 표기 x좌표
			gagebar_y: 116,                 //게이지 bar 표기 y좌표

		},
		{
			name: "RUSY VII",				// 루시7성-쎈언니 - 특수기능: 반피, 한번의 공격으로 상대HP를 무조건 반피로 만든다. 만약, 반피보다 더 많이 깎여야 하는 공격은 그렇게 한다.
			filename: "ally_50",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 460, h: 277,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수
			attack_frame_num: 9,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수 //몇frame으로 몇 단계로 날아 가겠느냐. //공격 몇frame에 damage 줄래
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (fire 이미지 갯수  )
			// attack_fire_frame:20-5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? 14 frame부터 발사해서 20 frame에 데미지를 입히자. -5는 fire_frame_num의 값이다.
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.VH * 2,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 11000,                        // 캐릭터 level 1일때의 attack power임
			ap_end: 210000,                      // 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 50000,                    // 캐릭터 level 1일때의 hp
			hp_end: 550000,                     // 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 2000,                    // 캐릭터 level 1일때의 Need Mineral임
			nm_end: 5000,                     // 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,                   // 성장할 수 있는 최고 level
			center_gap_x: 15,                   // wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,                // wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,           // 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 121,                  //게이지 bar 표기 x좌표
			gagebar_y: 77,                 //게이지 bar 표기 y좌표

		},
		{
			name: "GINGERMAN II",			// 캐릭 이름
			filename: "ally_51",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 165, h: 160,						// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 상대편 damage를 몇 frame부터 줄 것인가 attack_frame_num보다 작아야 한다.
			fire_img_frame_num: 0,			// 진저맨의 공격은 프레임에 붙어 있다. 그래서 0이다.
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? fire_frame_num(7);

			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 23,						// 캐릭터 level 1일때의 attack power임
			ap_end: 91,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 16,					// 캐릭터 level 1일때의 hp
			hp_end: 480,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 84,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 264,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: 16,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 20,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 46,					//게이지 bar 표기 x좌표
			gagebar_y: 33,					//게이지 bar 표기 y좌표

		},
		{
			name: "GINGERMAN III",					// 캐릭 이름
			filename: "ally_52",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 219, h: 153,						// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 0,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 57,						// 캐릭터 level 1일때의 attack power임
			ap_end: 273,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 36,					// 캐릭터 level 1일때의 hp
			hp_end: 1440,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 192,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 528,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level

			center_gap_x: 28,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: -80,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 57,					//게이지 bar 표기 x좌표
			gagebar_y: 25,					//게이지 bar 표기 y좌표

		},
		{
			name: "GINGERMAN IV",					// 캐릭 이름
			filename: "ally_53",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 224, h: 156,						// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 4,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안됨.

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 165,					// 캐릭터 level 1일때의 attack power임
			ap_end: 1092,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 115,					// 캐릭터 level 1일때의 hp
			hp_end: 5760,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 460,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 910,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 36,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 20,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 55,					//게이지 bar 표기 x좌표
			gagebar_y: 15,					//게이지 bar 표기 y좌표

		},
		{
			name: "GINGERMAN V",			// 캐릭 이름 - 닌자
			filename: "ally_54",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 140, h: 275,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 7,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 7,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 600,						// 캐릭터 level 1일때의 attack power임
			ap_end: 4550,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 600,					// 캐릭터 level 1일때의 hp
			hp_end: 28800,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 810,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1470,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 20,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 42,					//게이지 bar 표기 x좌표
			gagebar_y: 140,					//게이지 bar 표기 y좌표

		},
		{
			name: "GINGERMAN VI",			// 캐릭 이름
			filename: "ally_55",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 224, h: 160,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 3,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.VH * 1.3,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2100,						// 캐릭터 level 1일때의 attack power임
			ap_end: 26000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2100,					// 캐릭터 level 1일때의 hp
			hp_end: 148800,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1240,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level

			center_gap_x: 16,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: -50,			//적군이 아군 공격할때 얼마나 더 가깍이 가서 발사 할 것인가 이다.
			gagebar_x: 62,					//게이지 bar 표기 x좌표
			gagebar_y: 14,					//게이지 bar 표기 y좌표

		},
		{
			name: "GINGERMAN VII",					// 캐릭 이름
			filename: "ally_56",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 308, h: 241,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 12,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 3 + 4 + 8,		// 미사일 이미지 프레임수 (이미지 갯수 ) //날아갈때3, 돌아올때4, 샤라라8
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.VH * 1.8,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 180000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 15000,					// 캐릭터 level 1일때의 hp
			hp_end: 450000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3200,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 5000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 37,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: -50,			//적군이 아군 공격할때 얼마나 더 가깍이 가서 발사 할 것인가 이다.
			gagebar_x: 96,					//게이지 bar 표기 x좌표
			gagebar_y: 80 - 20,					//게이지 bar 표기 y좌표

		},
		//20190109_yhlee 벤시 추가
		{
			name: "BENSI II",					// 캐릭 이름
			filename: "ally_57",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 117, h: 151,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 23,						// 캐릭터 level 1일때의 attack power임
			ap_end: 91,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 16,					// 캐릭터 level 1일때의 hp
			hp_end: 480,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 84,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 264,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: 16,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 17,					//게이지 bar 표기 x좌표
			gagebar_y: -11,					//게이지 bar 표기 y좌표

		},
		{
			name: "BENSI III",					// 캐릭 이름
			filename: "ally_58",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 130, h: 151,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 5,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 10,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 57,						// 캐릭터 level 1일때의 attack power임
			ap_end: 273,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 36,					// 캐릭터 level 1일때의 hp
			hp_end: 1440,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 192,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 528,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level

			center_gap_x: 28,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 17,					//게이지 bar 표기 x좌표
			gagebar_y: -11,					//게이지 bar 표기 y좌표

		},
		{
			name: "BENSI IV",					// 캐릭 이름
			filename: "ally_59",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 117, h: 151,						// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 4,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 4,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 165,					// 캐릭터 level 1일때의 attack power임
			ap_end: 1092,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 115,					// 캐릭터 level 1일때의 hp
			hp_end: 5760,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 460,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 910,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 10,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 17,					//게이지 bar 표기 x좌표
			gagebar_y: -11,					//게이지 bar 표기 y좌표

		},
		{
			name: "BENSI V",					// 캐릭 이름
			filename: "ally_60",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 152, h: 147,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 3,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 600,						// 캐릭터 level 1일때의 attack power임
			ap_end: 4550,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 600,					// 캐릭터 level 1일때의 hp
			hp_end: 28800,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 810,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1470,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.


			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 49,					//게이지 bar 표기 x좌표
			gagebar_y: -9,					//게이지 bar 표기 y좌표

		},
		{
			name: "BENSI VI",					// 캐릭 이름
			filename: "ally_61",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 248, h: 296,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2100,						// 캐릭터 level 1일때의 attack power임
			ap_end: 26000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2100,					// 캐릭터 level 1일때의 hp
			hp_end: 148800,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1240,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level

			center_gap_x: -20,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 102,					//게이지 bar 표기 x좌표
			gagebar_y: 136,					//게이지 bar 표기 y좌표

		},
		{
			name: "BENSI VII",					// 캐릭 이름
			filename: "ally_62",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 300, h: 300,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 180000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 15000,					// 캐릭터 level 1일때의 hp
			hp_end: 450000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3200,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 5000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 37,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 79,					//게이지 bar 표기 x좌표
			gagebar_y: 144,					//게이지 bar 표기 y좌표

		},
		//20190215_yhlee 에이스 7성 추가
		{
			name: "ACE VII",					// 캐릭 이름
			filename: "ally_63",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 315, h: 298,					// 이미지의 크기 (width, height)
			move_frame_num: 9,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 4,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 4,		// 미사일 이미지 프레임수 (이미지 갯수 ) //날아갈때3, 돌아올때4, 샤라라8
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.HI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 8000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 400000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 25000,					// 캐릭터 level 1일때의 hp
			hp_end: 500000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 5000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: -70,			//적군이 아군 공격할때 얼마나 더 가깍이 가서 발사 할 것인가 이다.
			gagebar_x: 207,                  //게이지 bar 표기 x좌표
			gagebar_y: 65,                 //게이지 bar 표기 y좌표

		},
		//20190624_yhlee  루비,비비 7성 추가
		{
			name: "BEBEE VII",					// 캐릭 이름
			filename: "ally_64",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 274, h: 212,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 1,		// 미사일 이미지 프레임수 (이미지 갯수 ) //날아갈때3, 돌아올때4, 샤라라8
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VL,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 8000,                     // 캐릭터 level 1일때의 attack power임
			ap_end: 120000,                      // 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 8000,                    // 캐릭터 level 1일때의 hp
			hp_end: 440000,                     // 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1900,                    // 캐릭터 level 1일때의 Need Mineral임
			nm_end: 6000,                      // 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: 0,			//적군이 아군 공격할때 얼마나 더 가깍이 가서 발사 할 것인가 이다.
			gagebar_x: 46,					//게이지 bar 표기 x좌표
			gagebar_y: -12,					//게이지 bar 표기 y좌표

		},
		{
			name: "RUBY VII",					// 캐릭 이름
			filename: "ally_65",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 249, h: 259,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 15,				// 발사시 사용되는 frame의 수   실제 미사일 frame의 수 +8 , 포물선 frame 추가 +2 , 후폭풍 +5  포함 총합 15
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: ATTACK_LEN.VH + 10,	// 공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 8000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 250000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 20000,					// 캐릭터 level 1일때의 hp
			hp_end: 450000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 5000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 81,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		//20190704_yhlee  에코,스마티,칸 7성 추가
		{
			name: "ECHO VII",			// 캐릭 이름 - 에코 7성 (프라임 에코)
			filename: "ally_66",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 226, h: 268,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 5,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 8,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.VH,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 7000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 250000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 22000,					// 캐릭터 level 1일때의 hp
			hp_end: 400000,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)


			nm_start: 1900,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 6000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: -45,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 120,					//게이지 bar 표기 x좌표
			gagebar_y: 50,					//게이지 bar 표기 y좌표

		},
		{
			name: "SMARTY VII",			// 캐릭 이름 - 스마티 7성 (가디언 스마티)
			filename: "ally_67",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 198, h: 230,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수   실제 미사일 frame의 수 +7 , 후폭풍 +10  포함 총합 17
			fire_img_frame_num: 8,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.VH * 2,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 6000,					// 캐릭터 level 1일때의 attack power임
			ap_end: 160000,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 7000,					// 캐릭터 level 1일때의 hp
			hp_end: 350000,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)p)

			nm_start: 2000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 6000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 60,					//게이지 bar 표기 x좌표
			gagebar_y: 30,					//게이지 bar 표기 y좌표

		},
		{
			name: "KHAN VII",			// 캐릭 이름 - 칸 7성 (아이언 칸)
			filename: "ally_68",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 254, h: 189,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수 (게임에서 사용)
			attack_frame_num: 4,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 4,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.VL,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.MI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1,					// 캐릭터 level 1일때의 attack power임
			ap_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 100000,					// 캐릭터 level 1일때의 hp
			hp_end: 7776000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 4500,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 9000,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: -20,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 100,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표

		},

		//20200113_yhlee 제이 캐릭터 추가
		{
			name: "JEY I",			// 캐릭 이름 - 제이 1성
			filename: "ally_69",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 1,							//별몇개(1~8성),

			w: 132, h: 139,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수 (게임에서 사용)
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 미사일 날라 가다가 몇 frame에 damage줄래? 6frame날라가고 후폭풍있는 10쯤
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가? //사용안함.

			attack_len: ATTACK_LEN.HI,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1,					// 캐릭터 level 1일때의 attack power임
			ap_end: 25,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 10,					// 캐릭터 level 1일때의 hp
			hp_end: 150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 20,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 80,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 20,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 36,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		{
			name: "JEY II",					// 캐릭 이름
			filename: "ally_70",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 125, h: 139,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 7,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 7,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.HI,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 10,						// 캐릭터 level 1일때의 attack power임
			ap_end: 50,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 12,					// 캐릭터 level 1일때의 hp
			hp_end: 300,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 40,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 190,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: -10,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 30,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		{
			name: "JEY III",					// 캐릭 이름
			filename: "ally_71",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 143, h: 145,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.HI,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 25,						// 캐릭터 level 1일때의 attack power임
			ap_end: 140,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 27,					// 캐릭터 level 1일때의 hp
			hp_end: 950,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 130,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 410,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level

			center_gap_x: -10,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 40,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		{
			name: "JEY IV",					// 캐릭 이름
			filename: "ally_72",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 148, h: 146,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.HI,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.VH,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 73,					// 캐릭터 level 1일때의 attack power임
			ap_end: 600,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 86,					// 캐릭터 level 1일때의 hp
			hp_end: 3900,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 330,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 780,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 43,					//게이지 bar 표기 x좌표
			gagebar_y: -8,					//게이지 bar 표기 y좌표

		},
		{
			name: "JEY V",					// 캐릭 이름
			filename: "ally_73",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 241, h: 191,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH * 1.2,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 328,						// 캐릭터 level 1일때의 attack power임
			ap_end: 2850,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1200,					// 캐릭터 level 1일때의 hp
			hp_end: 72000,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 710,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1370,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: 20,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: -70,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 73,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표

		},
		{
			name: "JEY VI",					// 캐릭 이름
			filename: "ally_74",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 271, h: 167,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 4,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH * 1.5,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.LO,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 2007,						// 캐릭터 level 1일때의 attack power임
			ap_end: 25000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 2674,					// 캐릭터 level 1일때의 hp
			hp_end: 250000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 1240,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 2150,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level

			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: -100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 80,					//게이지 bar 표기 x좌표
			gagebar_y: 1,					//게이지 bar 표기 y좌표

		},
		{
			name: "JEY VII",					// 캐릭 이름
			filename: "ally_75",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 259, h: 234,						// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 4,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: ATTACK_LEN.VH * 1.8,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.LO,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 6000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 180000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)
			// ap_end:0,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 7000,					// 캐릭터 level 1일때의 hp
			hp_end: 380000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 4950,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 9900,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 30,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: -100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 76,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표

		},
		//20210603_yhlee 소캐릭터 추가
		{
			name: "COW II",					// 캐릭 이름
			filename: "ally_76",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 2,							//별몇개(1~8성),

			w: 173, h: 157,						// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 9,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_len: -200,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 12,						// 캐릭터 level 1일때의 attack power임
			ap_end: 45,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 84,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 264,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 30,					// 성장할 수 있는 최고 level
			center_gap_x: 0,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 56,					//게이지 bar 표기 x좌표
			gagebar_y: 48,					//게이지 bar 표기 y좌표

		},
		{
			name: "COW III",					// 캐릭 이름
			filename: "ally_77",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 3,							//별몇개(1~8성),

			w: 159, h: 170,						// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: -200,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 27,						// 캐릭터 level 1일때의 attack power임
			ap_end: 135,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 192,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 528,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 40,					// 성장할 수 있는 최고 level

			center_gap_x: -20,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 48,					//게이지 bar 표기 x좌표
			gagebar_y: 32,					//게이지 bar 표기 y좌표

		},
		{
			name: "COW IV",					// 캐릭 이름
			filename: "ally_78",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 4,							//별몇개(1~8성),

			w: 229, h: 195,						// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 9,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: -200,		//  공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 83,					// 캐릭터 level 1일때의 attack power임
			ap_end: 545,					// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 460,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 910,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 50,					// 성장할 수 있는 최고 level
			center_gap_x: 25,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 48,					//게이지 bar 표기 x좌표
			gagebar_y: 46,					//게이지 bar 표기 y좌표

		},
		{
			name: "COW V",					// 캐릭 이름
			filename: "ally_79",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 5,							//별몇개(1~8성),

			w: 381, h: 261,					// 이미지의 크기 (width, height)
			move_frame_num: 7,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 7,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 2,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: -380,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 300,						// 캐릭터 level 1일때의 attack power임
			ap_end: 2250,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 810,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 1470,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 60,					// 성장할 수 있는 최고 level
			center_gap_x: 150,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 38,					//게이지 bar 표기 x좌표
			gagebar_y: 81,					//게이지 bar 표기 y좌표

		},
		{
			name: "COW VI",					// 캐릭 이름
			filename: "ally_80",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 6,							//별몇개(1~8성),

			w: 361, h: 292,						// 이미지의 크기 (width, height)
			move_frame_num: 9,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: -380,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 13000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3200,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 5000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 70,					// 성장할 수 있는 최고 level

			center_gap_x: 80,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 70,					//게이지 bar 표기 x좌표
			gagebar_y: 67,					//게이지 bar 표기 y좌표

		},
		{
			name: "COW VII",					// 캐릭 이름
			filename: "ally_81",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 7,							//별몇개(1~8성),

			w: 325, h: 271,						// 이미지의 크기 (width, height)
			move_frame_num: 9,				// 이동시 사용되는 frame의 수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: -280,		// 공격거리(attack_len)
			move_speed: MOVE_SPEED.HI,		// 체력(hp),이동거리(move_speed),
			attack_speed: ATTACK_SPEED.MI,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 1100,						// 캐릭터 level 1일때의 attack power임
			ap_end: 90000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 4950,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 9900,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 80,					// 성장할 수 있는 최고 level
			center_gap_x: 50,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 69,					//게이지 bar 표기 x좌표
			gagebar_y: 88,					//게이지 bar 표기 y좌표

		},


		
		{
			name: "DragonKnight Ace",					// 캐릭 이름
			filename: "ally_82",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 499, h: 464,						// 이미지의 크기 (width, height)

			move_frame_num: 12,				// 이동시 사용되는 frame의 수
			wait_frame_num: 12,				// 대기시 사용되는 frame의 수
			attack_frame_num: 13,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 7,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 7,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 400,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -120,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 330,		// 공격거리(attack_len),
			move_speed: 6,		// 체력(hp),이동거리(move_speed),
			attack_speed: 20,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 18750,						// 캐릭터 level 1일때의 attack power임
			ap_end: 1000000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 14000,					// 캐릭터 level 1일때의 hp
			hp_end: 1000000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 5500,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 10000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 9,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 40,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 207,					//게이지 bar 표기 x좌표
			gagebar_y: 80,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "Hyper Echo",					// 캐릭 이름
			filename: "ally_83",			// 캐릭터의 파일 이름.
			feature: FEATURE.SPEED,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 346, h: 240,						// 이미지의 크기 (width, height)
			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 14,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 11,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			attack_len: 1200,		// 공격거리(attack_len)

			attack_x: 270,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -50,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)

			move_speed: 7,		// 체력(hp),이동거리(move_speed),
			attack_speed: 40,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 33000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 500000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 12500,					// 캐릭터 level 1일때의 hp
			hp_end: 800000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3800,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 8000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 10,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 6,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 130,					//게이지 bar 표기 x좌표
			gagebar_y: 20,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "Planet Smartie",					// 캐릭 이름
			filename: "ally_84",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 258, h: 407,						// 이미지의 크기 (width, height)

			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 12,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 18,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 18,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -50,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)

			attack_len: 875,		// 공격거리(attack_len)
			move_speed: 2,		// 체력(hp),이동거리(move_speed),
			attack_speed: 40,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 14000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 320000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 12750,					// 캐릭터 level 1일때의 hp
			hp_end: 850000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 4000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 8000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			
			center_gap_x: -6,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 3,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 110,					//게이지 bar 표기 x좌표
			gagebar_y: 120,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "IronPaladin Khan",					// 캐릭 이름
			filename: "ally_85",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 610, h: 475,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 15,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 1,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 10,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 300,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: 100,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)

			attack_len: -300,		// 공격거리(attack_len)

			move_speed: 6,		// 체력(hp),이동거리(move_speed),
			attack_speed: 30,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 4750,						// 캐릭터 level 1일때의 attack power임
			ap_end: 40000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 180750,					// 캐릭터 level 1일때의 hp
			hp_end: 15552000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 9000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 15000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 35,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 22,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 220,					//게이지 bar 표기 x좌표
			gagebar_y: 200,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "IceQueen Lucy",					// 캐릭 이름
			filename: "ally_86",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 274, h: 326,						// 이미지의 크기 (width, height)

			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수

			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 8,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -100,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)

			attack_len: 950,		// 공격거리(attack_len)
			move_speed: 9,		// 체력(hp),이동거리(move_speed),
			attack_speed: 30,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 13000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 100000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 13800,					// 캐릭터 level 1일때의 hp
			hp_end: 900000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 6500,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			
			center_gap_x: -9,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 3,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 113,					//게이지 bar 표기 x좌표
			gagebar_y: 116,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "Idol Lucy",					// 캐릭 이름
			filename: "ally_87",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 284, h: 319,						// 이미지의 크기 (width, height)

			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 9,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 9,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -15,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 680,		// 공격거리(attack_len)
			move_speed: 14,		// 체력(hp),이동거리(move_speed),
			attack_speed: 10,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 12000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 420000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 18750,					// 캐릭터 level 1일때의 hp
			hp_end: 1100000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3800,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 9000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: -24,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 2,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 140,					//게이지 bar 표기 x좌표
			gagebar_y: 70,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "Reaper Bebee",					// 캐릭 이름
			filename: "ally_88",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 437, h: 487,						// 이미지의 크기 (width, height)
			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 14,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 10,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: 80,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 700,		// 공격거리(attack_len)
			move_speed: 6,		// 체력(hp),이동거리(move_speed),
			attack_speed: 40,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 240000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 18750,					// 캐릭터 level 1일때의 hp
			hp_end: 880000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 3800,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 8000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 10,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 5,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 170,					//게이지 bar 표기 x좌표
			gagebar_y: 160,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "Unicorn Ruby",					// 캐릭 이름
			filename: "ally_89",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 264, h: 299,						// 이미지의 크기 (width, height)
			move_frame_num: 7,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 8,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -200,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 280,		// 공격거리(attack_len)
			move_speed: 4,		// 체력(hp),이동거리(move_speed),
			attack_speed: 30,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 500000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 118750,					// 캐릭터 level 1일때의 hp
			hp_end: 900000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 7000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 12000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 6,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 8,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 90,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표

		},
		
		{
			name: "Zeus Goldman",					// 캐릭 이름
			filename: "ally_90",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 271, h: 359,						// 이미지의 크기 (width, height)
			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 8,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 8,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: -90,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 600,		// 공격거리(attack_len)
			move_speed: 3,		// 체력(hp),이동거리(move_speed),
			attack_speed: 60,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 400000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 18750,					// 캐릭터 level 1일때의 hp
			hp_end: 900000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 5500,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 8000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 1,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 4,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 92,					//게이지 bar 표기 x좌표
			gagebar_y: 50,					//게이지 bar 표기 y좌표

		},
		{
			name: "High Devil Gingerman",					// 캐릭 이름
			filename: "ally_91",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 360, h: 284,						// 이미지의 크기 (width, height)
			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 13,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 0,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: 40,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 280,		// 공격거리(attack_len)
			move_speed: 6,		// 체력(hp),이동거리(move_speed),
			attack_speed: 20,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 360000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 18750,					// 캐릭터 level 1일때의 hp
			hp_end: 900000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 5200,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 8500,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: -14,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 6,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 170,					//게이지 bar 표기 x좌표
			gagebar_y: -5,					//게이지 bar 표기 y좌표

		},
		{
			name: "NineTailed Fox Bensi",					// 캐릭 이름
			filename: "ally_92",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 235, h: 271,						// 이미지의 크기 (width, height)
			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 6,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 6,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: -227,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: 15,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 450,		// 공격거리(attack_len)
			move_speed: 2,		// 체력(hp),이동거리(move_speed),
			attack_speed: 20,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 360000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 18750,					// 캐릭터 level 1일때의 hp
			hp_end: 900000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 4400,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 8000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: -11,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 7,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 95,					//게이지 bar 표기 x좌표
			gagebar_y: 30,					//게이지 bar 표기 y좌표

		},
		{
			name: "Summoner Jey",					// 캐릭 이름
			filename: "ally_93",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 282, h: 392,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 12,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 당할때 사용되는 frame의 수

			fire_frame_num: 5,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 5,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 170,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: 170,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: 1200,		// 공격거리(attack_len)
			move_speed: 6,		// 체력(hp),이동거리(move_speed),
			attack_speed: 40,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 360000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 18750,					// 캐릭터 level 1일때의 hp
			hp_end: 760000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 7000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 13000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: -10,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 6,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 120,					//게이지 bar 표기 x좌표
			gagebar_y: 110,					//게이지 bar 표기 y좌표

		},
		{
			name: "DJ Koo",					// 캐릭 이름
			filename: "ally_94",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			star: 8,							//별몇개(1~8성),

			w: 376, h: 338,						// 이미지의 크기 (width, height)
			move_frame_num: 10,				// 이동시 사용되는 frame의 수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수
			attack_frame_num: 6,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 당할때 사용되는 frame의 수

			fire_frame_num: 1,				// 발사시 사용되는 frame의 수
			fire_img_frame_num: 1,			// 미사일 이미지 프레임수 (이미지 갯수 )
			attack_fire_frame: 2,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?

			attack_x: 50,				// Tọa độ x khi xuất chiêu ( frame đâu tiên)
			attack_y: 230,				// Tọa độ y khi xuất chiêu ( frame đâu tiên)
			
			attack_len: -280,		// 공격거리(attack_len)
			move_speed: 6,		// 체력(hp),이동거리(move_speed),
			attack_speed: 40,	// 공격속도임. 이 값은 tick값임  공격속도빠름(10), 보통(25), 느림(50) 정도를 잡으면 됨.

			ap_start: 16000,						// 캐릭터 level 1일때의 attack power임
			ap_end: 180000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 attack power임)

			hp_start: 1,					// 캐릭터 level 1일때의 hp
			hp_end: 1,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 hp임)

			nm_start: 10000,					// 캐릭터 level 1일때의 Need Mineral임
			nm_end: 20000,						// 캐릭터 level MAX(즉 1성인 경우 20일때의 Need Mineral임)

			max_level: 90,					// 성장할 수 있는 최고 level
			center_gap_x: 30,				// wait 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// wait 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			//yhlee 2016 06 22 추가
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가?  피격마진 이라 부른다.
			gagebar_x: 100,					//게이지 bar 표기 x좌표
			gagebar_y: 120,					//게이지 bar 표기 y좌표

		},


	];

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// 적군 캐릭터 정의
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//var ENEMY_MINUS1 = 0.8; //1~30까지의 캐릭의 능력치의 공격력,방어력을 80%로 줄인다.
//var ENEMY_MINUS1 = 1.6; //20170814_ywlee 조정함.
//var ENEMY_MINUS1 = 1.4; //20170824_ywlee 조정함.
//var ENEMY_MINUS1 = 1.2; //20170828_ywlee 조정함.
//var ENEMY_MINUS1 = 1.4; //20170830_ywlee 조정함.
//var ENEMY_MINUS1 = 1.5; //20170831_ywlee 조정함.
//var ENEMY_MINUS1 = 1.3; //20170925_ywlee 조정함.
//var ENEMY_MINUS1 = 1.1; //20171127_ywlee 조정함.
var ENEMY_MINUS1 = 0.8;   //20180105_ywlee 조정함.

var CHAR_YOUR_TEAM =
	[
		{},//연산편의를 위해 0번 배열은 사용하지 않음.
		{
			name: "1",						// 캐릭 번호 - 카드병정(파랑클로버)
			dirname: "enemy_1",				// 디렉토리 이름
			feature: FEATURE.ATTACK,			// 특징
			w: 109, h: 131,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6, //8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,	//6		// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4, //5,		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: Math.round(ENEMY_MINUS1 * 2), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 20),							// 체력(hp)
			missile_gap_x: -122,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 25,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 9,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 24,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표
		},
		{
			name: "2",						// 캐릭 이름 - 카드병정(검정 에이스)
			dirname: "enemy_2",				// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 109, h: 131,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6, //8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4, //5,		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 6), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 40),							// 체력(hp)
			missile_gap_x: -122,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 25,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 9,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 24,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표
		},
		{
			name: "3",						// 캐릭 이름 - 벌레몬1
			dirname: "enemy_3",				// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,          // 특징
			w: 61, h: 105,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 10), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 80),							// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: -1,					//게이지 bar 표기 x좌표
			gagebar_y: 8,					//게이지 bar 표기 y좌표
		},
		{
			name: "4",						// 캐릭 번호 - 카드병정(빨강 다이아몬드)
			dirname: "enemy_4",				// 디렉토리 이름
			feature: FEATURE.ATTACK,			// 특징
			w: 109, h: 131,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6, //8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4, //5,		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 18), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 100),							// 체력(hp)
			missile_gap_x: -122,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 25,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 9,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 24,					//게이지 bar 표기 x좌표
			gagebar_y: 0,					//게이지 bar 표기 y좌표
		},
		{
			name: "5",						// 캐릭 번호 - 문어탱1
			dirname: "enemy_5",				// 디렉토리 이름
			feature: FEATURE.WIDE,			// 특징
			w: 129, h: 165,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,			// 이동시 사용되는 frame의 수
			attack_frame_num: 8, //10,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 30),				// 공격력(attack_power),
			hp: Math.round(ENEMY_MINUS1 * 150), 						// 체력(hp)
			missile_gap_x: 57,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 6,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -6,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -6,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 49,					//게이지 bar 표기 x좌표
			gagebar_y: 20,					//게이지 bar 표기 y좌표
		},
		{
			name: "6",						// 캐릭 번호 - 카드병정(빨강 다이아몬드)
			dirname: "enemy_6",				// 디렉토리 이름
			feature: FEATURE.ATTACK,			// 특징
			w: 109, h: 131,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6, //8,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4, //5,		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.MI,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 55), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 200),							// 체력(hp)
			missile_gap_x: -122,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 25,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 9,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 25,					//게이지 bar 표기 x좌표
			gagebar_y: 4,					//게이지 bar 표기 y좌표
		},
		{
			name: "7",						// 캐릭 번호 - 젤몬1
			dirname: "enemy_7",				// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 109, h: 116,					// 이미지의 크기 (width, height)
			move_frame_num: 7, //9,			// 이동시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수 // Jell은 자기의무기가 따로 없다. 그래도 우선 7로 해서 해보자. 정아씨의 다양성을 구현하기 위해~~^^;
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 70), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 300),							// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			center_gap_x: -2,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -19,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			gagebar_x: 26,					//게이지 bar 표기 x좌표
			gagebar_y: 16,					//게이지 bar 표기 y좌표
		},
		{
			name: "8",						// 캐릭 번호 - 락맨1
			dirname: "enemy_8",				// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			w: 169, h: 143,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			attack_frame_num: 9, //11,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1, //1,		// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 100), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 1000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			center_gap_x: -22,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			gagebar_x: 76,					//게이지 bar 표기 x좌표
			gagebar_y: 2,					//게이지 bar 표기 y좌표
		},
		{
			name: "9",						// 캐릭 이름 - 벌레몬2
			dirname: "enemy_9",				// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,          // 특징
			w: 61, h: 105,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 100), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 500),							// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: -1,					//게이지 bar 표기 x좌표
			gagebar_y: 6,					//게이지 bar 표기 y좌표
		},
		{
			name: "10",						// 캐릭 번호 - 젤몬2
			dirname: "enemy_10",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 109, h: 116,					// 이미지의 크기 (width, height)
			move_frame_num: 7, //9,			// 이동시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수 // Jell은 자기의무기가 따로 없다. 그래도 우선 7로 해서 해보자. 정아씨의 다양성을 구현하기 위해~~^^;
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 150), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 1500),						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -2,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -19,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 26,					//게이지 bar 표기 x좌표
			gagebar_y: 16,					//게이지 bar 표기 y좌표
		},
		{
			name: "11",						// 캐릭 번호 - 문어탱2
			dirname: "enemy_11",			// 디렉토리 이름
			feature: FEATURE.WIDE,			// 특징
			w: 129, h: 165,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,			// 이동시 사용되는 frame의 수
			attack_frame_num: 8, //10,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 250),				// 공격력(attack_power),
			hp: Math.round(ENEMY_MINUS1 * 2500), 						// 체력(hp)
			missile_gap_x: 57,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 6,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -6,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -6,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 48,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표
		},
		{
			name: "12",						// 캐릭 번호 - 락맨2
			dirname: "enemy_12",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			w: 169, h: 143,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			attack_frame_num: 9, //11,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,			// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 300), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 6000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -22,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 76,					//게이지 bar 표기 x좌표
			gagebar_y: 2,					//게이지 bar 표기 y좌표
		},
		{
			name: "13",						// 캐릭 번호 - 젤몬3
			dirname: "enemy_13",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 109, h: 116,					// 이미지의 크기 (width, height)
			move_frame_num: 7, //9,			// 이동시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수 // Jell은 자기의무기가 따로 없다. 그래도 우선 7로 해서 해보자. 정아씨의 다양성을 구현하기 위해~~^^;
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 350), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 4000),						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -22,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 27,					//게이지 bar 표기 x좌표
			gagebar_y: 14,					//게이지 bar 표기 y좌표

		},
		{
			name: "14",						// 캐릭 번호 - 문어탱3
			dirname: "enemy_14",			// 디렉토리 이름
			feature: FEATURE.WIDE,			// 특징
			w: 129, h: 165,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,			// 이동시 사용되는 frame의 수
			attack_frame_num: 8, //10,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,			// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 400),				// 공격력(attack_power),
			hp: Math.round(ENEMY_MINUS1 * 5000), 						// 체력(hp)
			missile_gap_x: 57,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 6,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -6,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -6,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 47,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표

		},
		{
			name: "15",						// 캐릭 번호 - 락맨3
			dirname: "enemy_15",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			w: 169, h: 143,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,			// 이동시 사용되는 frame의 수
			attack_frame_num: 9, //11,		// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,			// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 450), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 9000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -22,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 76,					//게이지 bar 표기 x좌표
			gagebar_y: 2,					//게이지 bar 표기 y좌표

		},
		{
			name: "16",						// 캐릭 이름 - 벌레몬3
			dirname: "enemy_16",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,          // 특징
			w: 61, h: 105,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 500), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 6000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: -1,					//게이지 bar 표기 x좌표
			gagebar_y: 8,					//게이지 bar 표기 y좌표

		},
		{
			name: "17",						// 캐릭 이름 - 유령몬1
			dirname: "enemy_17",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 91, h: 152,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 600), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 8000),						// 체력(hp)
			missile_gap_x: -218,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 32,				// 캐릭터 미사일 발사 y좌표
			center_gap_x: -1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -14,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 16,					//게이지 bar 표기 x좌표
			gagebar_y: 35,					//게이지 bar 표기 y좌표

		},
		{
			name: "18",						// 캐릭 이름 - 벌레몬4
			dirname: "enemy_18",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,          // 특징
			w: 61, h: 105,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 700), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 8000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: -1,					//게이지 bar 표기 x좌표
			gagebar_y: 8,					//게이지 bar 표기 y좌표

		},
		{
			name: "19",						// 캐릭 이름 - 유령몬2
			dirname: "enemy_19",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 91, h: 152,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 800), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 10000),						// 체력(hp)
			missile_gap_x: -218,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 32,				// 캐릭터 미사일 발사 y좌표
			center_gap_x: -1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -14,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 16,					//게이지 bar 표기 x좌표
			gagebar_y: 35,					//게이지 bar 표기 y좌표

		},
		{
			name: "20",						// 캐릭 번호 - 젤몬4
			dirname: "enemy_20",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 109, h: 116,					// 이미지의 크기 (width, height)
			move_frame_num: 7, //9,			// 이동시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수 // Jell은 자기의무기가 따로 없다. 그래도 우선 7로 해서 해보자. 정아씨의 다양성을 구현하기 위해~~^^;
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 900), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 20000),						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -2,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -19,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.

			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 26,					//게이지 bar 표기 x좌표
			gagebar_y: 16,					//게이지 bar 표기 y좌표
		},
		{
			name: "21",						// 캐릭 번호 - 문어탱4
			dirname: "enemy_21",			// 디렉토리 이름
			feature: FEATURE.WIDE,			// 특징
			w: 129, h: 165,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8, //10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 1000),				// 공격력(attack_power),
			hp: Math.round(ENEMY_MINUS1 * 15000), 						// 체력(hp)
			missile_gap_x: 57,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 6,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -6,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -6,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 48,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표

		},
		{
			name: "22",						// 캐릭 번호 - 락맨4
			dirname: "enemy_22",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			w: 169, h: 143,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9, //11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 2000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 60000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -22,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 76,					//게이지 bar 표기 x좌표
			gagebar_y: 2,					//게이지 bar 표기 y좌표

		},
		{
			name: "23",						// 캐릭 이름 - 유령몬3
			dirname: "enemy_23",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 91, h: 152,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.MI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 3000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 80000),						// 체력(hp)
			missile_gap_x: -218,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 32,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -14,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 16,					//게이지 bar 표기 x좌표
			gagebar_y: 35,					//게이지 bar 표기 y좌표

		},
		{
			name: "24",						// 캐릭 이름 - 눈사람몬1
			dirname: "enemy_24",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 204, h: 217,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7, //8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.HI,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 5000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 90000),						// 체력(hp)
			missile_gap_x: -218,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 32,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -46,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -34,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 122,					//게이지 bar 표기 x좌표
			gagebar_y: 70,					//게이지 bar 표기 y좌표

		},
		{
			name: "25",						// 캐릭 이름 - 벌레몬5
			dirname: "enemy_25",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,          // 특징
			w: 61, h: 105,						// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.MI,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.HI,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 8000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 100000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 1,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: -1,					//게이지 bar 표기 x좌표
			gagebar_y: 8,					//게이지 bar 표기 y좌표
		},
		{
			name: "26",						// 캐릭 번호 - 젤몬5
			dirname: "enemy_26",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 109, h: 116,					// 이미지의 크기 (width, height)
			move_frame_num: 7, //9,			// 이동시 사용되는 frame의 수
			attack_frame_num: 10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수 // Jell은 자기의무기가 따로 없다. 그래도 우선 7로 해서 해보자. 정아씨의 다양성을 구현하기 위해~~^^;
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.LO,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 10000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 140000),						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -2,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -19,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 26,					//게이지 bar 표기 x좌표
			gagebar_y: 16,					//게이지 bar 표기 y좌표

		},
		{
			name: "27",						// 캐릭 번호 - 문어탱5
			dirname: "enemy_27",			// 디렉토리 이름
			feature: FEATURE.WIDE,			// 특징
			w: 129, h: 165,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8, //10,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VL,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VH,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 10000),				// 공격력(attack_power),
			hp: Math.round(ENEMY_MINUS1 * 100000), 						// 체력(hp)
			missile_gap_x: 57,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 6,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -6,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -6,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 48,					//게이지 bar 표기 x좌표
			gagebar_y: 21,					//게이지 bar 표기 y좌표
		},
		{
			name: "28",						// 캐릭 번호 - 락맨5
			dirname: "enemy_28",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			w: 169, h: 143,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9, //11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.LO,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 25000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 250000),						// 체력(hp)
			missile_gap_x: 21,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -22,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 85,				//게이지 bar 표기 x좌표
			gagebar_y: 2,					//게이지 bar 표기 y좌표

		},
		{
			name: "29",						// 캐릭 이름 - 눈사람몬2
			dirname: "enemy_29",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 204, h: 217,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7, //8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.HI,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 50000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 300000),						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -46,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -34,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 122,				//게이지 bar 표기 x좌표
			gagebar_y: 70,					//게이지 bar 표기 y좌표

		},
		{
			name: "30",						// 캐릭 이름 - 눈사람몬3
			dirname: "enemy_30",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 204, h: 217,						// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7, //8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동 속도, very high
			attack_speed: E_ATTACK_SPEED.HI,	// 공격속도임 보통(MI)
			attack_len: ATTACK_LEN.VL,		// 공격거리(attack_len),

			attack_power: Math.round(ENEMY_MINUS1 * 70000), 				// 공격력(attack_power)
			hp: Math.round(ENEMY_MINUS1 * 350000),						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -46,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -34,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 122,				//게이지 bar 표기 x좌표
			gagebar_y: 74,					//게이지 bar 표기 y좌표

		},



		//2016.06.08  yhlee 적군 케릭 추가
		//타입을 정하기 전까지 모든 케릭 적군 케릭 1번인 파랑 카드 변정을 기준으로 해서 작성하였다.
		{
			name: "31",						// 캐릭 이름 - 설인 1
			dirname: "enemy_31",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,			// 특징
			w: 309, h: 288,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,			// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.HI,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL - 30,		// 공격거리

			attack_power: 70000, 				// 공격력(attack_power)
			hp: 500000,							// 체력(hp)

			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 55,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 107,					//게이지 bar 표기 x좌표
			gagebar_y: 94,					//게이지 bar 표기 y좌표

		},
		{
			name: "32",						// 캐릭 이름 - 고슴도치 1
			dirname: "enemy_32",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 130, h: 175,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //7,				// 이동시 사용되는 frame의 수
			attack_frame_num: 5,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6,//8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VH,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: 70000, 				// 공격력(attack_power)
			hp: 300000,							// 체력(hp)
			missile_gap_x: -180,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 50,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -30,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 28,					//게이지 bar 표기 x좌표
			gagebar_y: 71,					//게이지 bar 표기 y좌표

		},
		{
			name: "33",						// 캐릭 이름 - 고슴도치 2
			dirname: "enemy_33",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 145, h: 192,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //7,			// 이동시 사용되는 frame의 수
			attack_frame_num: 5,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 7,		//5		// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VH * 1.5,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: 80000, 				// 공격력(attack_power)
			hp: 350000,							// 체력(hp)
			missile_gap_x: -200,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 50,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -30,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 41,					//게이지 bar 표기 x좌표
			gagebar_y: 72,					//게이지 bar 표기 y좌표

		},
		{
			name: "34",						// 캐릭 이름 - 설인 2
			dirname: "enemy_34",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 320, h: 329,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,			// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 10,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.HI,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.MI,		// 공격거리

			attack_power: 85000, 				// 공격력(attack_power)
			hp: 600000,							// 체력(hp)
			missile_gap_x: -20,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -70,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -30,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 60,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 107,					//게이지 bar 표기 x좌표
			gagebar_y: 117,					//게이지 bar 표기 y좌표

		},
		{
			// 20220707_dblee 김정아 차장님의 요청으로 능력치 일부를 LG와 동일하게 바꿈.
			name: "35",						// 캐릭 이름 - 고슴도치 3
			dirname: "enemy_35",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징 //KT에서 wide형 -> ATTACK형 변경
			w: 196, h: 269,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //7,			// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 7,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VH,		// 이동속도  E_MOVE_SPEED.VH*2 -> E_MOVE_SPEED.VH
			attack_speed: E_ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: 55000, 				// 공격력(attack_power)  90000-> 55000
			hp: 400000,							// 체력(hp)
			missile_gap_x: -180,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 160,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -50,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 69,					//게이지 bar 표기 x좌표
			gagebar_y: 118,					//게이지 bar 표기 y좌표

		},
		{
			name: "36",						// 캐릭 이름 - 설인 3
			dirname: "enemy_36",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 372, h: 374,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //8,			// 이동시 사용되는 frame의 수
			attack_frame_num: 16,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 10, //8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 11,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.HI,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH,		// 공격거리

			attack_power: 95000, 				// 공격력(attack_power)
			hp: 700000,							// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 30,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -30,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 60,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 131,					//게이지 bar 표기 x좌표
			gagebar_y: 122,					//게이지 bar 표기 y좌표

		},
		{
			name: "37",						// 캐릭 이름 - 거북이 1
			dirname: "enemy_37",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 150, h: 144,					// 이미지의 크기 (width, height)
			move_frame_num: 8, //16,			// 이동시 사용되는 frame의 수
			attack_frame_num: 12,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 90000, 				// 공격력(attack_power)
			hp: 550000,							// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 38,					//게이지 bar 표기 x좌표
			gagebar_y: 39,					//게이지 bar 표기 y좌표

		},
		{
			name: "38",						// 캐릭 이름 - 드래곤 1
			dirname: "enemy_38",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 228, h: 198,					// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.MI,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: Math.floor(105000 * 1.1), 				// 공격력(attack_power)
			hp: 800000 * 1.1,							// 체력(hp)
			missile_gap_x: -100,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 100,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 44,					//게이지 bar 표기 x좌표
			gagebar_y: 20,					//게이지 bar 표기 y좌표

		},
		//이후 부터는 121 스테이지 부터 등장함.
		{
			name: "39",						// 캐릭 이름 - 거북이 2
			dirname: "enemy_39",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 210, h: 144,					// 이미지의 크기 (width, height)
			move_frame_num: 8, //16,			// 이동시 사용되는 frame의 수
			attack_frame_num: 12,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,			// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리 // 20180219_ywlee 레벨링을 위해 조정

			attack_power: Math.floor(121000 * 1.3), 	// 공격력(attack_power)// 20180219_ywlee 레벨링을 위해 조정
			hp: 800000 * 1.1,				// 체력(hp)//1.3 -> 1.1 yhlee
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 67,					//게이지 bar 표기 x좌표
			gagebar_y: 32,					//게이지 bar 표기 y좌표

		},
		{
			name: "40",						// 캐릭 이름 - 드래곤 2
			dirname: "enemy_40",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 231, h: 212,					// 이미지의 크기 (width, height)
			move_frame_num: 5, //6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 10,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3, //5,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.HI,		// 이동속도
			attack_speed: E_ATTACK_SPEED.MI,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: Math.floor(110000 * 1.1), 				// 공격력(attack_power)//1.3 -> 1.1 yhlee
			hp: 1000000 * 1.1,							// 체력(hp)//1.3 -> 1.1 yhlee
			missile_gap_x: -150,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 50,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 60,					//게이지 bar 표기 x좌표
			gagebar_y: 19,					//게이지 bar 표기 y좌표

		},
		{
			name: "41",						// 캐릭 이름 - 거북이 3
			dirname: "enemy_41",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 236, h: 200,					// 이미지의 크기 (width, height)
			move_frame_num: 8, //16,				// 이동시 사용되는 frame의 수
			attack_frame_num: 11,			// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH + 10,		// 공격거리

			attack_power: Math.floor(121000 * 1.3), 				// 공격력(attack_power)//1.3 -> 1.1 yhlee
			hp: 900000 * 1.1,							// 체력(hp)//1.3 -> 1.1 yhlee
			missile_gap_x: 70,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -30,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 83,					//게이지 bar 표기 x좌표
			gagebar_y: 52,					//게이지 bar 표기 y좌표

		},

		{
			name: "42",						// 캐릭 이름 - 드래곤 3
			dirname: "enemy_42",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 320, h: 491,					// 이미지의 크기 (width, height)
			move_frame_num: 4, //8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 24,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.VH,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.HI,		// 공격거리

			attack_power: Math.floor(140000 * 1.1), 				// 공격력(attack_power)//1.3 -> 1.1 yhlee
			hp: 1100000 * 1.1,							// 체력(hp)//1.3 -> 1.1 yhlee
			missile_gap_x: -300,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 70,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -100,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 79,					//게이지 bar 표기 x좌표
			gagebar_y: 262,					//게이지 bar 표기 y좌표

		},

		//이후 부터는 141 stage 부터 나옴
		{
			name: "43",						// 캐릭 이름 - 나즈굴 1
			dirname: "enemy_43",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 210, h: 154,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 10,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: E_MOVE_SPEED.LO,		// 이동속도
			attack_speed: E_ATTACK_SPEED.MI,	// 공격속도
			attack_len: ATTACK_LEN.VH * 1.4,		// 공격거리

			attack_power: Math.floor(170000 * 1.1), 				// 공격력(attack_power) //1.5 --> 1.3  20170919_ywlee//1.3 -> 1.1 yhlee
			hp: 1200000 * 1.1,							// 체력(hp) //1.5 --> 1.2   20170919_ywlee//1.2 -> 1.1 yhlee
			// hp:1,							// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 80,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 84,					//게이지 bar 표기 x좌표
			gagebar_y: -1,					//게이지 bar 표기 y좌표

		},
		{
			name: "44",						// 캐릭 이름 - 트롤 1
			dirname: "enemy_44",			// 캐릭터의 파일 이름.
			feature: FEATURE.HP,				// 특징
			w: 193, h: 167,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH * 2,		// 이동속도
			attack_speed: E_ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			// attack_power:Math.floor(170000*100), 				// 공격력(attack_power)
			//20191001_yhlee 아이템 추가로 인하여 트롤의 공격력을 원샷원킬나도록 합니다.
			attack_power: 170000 * 100000, 				// 공격력(attack_power)
			hp: 1500000 * 1.1,							// 체력(hp)//1.3 -> 1.1 yhlee
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -30,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 80,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 90,					//게이지 bar 표기 x좌표
			gagebar_y: -4,					//게이지 bar 표기 y좌표

		},
		{
			name: "45",						// 캐릭 이름 - 나즈굴 2
			dirname: "enemy_45",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 238, h: 167,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 10,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.LO,		// 이동속도
			attack_speed: ATTACK_SPEED.VL * 2,	// 공격속도
			attack_len: ATTACK_LEN.VH * 1.2,		// 공격거리//1.5 -> 1.2 yhlee

			attack_power: Math.floor(150000 * 1.0), 				// 공격력(attack_power)//190000*1.5 -> 150000*1.0 yhlee
			hp: 1400000 * 1.1,							// 체력(hp)//1.5 -> 1.1 yhlee
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -30,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 80,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 104,					//게이지 bar 표기 x좌표
			gagebar_y: 6,					//게이지 bar 표기 y좌표

		},
		{
			name: "46",						// 캐릭 이름 - 트롤 2
			dirname: "enemy_46",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 224, h: 178,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6,//8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH * 2,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			// attack_power:Math.floor(190000*100), 				// 공격력(attack_power)
			//20191001_yhlee 아이템 추가로 인하여 트롤의 공격력을 원샷원킬나도록 합니다.
			attack_power: 190000 * 100000, 				// 공격력(attack_power)
			hp: 1800000 * 1.1,							// 체력(hp)//1.3 -> 1.1 yhlee
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -30,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 111,					//게이지 bar 표기 x좌표
			gagebar_y: -11,					//게이지 bar 표기 y좌표

		},
		{
			name: "47",						// 캐릭 이름 - 나즈굴 3
			dirname: "enemy_47",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 265, h: 183,					// 이미지의 크기 (width, height)
			move_frame_num: 6, //12,				// 이동시 사용되는 frame의 수
			attack_frame_num: 10,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6, //8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 8,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.LO,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH * 1.5,		// 공격거리//1.6 -> 1.5 yhlee

			attack_power: Math.floor(170000 * 1.0), 				// 공격력(attack_power)//210000*1.5 -> 170000 * 1.0 yhlee
			hp: 1600000 * 1.1,							// 체력(hp)//1.5 -> 1.1 yhlee
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -30,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 90,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 123,					//게이지 bar 표기 x좌표
			gagebar_y: -1,					//게이지 bar 표기 y좌표

		},
		//===-----------------------------------------==현재 여기까지가 160 stage까지임
		{
			name: "48",						// 캐릭 이름 - 트롤3
			dirname: "enemy_48",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 275, h: 199,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH * 1.4,	// 이동속도
			attack_speed: ATTACK_SPEED.MI,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			// attack_power:200000*100, 				// 공격력(attack_power)
			//20191001_yhlee 아이템 추가로 인하여 트롤의 공격력을 원샷원킬나도록 합니다.
			attack_power: 200000 * 100000, 				// 공격력(attack_power)
			hp: 2100000 * 1.5,							// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -30,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 130,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 139,					//게이지 bar 표기 x좌표
			gagebar_y: -12,					//게이지 bar 표기 y좌표

		},
		{
			name: "49",						// 캐릭 이름 - 해골 1
			dirname: "enemy_49",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 309, h: 305,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.MI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 1.5,		// 공격거리

			attack_power: 220000 * 1.5,		// 공격력(attack_power)
			hp: 2000000 * 1.5,							// 체력(hp)
			missile_gap_x: 120,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 20,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -10,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -50,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 154,					//게이지 bar 표기 x좌표
			gagebar_y: 114,					//게이지 bar 표기 y좌표

		},
		{
			name: "50",						// 캐릭 이름 - 좀비 1
			dirname: "enemy_50",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 142, h: 196,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 2,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.HI,	// 공격속도
			attack_len: ATTACK_LEN.VH,		// 공격거리

			attack_power: 240000, 				// 공격력(attack_power)
			hp: 2400000 * 2.0,							// 체력(hp)
			missile_gap_x: -310,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 70,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 61,					//게이지 bar 표기 x좌표
			gagebar_y: -5,					//게이지 bar 표기 y좌표

		},
		{
			name: "51",						// 캐릭 이름 - 해골 2
			dirname: "enemy_51",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 387, h: 372,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.HI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 1.7,		// 공격거리

			attack_power: 250000 * 1.5,				// 공격력(attack_power)
			hp: 2500000 * 1.5,							// 체력(hp)
			missile_gap_x: 120,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 20,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: -10,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -80,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 130,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 195,					//게이지 bar 표기 x좌표
			gagebar_y: 162,					//게이지 bar 표기 y좌표

		},
		{
			name: "52",						// 캐릭 이름 - 좀비 2
			dirname: "enemy_52",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 199, h: 209,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 2,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH,		// 공격거리

			attack_power: 260000, 				// 공격력(attack_power)
			hp: 2600000 * 2.0,							// 체력(hp)
			missile_gap_x: -443,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 78,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 10,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 75,					//게이지 bar 표기 x좌표
			gagebar_y: -2,					//게이지 bar 표기 y좌표

		},
		{
			name: "53",						// 캐릭 이름 - 해골 3
			dirname: "enemy_53",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 342, h: 354,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.0,		// 공격거리

			attack_power: 270000 * 1.5,		// 공격력(attack_power)
			hp: 2700000 * 1.5,					// 체력(hp)
			missile_gap_x: 120,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 20,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: -60,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 156,					//게이지 bar 표기 x좌표
			gagebar_y: 128,					//게이지 bar 표기 y좌표
		},
		//-------------------180 스테이지----------------------------------------------
		{
			name: "54",						// 캐릭 이름 - 좀비 3
			dirname: "enemy_54",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 249, h: 216,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 2,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH,		// 공격거리

			attack_power: 280000, 				// 공격력(attack_power)
			hp: 2800000 * 2.0,							// 체력(hp)
			missile_gap_x: -683,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -140,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 20,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 20,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 76,					//게이지 bar 표기 x좌표
			gagebar_y: -4,					//게이지 bar 표기 y좌표

		},
		{
			name: "55",						// 캐릭 이름 - 인어 1
			dirname: "enemy_55",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 130, h: 146,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH * 5,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.MI,		// 공격거리

			attack_power: 2000000 * 3, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 3000000 * 3,							// 체력(hp)
			missile_gap_x: 150,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -50,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 29,					//게이지 bar 표기 x좌표
			gagebar_y: 14,					//게이지 bar 표기 y좌표

		},
		{
			name: "56",						// 캐릭 이름 - 문어 1
			dirname: "enemy_56",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 241,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.LO,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2,		// 공격거리

			attack_power: 400000, 				// 공격력(attack_power)
			hp: 3100000,							// 체력(hp)
			missile_gap_x: 50,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 130,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 107,					//게이지 bar 표기 x좌표
			gagebar_y: 33,					//게이지 bar 표기 y좌표

		},
		{
			name: "57",						// 캐릭 이름 - 인어 2
			dirname: "enemy_57",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 145, h: 159,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH * 6,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.HI,		// 공격거리

			attack_power: 3000000 * 3, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 4000000 * 3,							// 체력(hp)
			missile_gap_x: 150,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -60,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 37,					//게이지 bar 표기 x좌표
			gagebar_y: 16,					//게이지 bar 표기 y좌표

		},
		{
			name: "58",						// 캐릭 이름 - 문어 2
			dirname: "enemy_58",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 264, h: 240,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 9,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.LO,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.1,		// 공격거리

			attack_power: 700000, 				// 공격력(attack_power)
			// attack_power:1000, 				// 공격력(attack_power)
			hp: 3500000,							// 체력(hp)
			missile_gap_x: 220,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 50,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 111,					//게이지 bar 표기 x좌표
			gagebar_y: 32,					//게이지 bar 표기 y좌표

		},
		{
			name: "59",						// 캐릭 이름 - 인어 3
			dirname: "enemy_59",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 202, h: 210,					// 이미지의 크기 (width, height)
			move_frame_num: 4,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH * 7,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH,		// 공격거리

			attack_power: 4000000 * 3, 				// 공격력(attack_power)
			// attack_power:2, 				// 공격력(attack_power)
			hp: 5000000 * 3,							// 체력(hp)
			missile_gap_x: 150,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -60,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 50,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 73,					//게이지 bar 표기 x좌표
			gagebar_y: 20,					//게이지 bar 표기 y좌표

		},
		{
			name: "60",						// 캐릭 이름 - 문어 3
			dirname: "enemy_60",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 264, h: 263,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 13,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.LO,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.2,		// 공격거리

			// attack_power:1500000*3, 				// 공격력(attack_power)
			// hp:5000000*3,							// 체력(hp)
			//20200406_yhlee 하드모드 난이도 조정
			attack_power: 1500000 * 2, 				// 공격력(attack_power)
			hp: 5000000 * 2,							// 체력(hp)
			missile_gap_x: -1130,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -200,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 10,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 118,					//게이지 bar 표기 x좌표
			gagebar_y: 14,					//게이지 bar 표기 y좌표

		},
		//20200424_yhlee 201스테이지 추가로 인하여 적군들을 선언합니다
		//하드모드가 위의 능력치의 6배를 하였다 201스테이지는 하드모드 200을 지나온것이기때문에.
		//6배수치보다 높아야한다.
		//201~
		{
			name: "61",						// 캐릭 이름 - 스컬독
			dirname: "enemy_61",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 153, h: 154,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.MI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.5,		// 공격거리

			attack_power: 9300000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 32000000,						// 체력(hp)
			missile_gap_x: -774,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -98,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 42,					//게이지 bar 표기 x좌표
			gagebar_y: 7,					//게이지 bar 표기 y좌표

		},
		{
			name: "62",						// 캐릭 이름 - 시크릿
			dirname: "enemy_62",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 124, h: 121,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.MI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.LO,		// 공격거리

			attack_power: 6000000, 				// 공격력(attack_power)
			hp: 40000000,						// 체력(hp)
			missile_gap_x: -163,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -7,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 39,					//게이지 bar 표기 x좌표
			gagebar_y: 5,					//게이지 bar 표기 y좌표

		},
		{
			name: "63",						// 캐릭 이름 - 중형 스컬독
			dirname: "enemy_63",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 178, h: 182,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 7,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.5,		// 공격거리

			attack_power: 9600000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 36000000,						// 체력(hp)
			missile_gap_x: -834,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -31,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 51,					//게이지 bar 표기 x좌표
			gagebar_y: 14,					//게이지 bar 표기 y좌표

		},
		{
			name: "64",						// 캐릭 이름 - 원통 시크릿
			dirname: "enemy_64",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 163, h: 135,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.MI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.HI,		// 공격거리

			attack_power: 8000000, 				// 공격력(attack_power)
			hp: 42000000,						// 체력(hp)
			missile_gap_x: -375,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -197,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 59,					//게이지 bar 표기 x좌표
			gagebar_y: 2,					//게이지 bar 표기 y좌표

		},
		{
			name: "65",						// 캐릭 이름 - 대형 스컬독
			dirname: "enemy_65",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 215, h: 185,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.5,		// 공격거리

			attack_power: 10000000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 38000000,						// 체력(hp)
			missile_gap_x: -795,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -66,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 67,					//게이지 bar 표기 x좌표
			gagebar_y: 10,					//게이지 bar 표기 y좌표

		},
		{
			name: "66",						// 캐릭 이름 - 상자 시크릿
			dirname: "enemy_66",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 195, h: 175,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.MI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2,		// 공격거리

			attack_power: 10000000, 				// 공격력(attack_power)
			// attack_power:0, 				// 공격력(attack_power)
			hp: 45000000,						// 체력(hp)
			missile_gap_x: 130,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -180,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 72,					//게이지 bar 표기 x좌표
			gagebar_y: 29,					//게이지 bar 표기 y좌표

		},
		//보스 스테이지에 추가할 보스 패턴 4마리 보스는 같으나 패턴이 다르기에 4마리로 추가합니다
		{
			name: "67",						// 캐릭 이름 - 201~ 220 보스 1번  공격 1패턴
			dirname: "enemy_67",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 740, h: 568,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 3,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 15000000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 100000000,						// 체력(hp)
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 330,					//게이지 bar 표기 x좌표
			gagebar_y: 144,					//게이지 bar 표기 y좌표
		},
		{
			name: "68",						// 캐릭 이름 - 201~ 220 보스 1번  공격 2패턴
			dirname: "enemy_68",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 740, h: 568,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 6,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 5,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.5,		// 공격거리

			attack_power: 15000000, 				// 공격력(attack_power)
			hp: 100000000,						// 체력(hp)
			missile_gap_x: -142,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 80,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 330,					//게이지 bar 표기 x좌표
			gagebar_y: 144,					//게이지 bar 표기 y좌표

		},
		{
			name: "69",						// 캐릭 이름 - 201~ 220 보스 1번  공격 3패턴
			dirname: "enemy_69",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 740, h: 568,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 5,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.5,		// 공격거리

			attack_power: 15000000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 100000000,						// 체력(hp)
			missile_gap_x: -142,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 80,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 330,					//게이지 bar 표기 x좌표
			gagebar_y: 144,					//게이지 bar 표기 y좌표

		},
		{
			name: "70",						// 캐릭 이름 - 201~ 220 보스 1번  공격 4패턴
			dirname: "enemy_70",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 740, h: 568,					// 이미지의 크기 (width, height)
			move_frame_num: 6,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 3,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2.4,		// 공격거리

			attack_power: 15000000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 100000000,						// 체력(hp)
			missile_gap_x: -838,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 29,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 330,					//게이지 bar 표기 x좌표
			gagebar_y: 144,					//게이지 bar 표기 y좌표

		},
		//221~
		//20210222_yhlee 240스테이지 추가
		{
			name: "71",						// 캐릭 이름 - 핑크젤리
			dirname: "enemy_71",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 425, h: 282,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.HI,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 13000000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 40000000,						// 체력(hp)
			missile_gap_x: -155,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 69,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 232,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 277,					//게이지 bar 표기 x좌표
			gagebar_y: 84,					//게이지 bar 표기 y좌표

		},
		{
			name: "72",						// 캐릭 이름 - 프로그
			dirname: "enemy_72",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 210, h: 157,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 7,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.MI,	// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 16000000, 				// 공격력(attack_power)
			// attack_power:1, 				// 공격력(attack_power)
			hp: 50000000,						// 체력(hp)
			missile_gap_x: -155,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 69,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 109,					//게이지 bar 표기 x좌표
			gagebar_y: -4,					//게이지 bar 표기 y좌표

		},
		{
			name: "73",						// 캐릭 이름 - 옐로우 젤리
			dirname: "enemy_73",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 510, h: 283,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 6,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 4,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 20000000, 				// 공격력(attack_power)
			hp: 55000000,						// 체력(hp)
			missile_gap_x: -155,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 69,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 10,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 300,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 325,					//게이지 bar 표기 x좌표
			gagebar_y: 62,					//게이지 bar 표기 y좌표

		},
		{
			name: "74",						// 캐릭 이름 - 네온 프로그
			dirname: "enemy_74",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 250, h: 185,					// 이미지의 크기 (width, height)
			move_frame_num: 7,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 6,				// 대기시 사용되는 frame의 수

			fire_frame_num: 5,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH + 50,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.HI,		// 공격거리

			attack_power: 25000000, 				// 공격력(attack_power)
			hp: 65000000,						// 체력(hp)
			missile_gap_x: 3,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 69,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 123,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 138,					//게이지 bar 표기 x좌표
			gagebar_y: 1,					//게이지 bar 표기 y좌표

		},
		{
			name: "75",						// 캐릭 이름 - 블루젤리
			dirname: "enemy_75",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 283, h: 283,					// 이미지의 크기 (width, height)
			move_frame_num: 5,				// 이동시 사용되는 frame의 수
			attack_frame_num: 9,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 4,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VH * 2,		// 공격거리

			attack_power: 35000000, 				// 공격력(attack_power)
			hp: 80000000,						// 체력(hp)
			missile_gap_x: 218,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 100,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 114,					//게이지 bar 표기 x좌표
			gagebar_y: 28,					//게이지 bar 표기 y좌표

		},
		{
			name: "76",						// 캐릭 이름 - 미치광이 프로그
			dirname: "enemy_76",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 400, h: 274,					// 이미지의 크기 (width, height)
			move_frame_num: 7,				// 이동시 사용되는 frame의 수
			attack_frame_num: 8,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 4,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 5,				// 대기시 사용되는 frame의 수

			fire_frame_num: 3,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 6,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: MOVE_SPEED.VH + 50,		// 이동속도
			attack_speed: ATTACK_SPEED.VH,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 50000000, 				// 공격력(attack_power)
			hp: 120000000,						// 체력(hp)
			missile_gap_x: -155,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 69,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 177,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 176,					//게이지 bar 표기 x좌표
			gagebar_y: 34,					//게이지 bar 표기 y좌표

		},
		{
			name: "77",						// 캐릭 이름 - 221~ 240 에 등장하는 가운데 서있는 석상
			dirname: "enemy_77",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 173, h: 493,					// 이미지의 크기 (width, height)
			move_frame_num: 1,				// 이동시 사용되는 frame의 수
			attack_frame_num: 1,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 1,				// 대기시 사용되는 frame의 수

			fire_frame_num: 1,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 0,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 0, 				// 공격력(attack_power)
			// hp:2000000000,							// 체력(hp)
			//20210810_yhlee 석상 밸런스를 조정합니다. HP 70% 하양조정
			hp: 140000000,							// 체력(hp)  // 20211119_dblee 1/10로 조정함.
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 12,					//게이지 bar 표기 x좌표
			gagebar_y: -15,					//게이지 bar 표기 y좌표

		},
		{
			name: "78",						// 캐릭 이름 - 221~ 240 에 등장하는 가운데 서있는 석상
			dirname: "enemy_78",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 200, h: 503,					// 이미지의 크기 (width, height)
			move_frame_num: 1,				// 이동시 사용되는 frame의 수
			attack_frame_num: 1,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 1,				// 대기시 사용되는 frame의 수

			fire_frame_num: 1,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 0,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 0, 				// 공격력(attack_power)
			// hp:3000000000,							// 체력(hp)
			//20210810_yhlee 석상 밸런스를 조정합니다. HP 70% 하양조정
			hp: 210000000,							// 체력(hp) // 20211119_dblee 1/10로 조정함.
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 25,					//게이지 bar 표기 x좌표
			gagebar_y: -22,					//게이지 bar 표기 y좌표

		},
		{
			name: "79",						// 캐릭 이름 - 221~ 240 에 등장하는 가운데 서있는 석상
			dirname: "enemy_79",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 229, h: 496,					// 이미지의 크기 (width, height)
			move_frame_num: 1,				// 이동시 사용되는 frame의 수
			attack_frame_num: 1,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 1,				// 대기시 사용되는 frame의 수

			fire_frame_num: 1,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 0,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 0, 				// 공격력(attack_power)
			// hp:4000000000,							// 체력(hp)
			//20210810_yhlee 석상 밸런스를 조정합니다. HP 70% 하양조정
			hp: 280000000,							// 체력(hp) // 20211119_dblee 1/10로 조정함.
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 40,					//게이지 bar 표기 x좌표
			gagebar_y: -23,					//게이지 bar 표기 y좌표

		},
		{
			name: "80",						// 캐릭 이름 - 221~ 240 에 등장하는 가운데 서있는 석상
			dirname: "enemy_80",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 225, h: 491,					// 이미지의 크기 (width, height)
			move_frame_num: 1,				// 이동시 사용되는 frame의 수
			attack_frame_num: 1,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 1,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 1,				// 대기시 사용되는 frame의 수

			fire_frame_num: 1,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 1,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 0,		// 이동속도
			attack_speed: ATTACK_SPEED.VL,	// 공격속도
			attack_len: ATTACK_LEN.VL,		// 공격거리

			attack_power: 0, 				// 공격력(attack_power)
			// hp:5000000000,							// 체력(hp)
			//20210810_yhlee 석상 밸런스를 조정합니다. HP 70% 하양조정
			hp: 350000000,							// 체력(hp) // 20211119_dblee 1/10로 조정함.
			missile_gap_x: 0,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 0,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 38,					//게이지 bar 표기 x좌표
			gagebar_y: -23,					//게이지 bar 표기 y좌표

		},
		{
			name: "81",						// 캐릭 이름 아이볼
			dirname: "enemy_81",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 182, h: 144,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 14,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 10,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 57,					// 이동속도
			attack_speed: 10,				// 공격속도
			attack_len: 380,				// 공격거리  ATTACK_LEN.VL  - KT 밸런스 적용 450->380

			attack_power: 23000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			// attack_power:2300,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 77000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함.
			missile_gap_x: -450,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -3,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 60,					//게이지 bar 표기 x좌표
			gagebar_y: -13,					//게이지 bar 표기 y좌표

		},
		{
			name: "82",						// 캐릭 이름  문
			dirname: "enemy_82",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 203, h: 221,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 14,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수
			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수 8 -> 4
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 57,					// 이동속도
			attack_speed: 30,				// 공격속도
			attack_len: 860,				// 공격거리
			attack_power: 25000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 87000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 78,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 42,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 98,					//게이지 bar 표기 x좌표
			gagebar_y: 10,					//게이지 bar 표기 y좌표

		},
		{
			name: "83",						// 캐릭 이름 레드 아이볼
			dirname: "enemy_83",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 208, h: 165,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 14,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 10,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 57,					// 이동속도
			attack_speed: 10,				// 공격속도
			attack_len: 530,				// 공격거리 - KT 밸런스 적용 800->530

			attack_power: 30000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 110000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: -640,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -63,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 60,					//게이지 bar 표기 x좌표
			gagebar_y: -13,					//게이지 bar 표기 y좌표

		},
		{
			name: "84",						// 캐릭 이름 그린 문
			dirname: "enemy_84",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 230, h: 232,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 14,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 57,					// 이동속도
			attack_speed: 30,				// 공격속도
			attack_len: 860,				// 공격거리

			attack_power: 30000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 115000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 78,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 42,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 98,					//게이지 bar 표기 x좌표
			gagebar_y: 10,					//게이지 bar 표기 y좌표

		},
		{
			name: "85",						// 캐릭 이름 퍼플 아이볼
			dirname: "enemy_85",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 232, h: 194,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 14,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수

			fire_frame_num: 10,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 57,					// 이동속도
			attack_speed: 10,				// 공격속도
			attack_len: 560,				// 공격거리 - KT 밸런스 적용 650->560

			attack_power: 40000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 125000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: -600,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: -45,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 60,					//게이지 bar 표기 x좌표
			gagebar_y: -13,					//게이지 bar 표기 y좌표

		},
		{
			name: "86",						// 캐릭 이름 블루 문
			dirname: "enemy_86",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 255, h: 255,					// 이미지의 크기 (width, height)
			move_frame_num: 8,				// 이동시 사용되는 frame의 수
			attack_frame_num: 14,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 6,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 8,				// 대기시 사용되는 frame의 수
			// effect_frame_num: 10
			fire_frame_num: 8,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 9,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 57,					// 이동속도
			attack_speed: 30,				// 공격속도
			attack_len: 860,				// 공격거리

			attack_power: 50000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 140000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 78,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 42,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 0,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 98,					//게이지 bar 표기 x좌표
			gagebar_y: 10,					//게이지 bar 표기 y좌표

		},
		{
			name: "87",						// 캐릭 이름 거인 - 갈
			dirname: "enemy_87",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 1,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리 : 모바일은 -800. TV는 -400

			attack_power: 30000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			// attack_power:30000, 				// 공격력(attack_power)
			hp: 9400000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			// hp:94000000,							// 체력(hp)
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함. - 메인화면, 결과화면에서 캐릭터 위치 잡을때 사용
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다. - 아이언칸의 방어 위치 값. (100)

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표

		},
		{
			name: "88",						// 캐릭 이름 거인-파
			dirname: "enemy_88",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 1,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 40000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 11300000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표

		},
		{
			name: "89",						// 캐릭 이름 거인-보
			dirname: "enemy_89",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 1,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 50000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 14000000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표

		},
		{
			name: "90",						// 캐릭 이름 거인-검
			dirname: "enemy_90",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 4,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 2,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 60000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 21200000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표
		},
		{
			name: "91",						// 캐릭 이름 거인-검
			dirname: "enemy_91",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 2,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 60000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 21200000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표
		},
		{
			name: "92",						// 캐릭 이름 거인-검
			dirname: "enemy_92",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 2,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 60000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 21200000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표
		},
		{
			name: "93",						// 캐릭 이름 거인-검
			dirname: "enemy_93",			// 캐릭터의 파일 이름.
			feature: FEATURE.WIDE,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 2,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 60000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 21200000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표
		},
		{
			name: "94",						// 캐릭 이름 거인-검
			dirname: "enemy_94",			// 캐릭터의 파일 이름.
			feature: FEATURE.ATTACK,			// 특징
			w: 258, h: 407,					// 이미지의 크기 (width, height)
			move_frame_num: 24,				// 이동시 사용되는 frame의 수
			attack_frame_num: 29,				// 공격시 사용되는 frame의 수
			beattack_frame_num: 10,			// 공격당할때 사용되는 프레임수
			wait_frame_num: 10,				// 대기시 사용되는 frame의 수

			fire_frame_num: 15,				// 공격시 미사일에 사용되는 frame의 수
			attack_fire_frame: 15,			// 공격 모션중 몇 프레임 부터 발사를 시작 할 것인가?
			move_speed: 2,					// 이동속도
			attack_speed: 5,				// 공격속도
			attack_len: -300,				// 공격거리

			attack_power: 60000000 * 0.8,	// 공격력(attack_power) - KT 밸런스위해 0.8 곱함.
			hp: 21200000000 * 0.6,				// 체력(hp) - KT 밸런스위해 0.6 곱함
			missile_gap_x: 1,				// 캐릭터 미사일 발사 x좌표
			missile_gap_y: 1,				// 캐릭터 미사일 발사 y좌표

			center_gap_x: 0,				// attack 01 이 중간을 기준으로 왼쪽으로 얼마나 치우쳤느냐, 결국 center_gap_x만큼 더해서 중심 맞추기 위함.
			center_gap_y: 0,				// attack 01 이 중간을 기준으로 위쪽으로 얼마나 취우쳤느냐, 결국 center_gap_y만큼 더해서 중심 맞추기 위함.
			beattack_margine: 400,			// 미사일 맞을때, 몇 픽셀 더 들어가서 맞아야 하는가? 나즈굴은 80 즉, 피격마진 이라 부른다.

			gagebar_x: 390,					//게이지 bar 표기 x좌표
			gagebar_y: 420,					//게이지 bar 표기 y좌표
		},
	];

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// Payment정의 - 마켓의 숫자들을 서버에서 관리하자.
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

//할로윈 이벤트 시작 (루비 , 마일리지 1+1 )20171030_yhlee
var EVENT_Halloween = 1;


var MARKET_DESIGN =
{
	ROW1: // 루비를 골드로 전환하는 비율 display용
		[
			{},
			{ gold: 17000, ruby: 10 }, //10 루비를 17000골드로 변환
			{ gold: 54000, ruby: 30 },
			{ gold: 133000, ruby: 70 },
			{ gold: 200000, ruby: 100 },
			{ gold: 315000, ruby: 150 },
		],

	/* -CNM  */
	ROW2: // 루비를 돈으로 구매하는 비율 display용
		[
			{},
			{ ruby: 10 * EVENT_Halloween, won: '1,100원' },
			{ ruby: 40 * EVENT_Halloween, won: '3,300원' },
			{ ruby: 70 * EVENT_Halloween, won: '5,500원' },
			{ ruby: 150 * EVENT_Halloween, won: '11,000원' },
			{ ruby: 260 * EVENT_Halloween, won: '16,500원' },
		],

	EVENT_TAG: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], //event라는 표기를 할것인가 말것인가. 0번지는 무시 1번지 부터 시작

	//20210820_yhlee BP 이벤트를 자동화 하면서 BP이벤트 수량을 지정합니다
	BP_EVENT: [0, 1, 2, 5, 8, 30],
	tmp: ""
}


//20171014_ywlee 마일리지 시스템
//해당금액에 맞는 보너스 포인트를 return한다.
//마일리지는 1000원당 5점이다.
MARKET_DESIGN.get_bonus_point = function (won) {
	var point = 0;
	switch (won) {
		case '0.99$':
		case '0.90$':
		case '1,000원':
		case '1,100원':
			point = 5; break;
		case '1.99$':
		case '1.90$':
		case '2,000원':
			point = 10; break;
		case '2.99$':
		case '2.90$':
		case '3,000원':
		case '3,300원':
			point = 15; break;
		case '3.99$':
		case '3.90$':
		case '4,000원':
			point = 20; break;
		case '4.99$':
		case '4.90$':
		case '100.000đ':
		case '5,000원':
		case '5,500원':
			point = 25; break;
		case '5.99$':
		case '5.90$':
		case '6,000원':

			point = 30; break;
		case '6.99$':
		case '6.90$':
		case '7,000원':
			point = 35; break;
		case '7.99$':
		case '7.90$':
		case '8,000원':
			point = 40; break;
		case '8.99$':
		case '8.90$':
		case '9,000원':
			point = 45; break;
		case '9.99$':
		case '9.90$':
		case '200.000đ':
		case '10,000원':
		case '11,000원':
			point = 50; break;
		case '15,000원':
		case '16,500원':
			point = 75; break;
	}
	// return point;
	//--------------------------------------------------------------------
	//20210820_yhlee 이벤트가 진행 여부를 확인합니다.
	// if(AUTO_EVENT_FLAG[11] == 1){	return point*2; }
	//20210823_yhlee_2 루비 1+1 이벤트일때도 BP 2배
	if (AUTO_EVENT_FLAG[11] == 1 || AUTO_EVENT_FLAG[3] == 1) { return point * 2; }
	else { return point; }
	//--------------------------------------------------------------------
}

/////////////////////////////////////////////////
//20200526_yhlee 패키지 상품을 정의합니다
var PACKAGE_DESIGN =
{

	ROW1: // 패키지  display용
		[
			{},
			//     gold = 획득 골드 양	,	ruby = 획득 루비 양
			//     won = 실제 판매가	,	zzinwon = 골드,루비를 일반상점에서 살때 드는 비용
			//     cur_buy_num = 현재 구매 횟수(DB에 저장된 값)    ,	max_buy_num = 최대 구매할수 있는 횟수
			{ gold: 400000, ruby: 0, won: '3,300원', zzinwon: '16,500원', cur_buy_num: -1, max_buy_num: 10, },//골드 40만
			{ gold: 800000, ruby: 0, won: '5,500원', zzinwon: '27,500원', cur_buy_num: -1, max_buy_num: 10, },//골드 80만
			{ gold: 0, ruby: 120, won: '3,300원', zzinwon: '9,900원', cur_buy_num: -1, max_buy_num: 10, },//루비 120개
			{ gold: 0, ruby: 240, won: '5,500원', zzinwon: '16,500원', cur_buy_num: -1, max_buy_num: 10, },//루비 240개
		]
}
var PACKAGE_OPEN = 1; // 패키지 상품을 오픈 할지 말지는 정합니다. 한번 오픈하면 필요가없습니다.   0 = 오픈하지 않음  , 1 = 오픈
/////////////////////////////////////////////////



// 2016.05.11
// 사용자 레벨 업그레이드시 루비 보상
// LEVEL_five: 레벨 5단위시 보상 루비 개수
// LEVEL_other: 레벨 5단위 제한한 보상 루비 개수
// CJH, CNM은 기존의 4, 2 루비 개수를 줌.
var LEVELUP_RUBY_BONUS = {
	'LEVEL_five': 4,
	'LEVEL_other': 2
};

//자동 플레이 추가합니다. 20190412_yhlee
var AUTOPLAY = {

	paid: 0, //0 ---> 자동 플레이를 구매하지 않았다  1---> 자동 플레이를 구매했다
	on_off: 0, //0 ---> 자동 플레이 끔  1---> 자동 플레이 켬
	end_time: 0, //종료 시간   -> 타임 스탬프로 저장하여 계산하도록 하자.
	stop_flag: 0, //0 ---> 자동플레이를 진행중에 중지  1---> 자동 플레이 진행중
	event_flag: 0, //0 ---> 무료 이벤트 진행 중이지 않다  1---> 무료 이벤트 진행 중

	//자동 플레이 구매 가격
	// 구매 가격 1일에 10bp
	get_day: 1,//자동 플레이 구매시 일수
	need_bp: 10,//자동 플레이 구매 BP 가격



	acc_gold: 0,//자동 플레이 완료후 획득한 골드를 기록에 남깁니다
	acc_stage: 0,//자동 플레이 진행한 스테이지를 기록에 남깁니다
	acc_start_time: 0,//자동 플레이 시작 시간을 기록에 남깁니다
	acc_end_time: 0,//자동 플레이 종료 시간을 기록에 남깁니다
	acc_tot_time: 0//자동 플레이 진행한 시간을 기록에 남깁니다
}


//2016.08.01 이벤트를 위해 추가
var gEVENT =
{
	//1차 체크 -- ACTVIE로 체크함.
	ACTIVE: false, // (true,false) 이벤트를 보여 줄 것인가 말것인가의 결정, 아래 기간도 있지만 안전 장치를 위해 ACTIVE 전역변수 영입

	//2차 체크 -- 날짜로 체크함.
	start_day: new Date(2016, 7, 1, 0, 0, 0),	//이벤트 시작 시간 -- 2016년 8월 6일 0시 0분 0초		//자바스크립트 월 함수는 0부터 시작하기 때문에 1을 빼야 한다.
	end_day: new Date(2016, 7, 31, 23, 59, 59)	//이벤트 종료 시각 -- 2016년 8월 31일 23시 59분 59초	//자바스크립트 월 함수는 0부터 시작하기 때문에 1을 빼야 한다.

};

//오광전 맞고에 들어간 이벤트
var EVENT =
	[
		{},
		{  //1번 이벤트
			active: 0,										//이벤트 실행 여부 (0-->중지, 1-->진행)
			name: "공격력,방어력,메테오 무료 체험",			//이벤트 이름
			start: "2017-02-10 13:00:00",					//이벤트 시작 시간 (2016-01-01 13:20:00) 형식으로 표기
			end: "2017-02-14 14:00:00",					//이벤트 종료 시간
		},
		{  //2번 이벤트
			active: 0,										//이벤트 실행 여부 (0-->중지, 1-->진행)
			name: "연속뽑기 30% 할인 이벤트",			//이벤트 이름
			start: "2017-02-10 13:00:00",					//이벤트 시작 시간 (2016-01-01 13:20:00) 형식으로 표기
			end: "2017-04-15 14:00:00",					//이벤트 종료 시간
			value: 30,										//20% 할인 30%이면 30이라 적으면 된다.
		},
		{  //3번 이벤트
			active: 0,										//이벤트 실행 여부 (0-->중지, 1-->진행)
			name: "메달 이벤트 - 꽝없다. 금메달 확률 상승", //이벤트 이름
			start: "2017-02-10 13:00:00",					//이벤트 시작 시간 (2016-01-01 13:20:00) 형식으로 표기
			end: "2017-02-15 14:00:00",					//이벤트 종료 시간
		},
		/*
			{  //4번 이벤트 - full pay event ==>엘도라도에서는 자리 문제 등으로 진행 안함.
				active	: 0,										//이벤트 실행 여부 (0-->중지, 1-->진행)
				name	: "20만원 만땅 결제 이벤트",				//이벤트 이름
				start   : "2017-01-01 00:00:00",					//이벤트 시작 시간 (2016-01-01 13:20:00) 형식으로 표기
				end		: "2017-02-31 23:59:59",					//이벤트 종료 시간  ==> 크게 잡아둬야 함.
				min     : 0,										//이벤트 최소 조건 - 10만원 이상 결제시, 0 --> 0원 이상 결제시...즉,모든 사용자에게 보여 주기
			},
		*/
		{  //4번 이벤트
			active: 1,										//이벤트 실행 여부 (0-->중지, 1-->진행)
			name: "PVP 점수 value(2)배, 획득골드 value(2)배",							//이벤트 이름
			start: "2017-01-01 00:00:00",					//이벤트 시작 시간 (2016-01-01 13:20:00) 형식으로 표기
			end: "2017-02-31 23:59:59",					//이벤트 종료 시간  ==> 크게 잡아둬야 함.
			value: 1.5,										//pvp점수 2배일경우 2, 1.5배 일경우 1.5
		},
	];

//해당하는 event_num이 active되었는가? 그렇다면 return true; 그렇지 않다면 return false;
EVENT.is_active = function (event_num) {
	//우선 active가 0이면 return flase
	if (EVENT[event_num].active == 0) {
		utilConsoleLog("이벤트가 activation되지 않았습니다.");
		return false;
	}


	//기간이 맞는가 체크 한다.
	var start = new Date(EVENT[event_num].start).getTime(); //시작시간(타임스탬프)
	var end = new Date(EVENT[event_num].end).getTime();   //종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각

	if (start <= cur && cur <= end) {
		utilConsoleLog("이벤트 기간 입니다.");
		return true;
	}
	else {
		utilConsoleLog("이벤트 기간이 아닙니다. " + event_num + "번 이벤트의 active를 0에서 1로 변경 바랍니다.");
		return false;
	}

}


var DEFINE = {
	RANKING_PERCENT: 80, //연결점수는 이전 wave clear점수의 80% //랭킹관련,PvP게임 관련

	// MONTH_MAX_PAYMENT	: 200000,	//월구매한도 정의 g.MONTH_MAX_PAYMENT에 값을 다시 setting함. -- Dlive 사업자 요구에 따라 현재(2017.1) 20만원임.
	// UPGRADE_MAX			: 140,		//업그레이드에서 max //120 ->140
	// USER_LEVEL_MAX		: 140,		//사용자 레벨 MAX //120 --> 140
	// USER_STORAGE_MAX	: 100,		//캐릭터 저장소 ( 기존 30에서 1씩 증가해서 최고 60까지 증가 가능 )
	//20210331_yhlee 업그레이드 및 유저 레벨 160으로 상승 및 캐릭터 저장소 120으로 증가
	UPGRADE_MAX: 160,		//업그레이드에서 max //140 ->160
	USER_LEVEL_MAX: 160,		//사용자 레벨 MAX //140 --> 160
	USER_STORAGE_MAX: 120,		//캐릭터 저장소 ( 기존 30에서 1씩 증가해서 최고 60까지 증가 가능 )

	//20191001_yhlee 아이템 메뉴 추가로 인하여 추가합니다.
	USER_ITEM_MAX: 60,//아이템 저장소 (기본 60) 항상  MAX = 216
	USER_ITEM_PAGE_MAX: 5,//아이템 저장소의 페이지 수 즉 12칸이 1페이지 이다. ITEM_STORAGE_MAX 수치에 따라 자동으로 변경됨 // MAX = 18

	//20200918_yhlee 아이템 저장소 추가를 위해 MAX 수치를 정합니다
	//굳이 페이지 단위가 아니여도 된다 칸수로 MAX값을 지정하면 된다.
	ITEM_STORAGE_MAX: 100,//증가할수있는 최대 칸수    ( 최대 MAX = 총합 218칸 , 18페이지 )

	//20210331_yhlee 미사일 레벨을 120으로 변경으로 추가합니다.
	MISSILE_RECHARGE_MAX: 120,


	BUY_EVENT_PROBABILITY_MAINMENU_BACK: 10,  //메인메뉴에서 back했을 경우 첫구매 재구매 이벤트 나타탈 확률 --- 10%일 경우 10
	BUY_EVENT_PROBABILITY_MARKETSTORE_IN: 30, //마켓스토어 진입했을때 첫구매,재구매 이벤트 나타날 확률 -------- 30%일 경우 30

	//20190308_yhlee 월드 보스전 데미지 표시
	DAMAGE_MAX_NUM: 20, //피격당할때 -20 표기하는 damge 숫자, 20개 정도면 충분할 듯

	//20210603_yhlee 소캐릭터가 대포를 터트릴 확률입니다.
	RASER_DESTROY_PERCENT:
	{
		COW76: 5,//2성 소 캐릭터가 대포와 충돌하는 경우 대포가 파괴 될 확률   0.5%
		COW77: 10,//3성 소 캐릭터가 대포와 충돌하는 경우 대포가 파괴 될 확률   1%
		COW78: 30,//4성 소 캐릭터가 대포와 충돌하는 경우 대포가 파괴 될 확률   3%
		COW79: 100,//5성 소 캐릭터가 대포와 충돌하는 경우 대포가 파괴 될 확률   10%
		COW80: 400,//6성 소 캐릭터가 대포와 충돌하는 경우 대포가 파괴 될 확률   40%
		COW81: 1000//7성 소 캐릭터가 대포와 충돌하는 경우 대포가 파괴 될 확률   100%
	},
	//20210603_yhlee 소캐릭터 추가로 소캐릭터가 미사일을 떨어트리고 날아가는 속도 최소 120을 해야 화면을 넘어서 지나갑니다.
	COW_MOVE_SPEED: 120,

	//20180315_ywlee 루시7성에 대한 define들
	//대천사루시
	RUSY:
	{
		C49_PROP: //대천사루시 발동확률 -- S_game_raser.js파일에서 사용함.
		{
			LEVEL80: 60,//level 0 ~ 80이하일때 발동확률 60%
			LEVEL85: 70,//level 80 ~ 85이하일때 발동확률 70%
			LEVEL90: 80,//level 85 ~ 90이하일때 발동확률 80%
			LEVEL95: 90,//level 90 ~ 96이하일때 발동확률 90%
			LEVEL100: 100//level 96 ~ 100이하일때 발동확률 100%
		},
		//20190704_yhlee 칸 7성 추가로 칸(원샷원킬 방어)도 이확률을 그대로 사용합니다.
		//20190704_yhlee 에코 7성 추가로 에코 능력(아군순간이동)도 이확률을 그대로 사용합니다.
		C50_PROP: //쎈언니루시 발동확률 -- S_game.js파일에서 사용 함.
		{
			LEVEL80: 60,//level 0 ~ 80이하일때 발동확률 60%
			LEVEL85: 70,//level 80 ~ 85이하일때 발동확률 70%
			LEVEL90: 80,//level 85 ~ 90이하일때 발동확률 80%
			LEVEL95: 90,//level 90 ~ 96이하일때 발동확률 90%
			LEVEL100: 100//level 96 ~ 100이하일때 발동확률 100%
		}
	}
};
//랭킹게임에서 이어서 하기에 필요한 루비 수
DEFINE.get_needruby_for_ranking_connect = function () {
	if (USER.clear_wave <= 20)
		return 1; //실제 사용자 보상은 2
	else if (USER.clear_wave <= 30)
		return 2; //실제 사용자 보상은 3
	else
		return 3; //실제 사용자 보상은 5
}

//초기화 시간 이면 return ture, 그렇지 않으면 false
//초기화 시간은 매주 월요일 오전1시 ~ 오전6시 까지 임.
DEFINE.Limit_Time = function () {
	var d = new Date();
	var day = d.getDay();
	if (day == 1) // 월요일(1)이면  (일요일0, 월요일1, 화요일2)
	{
		var hour = d.getHours(); //24시 체계로 return
		if (hour >= 1 && hour <= 5) //월요일 새벽 1:00분 부터 새벽 5시 59분까지 이면
		{
			return true;
		}
	}
	return false;
}

//게임시작전 게임에 영향을 미치는 공격력,체략,메테오공격에 대한 정의
DEFINE.board = function () {
	//캐릭공격력
	S_GAME.board.menu[1].upgrade = 50; //50%향상
	S_GAME.board.menu[1].need_ruby = 1; //필요루비 1개

	//캐릭체력
	S_GAME.board.menu[2].upgrade = 50; //50%향상
	S_GAME.board.menu[2].need_ruby = 1; //필요루비 1개

	//메테오공격
	S_GAME.board.menu[3].upgrade = 1; //추가 1회
	S_GAME.board.menu[3].need_ruby = 1; //필요루비 1개

	//무료체험 이벤트 진행 중이면
	if (EVENT.is_active(1)) {
		S_GAME.board.menu[1].need_ruby = 0;
		S_GAME.board.menu[2].need_ruby = 0;
		S_GAME.board.menu[3].need_ruby = 0;
	}
}
//뽑기확률
// 20230306_dblee_엘도라도 뽑기 개선안 적용
var GACHA_PROBABILITY =
{
	//가차1 --	3성,		2성,		1성 뽑힐 확률  //NORMAL (1성 ~ 3성) ,1회
	// gacha1 : [0,	20,		30,		50], //총합이 100이 되어야 함.
	gacha1: [0, 4, 12, 36, 24, 24], //총합이 100이 되어야 함.

	//가차2 --		5성,	4성,	3성,	2성,	1성이 뽑힐 확률 // NORMAL PLUS (1성 ~ 5성) ,1회
	// gacha2 : [0,	5,		10,		20,		30,		35], //총합이 100이 되어야 함.
	gacha2: [0, 12, 22, 36, 16, 14], //총합이 100이 되어야 함.

	//가차3 --		5성,	4성,	3성 //// PREMIUM (3성 ~ 5성) ,1회
	//gacha3 : [0,	10,		35,		55],
	// gacha3 : [0,	8,		37,		55],
	gacha3: [0, 4, 20, 48, 28],

	//가차4 --		5성,	4성		3성 //PREMIUM PLUS(3성 ~ 5성) ,5+1 =6회

	// gacha4 : [0,	15,		45,		40]
	gacha4: [0, 4, 20, 48, 28]
	// 20211119_dblee 뽑기 확률 조정 [0,   10,     45,     45] > [0,   15,     45,     40]
	// gacha4 : [0,	20,		40,		40]
	//2017년6월17일 5성 뽑기확률 2배 이벤트
	//20170621_yhlee 뽑기 확률 이벤트 종료

}


//20191001_yhlee 아이템 추가
//뽑기확률
var ITEM_GACHA_PROBABILITY =
{
	//가차1 --		F,		E 뽑힐 확률  //NORMAL (F ~ E) ,1회
	// gacha1 : [0,	80,		20], //총합이 100이 되어야 함.

	// //가차2 --		F,	    E,		D// NORMAL PLUS (F ~ D) ,1회
	// gacha2 : [0,	70,		27,		3], //총합이 100이 되어야 함.

	// //가차3 --		E,		D,		C // PREMIUM (E ~ C) ,1회
	// gacha3 : [0,	94,		5,		1],

	// //가차4 --		E,		D		C //PREMIUM PLUS(E ~ C) ,5+1 =6회
	// gacha4 : [0,	94,		5,		1]

	//20200325_yhlee 아이템 리메이크로 인한 확률 변경
	//가차1 --		F,		E 뽑힐 확률  //NORMAL (F 등급 ) ,1회
	gacha1: [0, 100, 0], //총합이 100이 되어야 함.

	//가차2 --		E,		D,		C // PREMIUM (E ~ C) [칼/날개] ,1회
	gacha2: [0, 70, 25, 5], //총합이 100이 되어야 함.

	//가차3 --		E,		D,		C // PREMIUM (E ~ C) [방패/시계] ,1회
	gacha3: [0, 70, 25, 5],

	//가차4 --		E,		D,		C //PREMIUM PLUS(E ~ C) [칼/날개] ,5+1 =6회
	gacha4: [0, 70, 25, 5],

	//가차5 --		E,		D,		C //PREMIUM PLUS(E ~ C) [방패/시계] ,5+1 =6회
	gacha5: [0, 70, 25, 5]
}


//20201110_yhlee 요일던전추가로 보상에 대한 확률을 추가합니다.
var DAYDUNGEON_REWARD_PROBABILITY =
{
	//쉬움 --		F,		E	  // 쉬움  F등급
	level1: [0, 100, 0], //총합이 100이 되어야 함.

	//보통 --		E,		D  // 보통  F등급
	level2: [0, 99, 1], //총합이 100이 되어야 함.

	//어려움 --		D,		C  // 어려움  F등급
	level3: [0, 99, 1,] //총합이 100이 되어야 함.

}


/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// global변수의 선언
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
var g =
{
	blink:
	{
		//변수
		value: 0,	// focus의 깜빡임을 나타낼 변수  0 --> opacity:0, 1--> opacity :1
		scene: null,	// blink를 호출한 scenario, 이변수를 기반으로 blink를 종료 한다.
		timer: null,

		//상수
		SHOW_TIMER: 700,	//blink관련 보여지는 시간
		HIDE_TIMER: 300	//blink관련 안보이게 하는 시간
	},
	REWARD_TIME_MS: 11 * 60 * 60 * 1000, //보상시간정의 12시간임. --> 11시간으로 변경함. 2018년7월 즈음.


	/*
	//20180702_ywlee  진저맨 추가 51~56
	STAR : [ //별들에 대한 캐릭터 번호 정의 -- 진화에 대한 표식 이며, 스테이지 클리어시 보상기준이 된다.
			[], //empty
			[0,1, 2, 3, 4,25,31,37, 0,0], //1성
			[0,5,10,15,20,26,32,38,43,51],//2성
			[0,6,11,16,21,27,33,39,44,52],//3성
			[0,7,12,17,22,28,34,40,45,53],//4성
			[0,8,13,18,23,29,35,41,46,54],//5성
			[0,9,14,19,24,30,36,42,47,55],//6성
			[0,0, 0, 0, 0,49, 0, 0,48,56], //7성
		],
		*/

	//20190109_yhlee  벤시 추가 57~62
	//20190215_yhlee  에이스 7성 추가 63
	//20190624_yhlee  루비,비비 7성 추가 64,65
	//20190704_yhlee  에코,스마티,칸 7성 추가
	//20200113_yhlee 제이 캐릭터 추가
	//20210603_yhlee 소 캐릭터 추가
	STAR: [ //별들에 대한 캐릭터 번호 정의 -- 진화에 대한 표식 이며, 스테이지 클리어시 보상기준이 된다.
		[], //empty
		[0, 1, 2, 3, 4, 25, 31, 37, 0, 0, 0, 69, 0], //1성
		[0, 5, 10, 15, 20, 26, 32, 38, 43, 51, 57, 70, 76],//2성
		[0, 6, 11, 16, 21, 27, 33, 39, 44, 52, 58, 71, 77],//3성
		[0, 7, 12, 17, 22, 28, 34, 40, 45, 53, 59, 72, 78],//4성
		[0, 8, 13, 18, 23, 29, 35, 41, 46, 54, 60, 73, 79],//5성
		[0, 9, 14, 19, 24, 30, 36, 42, 47, 55, 61, 74, 80],//6성
		[0, 63, 66, 67, 68, 49, 64, 65, 48, 56, 62, 75, 81], //7성
	],
	//20191111_chkim
	//각캐릭터 별로 1성~6성까지 캐릭터 번호가 들어가있다 .--시작은 도감에서 이름 추가부분떄문에 넣지만 나중에 쓸일것 같다.20170705_yhlee
	CHAR_NUM: [
		[],//empty
		[0, 1, 5, 6, 7, 8, 9, 63],//에이스 1성~7성 캐릭터 번호 //20190215_yhlee  에이스 7성 추가 63
		[0, 2, 10, 11, 12, 13, 14, 66],//에코 1성~7성 캐릭터 번호 //20190704_yhlee  에코,스마티,칸 7성 추가
		[0, 3, 15, 16, 17, 18, 19, 67],//스마티 1성~7성 캐릭터 번호 //20190704_yhlee  에코,스마티,칸 7성 추가
		[0, 4, 20, 21, 22, 23, 24, 68],//칸 1성~7성 캐릭터 번호 //20190704_yhlee  에코,스마티,칸 7성 추가
		//[0,25,26,27,28,29,30],//루시 1성~6성 캐릭터 번호
		[0, 25, 26, 27, 28, 29, 30, 49, 50],//루시 1성~7성 캐릭터 번호 //20180315_ywlee 루시7성 2개 추가
		[0, 31, 32, 33, 34, 35, 36, 64],//비비 1성~6성 캐릭터 번호//20190624_yhlee  루비,비비 7성 추가 64,65
		[0, 37, 38, 39, 40, 41, 42, 65],//루비 1성~6성 캐릭터 번호//20190624_yhlee  루비,비비 7성 추가 64,65
		[0, 43, 44, 45, 46, 47, 48],//황금맨 2성~7성 캐릭터 번호
		[0, 51, 52, 53, 54, 55, 56],//진저맨 2성~7성 캐릭터 번호
		[0, 57, 58, 59, 60, 61, 62],//벤시 2성~7성 캐릭터 번호  //20190109_yhlee  벤시 추가 57~62
		[0, 69, 70, 71, 72, 73, 74, 75],//제이 1성~7성 캐릭터 번호  //20200113_yhlee 제이 캐릭터 추가
		[0, 76, 77, 78, 79, 80, 81],//소 2성~7성 캐릭터 번호  //20210603_yhlee 소 캐릭터 추가

		//[0,49,50,51,52,53,54],//두기 1성~6성 캐릭터 번호  //20180315_ywlee 루시7성 2개 추가 나머지 캐릭터 주석처리
		//[0,61,62,63,64,65,66],//진저맨 1성~6성 캐릭터 번호
	],

	//ywlee_20160526
	MONTH_MAX_PAYMENT: 500000, //월결제 한도 50만원 --> 구매한도 수정시, MS_popup_txt1를 검색하여 함께 수정 해 줘야 함.

	METOR_POWER: 500,		//metor 공격 당했을 경우 damage정도
	tutorial_mode: 0,		//0 -> normal mode, tutorial mode
	flag_over1time: 0,		//게임시작하고 1시간이 지나면 이 flag가 1이 된다.

	flag_pay_once: 0, // 1번이라도 결제 성공 하면 pay_once의 값이 1로 된다.

	//사용자 보상관련 get_reward.php를 호출해서 값이 setting됨.
	REWARD:
	{
		status: 0,		//0-->초기값,  1-->보상받을게 있다. 2---> 보상지불완료했다., 3---> 보상받을게 없다.
		why: "",		//보상사유 (PvP대전 보상)
		what: "",		//보상내용 (예: RUBY, GOLD, CHAR)
		what_value: 0	//보상숫자
	},

	CHAR_BOOK_FLAG: 1,//도감을 보여줄지 말지 정하는 flag             1  : 보여줌      0 : 보여주지 않음

	timestamp_flag: 0, //서버에 timestamp요청할때 0으로 하고 요청하고, 요청완료되면 1로 바뀜.
	timestamp_start: 0, //실제 서버에서 받아온 timestamp값을 기록한다. timestamp_flag가0일때는 의미없는 data임. --> 게임 시작시 최초 1회만 불려짐
	timestamp_due: 0,  //게임시작부터 흐른시간 1초에 한번씩 증가 된다.


	//20210503_yhlee 모바일 연동 추가로 모바일 접속을 알기 위해 추가
	daily_run_count: 0,


	//20190709_yhlee 우편함 추가를위해 선언합니다.
	//사용자 보상관련 get_reward2.php를 호출해서 값이 setting됨.
	REWARD: null,
	name_change_ruby: 100, // 이름 변경시 소모되는 루비 수 20190129_yhlee  // 20220922_twkim...이름변경 루비100개
}
//20210118_yhlee 다른 플랫폼이랑 비슷하게 하기위해 이미지 URL 지정합니다.
var SERVER_IMG_URL = "./image/"; //20180920_yhlee 일단 busidol2로 해두고 load 다되면 바꾸자


// 20230306_dblee_엘도라도 뽑기 개선안 적용
//20171014_ywlee 마일리지 시스템
var NEED_BONUS_POINT = 450;  //6성 뽑기를 위한 필요 포인터(마일리지) 1000원(1$)당 5점, 20만원은 1000점.

// 20230306_dblee_엘도라도 뽑기 개선안 적용
//20180509_ywlee BP 5성뽑기 추가
var NEED_BONUS_POINT5 = 75; //5성 뽑기를 위한 필요 포인터  (3만원 상당)

//20190308_yhlee 보스가 죽었을때 지급 되는 루비 수량
var BOSS_DIE_RUBY = 100;

//20190308_yhlee 보스전에 입장가능한가를 확인하는 변수입니다.   1 입장가능    -1 입장 불가  0 초기값
var BOSS_GOIN_FLAG = 0;

//20190425_yhlee 행운 이벤트 추가
var LUCK_EVENT_FLAG = 0;   // 행운 이벤트 이벤트 플러그     1 이벤트 진행    0 이벤트 진행하지 않음
var LUCK_EVENT_NEED_RUBY = [0, 10, 30, 80, 200, 400, 750];
var LUCK_EVENT_GET_RUBY = [0,
	[15, 20],//첫번째 루비 투자 후 보상 15 ~ 20 개 획득
	[40, 50],//두번째 루비 투자 후 보상 40 ~ 50 개 획득
	[100, 150],//100 ~ 150 개 획득
	[250, 300],//250 ~ 300 개 획득
	[450, 550],//450 ~ 550 개 획득
	[800, 1000]//마지막 루비 투자 후 보상 800 ~ 1000 개 획득
];

//20220923_twkim...개인별 / 국가별 보상을 저장합니다.
var PVP_REWARD = {
	//개인별 보상 루비 개수  (항상 6개 이여야 한다.)
	ALONE: [0, 300, 200, 150, 100, 50, 20], // 실제로 지급하는 루비 갯수는 php 에서 수정해야한다 .pvp_reward_run.php
	//국가별 보상 루비 개수 (항상 보상은 3개이다 )
	COUNTRY:
	{
		// TOP1 : [0,500,400,300,200,100,3],//1등 국가 개인보상
		// TOP2 : [0,400,300,200,100,50,2],//2등 국가 개인보상
		// TOP3 : [0,300,200,100,50,30,1]//3등 국가 개인보상
		TOP1: [0, 300, 200, 100, 50, 30, 3],//1등 국가 개인보상
		TOP2: [0, 200, 100, 50, 25, 15, 2],//2등 국가 개인보상
		TOP3: [0, 100, 50, 25, 15, 10, 1]//3등 국가 개인보상
	},
}
/*********************************************************************************/
/////////////////////////////////////////////////////////////////////////////////
//실제 소스 코드에 적용 되어야 하나 급박한 수정사항의 경우 여기에 우선 적용 한다.
/////////////////////////////////////////////////////////////////////////////////

window.addEventListener('load', function () { temporary_run(); }, true);
function temporary_run() {

	// 20211124_dblee ajax 동기화 적용
	$.ajaxSetup({ timeout: 30000, async: false });

	//이달의 캐릭터 이벤트
	DEFINEJS_EVENT.this_month_char();

	//매일 루비 골드 지급 이벤트
	//DEFINEJS_EVENT.every_day_ruby_gold();

	//매일 루비 이벤트  -- 설날이벤트 1.28 ~ 2.2
	DEFINEJS_EVENT.every_day_ruby();

	//PVP입장 반값 이벤트 -- 신년이벤트#3
	//DEFINEJS_EVENT.pvp_enterance_sale();

	//업적(Quest) 2배 이벤트
	//DEFINEJS_EVENT.quest_double();

	//레벨업 이벤트 : 모든사용자 레벨업 할경우 먹인재료 등급 * 3개의 루비 지급
	//DEFINEJS_EVENT.levelup_ruby_event();

	//특정 캐릭터 --진저맨 뽑기 확률 up
	// DEFINEJS_EVENT.pointed_char_gacha_up();

	//이름변경 공짜 이벤트 01.29 ~ 01.30
	// DEFINEJS_EVENT.name_chabge_0ruby();

	//PVP 랭킹 보상으로 아이템 지급 이벤트 해당하는 주 03.23 ~ 3.29
	// DEFINEJS_EVENT.pvp_item_reward();
}

/*********************************************************************************
		  defjine.js파일에서 이벤트를 위해 짜집기되는 함수들의 모음
**********************************************************************************/
var DEFINEJS_EVENT = {};

//이달의 캐릭터 이벤트
DEFINEJS_EVENT.this_month_char = function () {
	var char_event_filename = null;



	//2020년 10월 : 제이 공격력2배, 생산속도2배.=======================================================================================
	var start = new Date("2020/10/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2020/10/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		//제이 공격력2배,생산속도2배
		char_event_filename = "mm_chevent_October_all_kor.png";
		//공격력 2배
		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 69: //제이1성
				case 70: //제이2성
				case 71: //제이3성
				case 72: //제이4성
				case 73: //제이5성
				case 74: //제이6성
				case 75: //제이7성

				//항상 추가하기 비비
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성
					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}

		//생산속도 2배
		CAL.get_charge_time_tick = function (index) {
			//var cur_level = STORAGE.data2[index].cur_level;
			var unit_num = STORAGE.data2[index].ch_num;
			var star = CHAR_OUR_TEAM[unit_num].star;
			var baesu;
			switch (star) {
				case 1: /*1성*/
					baesu = 2; break;
				case 2: /*2성*/
					baesu = 1.4; break;
				case 3: /*3성*/
					baesu = 1.1; break;
				case 4: /*4성*/
					baesu = 0.8; break;
				case 5: /*5성*/
					baesu = 0.6; break;
				case 6: /*6성*/
				default:
					baesu = 0.4; break;
			}

			var ret = CAL.get_char_nm(unit_num, 1, STORAGE.data2[index].max_level, index) * baesu;


			//"MedalPower 12.캐릭터 생산 속도 증가 발동 중인가?
			if (S_MEDALPOWER.value[12] > 0) //발동 되었다면
			{
				ret = ret - ret * (S_MEDALPOWER.value[12] * 0.50); // 발동100%일때 생산속도 50%감소 하라.
			}

			//"MedalPower 21.캐릭터 생산 속도 증가 발동 중인가?
			if (S_MEDALPOWER.value[21] > 0) //발동 되었다면
			{
				ret = ret - ret * (S_MEDALPOWER.value[21] * 0.50); // 발동100%일때 생산속도 50% 추가 감소 하라.
			}

			//"MedalPower 30.캐릭터 생산 속도 증가 발동 중인가?
			if (S_MEDALPOWER.value[30] > 0) //발동 되었다면
			{
				ret = ret - ret * (S_MEDALPOWER.value[30] * 0.25); // 발동100%일때 생산속도 50% 추가 감소 하라.
			}

			//"MedalPower 39.캐릭터 생산 속도 증가 발동 중인가?
			if (S_MEDALPOWER.value[39] > 0) //발동 되었다면
			{
				ret = ret - ret * (S_MEDALPOWER.value[39] * 0.50); // 발동100%일때 생산속도 50% 추가 감소 하라.
			}

			//20190704_yhlee 7성 칸 추가로 인하여 칸은 원래의 기준에서 3배 느리게 뽑을수 있도록합니다.
			// if(unit_num == 68)
			// 	ret = ret * 3;
			//------------------------------------------------
			//20200113_yhlee 제이캐릭터 원래의 기준에서 4배 , 5배 느리게 뽑을수 있도록 합니다.
			switch (unit_num) {
				case 68://칸 7성
					ret = ret * 3;
					break;
				case 74://제이 6성
					ret = ret * 4;
					break;
				case 75://제이 7성
					ret = ret * 5;
					break;
			}
			//------------------------------------------------

			////////////////////////////////////////////////////////////////////////////////
			switch (unit_num) {
				//이달의 캐릭터 이벤트 추가
				case 69: //제이1성
				case 70: //제이2성
				case 71: //제이3성
				case 72: //제이4성
				case 73: //제이5성
				case 74: //제이6성
				case 75: //제이7성
					ret = Math.floor(ret / 2);
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////


			// utilConsoleLog("time_tick="+ret);
			// return Math.floor(ret);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력치를 적용합니다
			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(index, 2));
			add_option_num = Number(CAL.char_use_item_add_option(index, 2));

			var tot_option_num = base_option_num + add_option_num;

			//생산속도 % 증가 계산식
			if (tot_option_num != 0)
				ret = ret * 1 / (tot_option_num / 100 + 1);

			return Math.floor(ret);



		}
	}

	// 에이스 공격력2배, 이동속도 2배======================================================================================= chkim
	var start = new Date("2022/08/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/08/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		//11월 이벤트의 파일명-- 에이스 공격력,이동속도 2배
		char_event_filename = "mm_chevent_ace_all_kor.png";

		//이동속도 2배
		CHAR_OUR_TEAM[1].move_speed = CHAR_OUR_TEAM[1].move_speed * 2;
		CHAR_OUR_TEAM[5].move_speed = CHAR_OUR_TEAM[5].move_speed * 2;
		CHAR_OUR_TEAM[6].move_speed = CHAR_OUR_TEAM[6].move_speed * 2;
		CHAR_OUR_TEAM[7].move_speed = CHAR_OUR_TEAM[7].move_speed * 2;
		CHAR_OUR_TEAM[8].move_speed = CHAR_OUR_TEAM[8].move_speed * 2;
		CHAR_OUR_TEAM[9].move_speed = CHAR_OUR_TEAM[9].move_speed * 2;
		CHAR_OUR_TEAM[63].move_speed = CHAR_OUR_TEAM[63].move_speed * 2;

		//공격력 2배

		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 1: //에이스1성
				case 5: //에이스2성
				case 6: //에이스3성
				case 7: //에이스4성
				case 8: //에이스5성
				case 9: //에이스6성
				case 63: //에이스7성

					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}
	}


	// 진저맨 공격력2배=======================================================================================
	var start = new Date("2022/09/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/09/30 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		//12월 이벤트의 파일명-- 진저맨 공격력 2배
		char_event_filename = "mm_chevent_gingerman_all_kor.png";

		//공격력 2배
		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 51: //진저맨2성
				case 52: //진저맨3성
				case 53: //진저맨4성
				case 54: //진저맨5성
				case 55: //진저맨6성
				case 56: //진저맨7성


				//항상 추가하기 비비
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성
					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}
	}


	// 밴시 공격력2배 사거리 2배 ======================================================================================= chkim
	var start = new Date("2022/10/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/10/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		//1월 이벤트의 파일명-- 밴시 공격력 2배 사거리 2배
		char_event_filename = "mm_chevent_bensi_all_kor.png";

		//사거리2배
		CHAR_OUR_TEAM[57].attack_len = CHAR_OUR_TEAM[57].attack_len * 2;
		CHAR_OUR_TEAM[58].attack_len = CHAR_OUR_TEAM[58].attack_len * 2;
		CHAR_OUR_TEAM[59].attack_len = CHAR_OUR_TEAM[59].attack_len * 2;
		CHAR_OUR_TEAM[60].attack_len = CHAR_OUR_TEAM[60].attack_len * 2;
		CHAR_OUR_TEAM[61].attack_len = CHAR_OUR_TEAM[61].attack_len * 2;
		CHAR_OUR_TEAM[62].attack_len = CHAR_OUR_TEAM[62].attack_len * 2;

		//공격력 2배
		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			/******2020년 2월 이벤트 벤시 캐릭 공격력 200% 증가 ********/
			switch (char_num) {
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성

				///이달의 캐릭터 이벤트 추가
				case 57: //벤시 2성
				case 58: //벤시 3성
				case 59: //벤시 4성
				case 60: //벤시 5성
				case 61: //벤시 6성
				case 62: //벤시 7성
					cur_ap = cur_ap * 2.0;
					break;
			}
			/********************************************************************************/
			//////////////////////////////////////////////////////////////////////////////////

			//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
			//만약 슬롯에 벤시가 있다면 버프를 하자
			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}
	}


	//2022년 11월 : 칸 체력,이동속도 각 2배=======================================================================================
	var start = new Date("2022/11/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/11/30 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		char_event_filename = "mm_chevent_kan_all_kor.png";

		//이동스피드 2배
		CHAR_OUR_TEAM[4].move_speed *= 2;
		CHAR_OUR_TEAM[20].move_speed *= 2;
		CHAR_OUR_TEAM[21].move_speed *= 2;
		CHAR_OUR_TEAM[22].move_speed *= 2;
		CHAR_OUR_TEAM[23].move_speed *= 2;
		CHAR_OUR_TEAM[24].move_speed *= 2;
		CHAR_OUR_TEAM[68].move_speed *= 2;

		//칸캐릭터 체력2배
		CAL.get_char_hp = function (char_num, level, char_index) {
			var hp_start = CHAR_OUR_TEAM[char_num].hp_start;
			var hp_end = CHAR_OUR_TEAM[char_num].hp_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;
			var cur_hp = Math.round(hp_end / level_num * level);

			//MEDAL POWER 7 아군체력 증가
			if (S_MEDALPOWER.value[7] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[7] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 18 아군체력 증가
			if (S_MEDALPOWER.value[18] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[18] * 0.5)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 27 아군체력 증가 II
			if (S_MEDALPOWER.value[27] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[27] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 36 아군체력 증가 III
			if (S_MEDALPOWER.value[36] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[36] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 아군 체력 메달을 적용합니다.
			if (S_MEDALPOWER.value[42] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 최대 피의 50%만큼만 증가하도록하자
				cur_hp = cur_hp + Math.floor(cur_hp * (S_MEDALPOWER.value[42] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_hp = cur_hp * 4.0;
							break;
						case 61://6성 벤시
							cur_hp = cur_hp * 3.0;
							break;
						case 60://5성 벤시
							cur_hp = cur_hp * 2.0;
							break;
					}
				}

			}

			//////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//칸 체력 2배 증가
				case 4:
				case 20:
				case 21:
				case 22:
				case 23:
				case 24:
				case 68: cur_hp *= 2; break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			// return Math.floor(cur_hp);

			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0 || char_index == undefined || char_index == null) {
				return Math.floor(cur_hp);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 3));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 3));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_hp = cur_hp + (cur_hp * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_hp = cur_hp + add_option_num;

			return Math.floor(cur_hp);


		}
	}



	//2022년 12월 : 에코 공격력2배, 이동속도 2배======================================================================================= chkim
	var start = new Date("2022/12/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/12/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		//3월 이벤트의 파일명-- 에코 공격력,이동속도 2배
		char_event_filename = "mm_chevent_echo_all_kor.png";

		//이동속도 2배
		CHAR_OUR_TEAM[2].move_speed = CHAR_OUR_TEAM[2].move_speed * 2;
		CHAR_OUR_TEAM[10].move_speed = CHAR_OUR_TEAM[10].move_speed * 2;
		CHAR_OUR_TEAM[11].move_speed = CHAR_OUR_TEAM[11].move_speed * 2;
		CHAR_OUR_TEAM[12].move_speed = CHAR_OUR_TEAM[12].move_speed * 2;
		CHAR_OUR_TEAM[13].move_speed = CHAR_OUR_TEAM[13].move_speed * 2;
		CHAR_OUR_TEAM[14].move_speed = CHAR_OUR_TEAM[14].move_speed * 2;
		CHAR_OUR_TEAM[66].move_speed = CHAR_OUR_TEAM[63].move_speed * 2;

		//공격력 2배

		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 2: //에코1성
				case 10: //에코2성
				case 11: //에코3성
				case 12: //에코4성
				case 13: //에코5성
				case 14: //에코6성
				case 66: //에코7성
				//항상 추가하기 비비
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성
					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}
	}


	//2023년 1월 : 스마티 사거리2배 , 공격력 2배 =======================================================================================
	var start = new Date("2023/01/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2023/01/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		char_event_filename = "mm_chevent_smartie_all_kor.png";

		//공격거리 2배
		CHAR_OUR_TEAM[3].attack_len = CHAR_OUR_TEAM[3].attack_len * 2;
		CHAR_OUR_TEAM[15].attack_len = CHAR_OUR_TEAM[15].attack_len * 2;
		CHAR_OUR_TEAM[16].attack_len = CHAR_OUR_TEAM[16].attack_len * 2;
		CHAR_OUR_TEAM[17].attack_len = CHAR_OUR_TEAM[17].attack_len * 2;
		CHAR_OUR_TEAM[18].attack_len = CHAR_OUR_TEAM[18].attack_len * 2;
		CHAR_OUR_TEAM[19].attack_len = CHAR_OUR_TEAM[19].attack_len * 2;
		CHAR_OUR_TEAM[67].attack_len = CHAR_OUR_TEAM[67].attack_len * 2;

		//공격력 2배
		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 3: //스마티1성
				case 15: //스마티2성
				case 16: //스마티3성
				case 17: //스마티4성
				case 18: //스마티5성
				case 19: //스마티6성
				case 67: //스마티7성
				//항상 추가하기 비비
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성
					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}
	}


	// 루시 공격력 2배 =======================================================================================
	var start = new Date("2023/02/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2023/02/28 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		char_event_filename = "mm_chevent_lucy_all_kor.png";
		//공격력 2배
		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 25: //루시1성
				case 26: //루시2성
				case 27: //루시3성
				case 28: //루시4성
				case 29: //루시5성
				case 30: //루시6성
				case 49: //루시7성(대천사루시)
				case 50: //루시7성(쎈언니루시)
				//항상 추가하기 비비
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성
					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}
	}


	// 루비 사거리2배=======================================================================================
	var start = new Date("2023/03/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2023/03/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		char_event_filename = "mm_chevent_ruby_all_kor.png";

		//사거리2배
		CHAR_OUR_TEAM[37].attack_len = CHAR_OUR_TEAM[37].attack_len * 2;
		CHAR_OUR_TEAM[38].attack_len = CHAR_OUR_TEAM[38].attack_len * 2;
		CHAR_OUR_TEAM[39].attack_len = CHAR_OUR_TEAM[39].attack_len * 2;
		CHAR_OUR_TEAM[40].attack_len = CHAR_OUR_TEAM[40].attack_len * 2;
		CHAR_OUR_TEAM[41].attack_len = CHAR_OUR_TEAM[41].attack_len * 2;
		CHAR_OUR_TEAM[42].attack_len = CHAR_OUR_TEAM[42].attack_len * 2;
		CHAR_OUR_TEAM[65].attack_len = CHAR_OUR_TEAM[65].attack_len * 2;
	}


	//2022년 6월 : 비비 체력,스피드 각 2배=======================================================================================
	var start = new Date("2022/06/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/06/30 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		char_event_filename = "mm_chevent_june_all_kor.png";

		//이동스피드 2배
		CHAR_OUR_TEAM[31].move_speed *= 2;
		CHAR_OUR_TEAM[32].move_speed *= 2;
		CHAR_OUR_TEAM[33].move_speed *= 2;
		CHAR_OUR_TEAM[34].move_speed *= 2;
		CHAR_OUR_TEAM[35].move_speed *= 2;
		CHAR_OUR_TEAM[36].move_speed *= 2;
		CHAR_OUR_TEAM[64].move_speed *= 2;

		//비비캐릭터 체력2배
		CAL.get_char_hp = function (char_num, level, char_index) {
			var hp_start = CHAR_OUR_TEAM[char_num].hp_start;
			var hp_end = CHAR_OUR_TEAM[char_num].hp_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;
			var cur_hp = Math.round(hp_end / level_num * level);

			//20210603_yhlee 소캐릭터 추가로 소캐릭터의 경우 기본 HP가 무조건 1로 셋팅되도록 변경합니다.
			if (char_num >= 76 && char_num <= 81) cur_hp = 1;

			//MEDAL POWER 7 아군체력 증가
			if (S_MEDALPOWER.value[7] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[7] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 18 아군체력 증가
			if (S_MEDALPOWER.value[18] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[18] * 0.5)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 27 아군체력 증가 II
			if (S_MEDALPOWER.value[27] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[27] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 36 아군체력 증가 III
			if (S_MEDALPOWER.value[36] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[36] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 아군 체력 메달을 적용합니다.
			if (S_MEDALPOWER.value[42] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 최대 피의 50%만큼만 증가하도록하자
				cur_hp = cur_hp + Math.floor(cur_hp * (S_MEDALPOWER.value[42] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$



			switch (char_num) { //비비캐릭터
				case 31:
				case 32:
				case 33:
				case 34:
				case 35:
				case 36:
				case 64:
					cur_hp *= 2;
					break;
			}


			//20201110_yhlee 요일던전 추가로 요일별 컨셉 적용
			//토 : 아이템 적용X
			if (S_DAYDUNGEON_SELECT.cur_day == 6 && g_sceneinfo.cur_scene == gS_DAYDUNGEON)
				return Math.floor(cur_hp);



			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_hp = cur_hp * 4.0;
							break;
						case 61://6성 벤시
							cur_hp = cur_hp * 3.0;
							break;
						case 60://5성 벤시
							cur_hp = cur_hp * 2.0;
							break;
					}
				}
			}

			//20210603_yhlee 소캐릭터 추가로 HP가 0으로 표기되는 것을 방지하기위해 0일경우 1로 셋팅하도록 변경합니다.
			if (cur_hp < 1) cur_hp = 1;

			// return Math.floor(cur_hp);

			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0 || char_index == undefined || char_index == null) {
				return Math.floor(cur_hp);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 3));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 3));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_hp = cur_hp + (cur_hp * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_hp = cur_hp + add_option_num;

			return Math.floor(cur_hp);
		}
	}

	//2022년 7월 : 황금맨 체력,이동속도 각 2배=======================================================================================
	var start = new Date("2022/07/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/07/31 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		char_event_filename = "mm_chevent_july_all_kor.png?20220726";

		//이동스피드 2배
		CHAR_OUR_TEAM[43].move_speed *= 2;
		CHAR_OUR_TEAM[44].move_speed *= 2;
		CHAR_OUR_TEAM[45].move_speed *= 2;
		CHAR_OUR_TEAM[46].move_speed *= 2;
		CHAR_OUR_TEAM[47].move_speed *= 2;
		CHAR_OUR_TEAM[48].move_speed *= 2;

		//황금맨캐릭터 체력2배
		CAL.get_char_hp = function (char_num, level, char_index) {
			var hp_start = CHAR_OUR_TEAM[char_num].hp_start;
			var hp_end = CHAR_OUR_TEAM[char_num].hp_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;
			var cur_hp = Math.round(hp_end / level_num * level);

			//20210603_yhlee 소캐릭터 추가로 소캐릭터의 경우 기본 HP가 무조건 1로 셋팅되도록 변경합니다.
			if (char_num >= 76 && char_num <= 81) cur_hp = 1;

			//MEDAL POWER 7 아군체력 증가
			if (S_MEDALPOWER.value[7] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[7] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 18 아군체력 증가
			if (S_MEDALPOWER.value[18] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[18] * 0.5)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 27 아군체력 증가 II
			if (S_MEDALPOWER.value[27] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[27] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 36 아군체력 증가 III
			if (S_MEDALPOWER.value[36] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[36] * 0.25)  //100%일때 아군 공격력 증가 25%
			}


			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 아군 체력 메달을 적용합니다.
			if (S_MEDALPOWER.value[42] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 최대 피의 50%만큼만 증가하도록하자
				cur_hp = cur_hp + Math.floor(cur_hp * (S_MEDALPOWER.value[42] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			switch (char_num) { //황금맨캐릭터
				case 43:
				case 44:
				case 45:
				case 46:
				case 47:
				case 48:
					cur_hp *= 2;
					break;
			}


			//20201110_yhlee 요일던전 추가로 요일별 컨셉 적용
			//토 : 아이템 적용X
			if (S_DAYDUNGEON_SELECT.cur_day == 6 && g_sceneinfo.cur_scene == gS_DAYDUNGEON)
				return Math.floor(cur_hp);


			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_hp = cur_hp * 4.0;
							break;
						case 61://6성 벤시
							cur_hp = cur_hp * 3.0;
							break;
						case 60://5성 벤시
							cur_hp = cur_hp * 2.0;
							break;
					}
				}

			}
			// return Math.floor(cur_hp);

			//20210603_yhlee 소캐릭터 추가로 HP가 0으로 표기되는 것을 방지하기위해 0일경우 1로 셋팅하도록 변경합니다.
			if (cur_hp < 1) cur_hp = 1;

			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0 || char_index == undefined || char_index == null) {
				return Math.floor(cur_hp);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 3));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 3));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_hp = cur_hp + (cur_hp * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_hp = cur_hp + add_option_num;

			return Math.floor(cur_hp);


		}
	}



	//2021년 09월 : 제이 공격력2배, 체력2배.=======================================================================================
	var start = new Date("2021/09/01 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2021/09/30 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각
	if (start <= cur && cur <= end) {
		//제이 공격력2배,생산속도2배
		char_event_filename = "mm_chevent_september_all_kor.png";
		//공격력 2배
		CAL.get_char_ap = function (char_num, level, char_index) {
			var cur_ap;
			var ap_start = CHAR_OUR_TEAM[char_num].ap_start;
			var ap_end = CHAR_OUR_TEAM[char_num].ap_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;

			if (level == 1) //level 1이면 설정해둔 값으로 적용 한다.
			{
				cur_ap = ap_start;
			}
			else {
				cur_ap = Math.round((ap_end - ap_start) / level_num * level + ap_start);
			}

			//MEDAL POWER 6 아군공격력 증가
			if (S_MEDALPOWER.value[6] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[6] * 0.25)  //100%일때 아군 공격력 증가 25%
			}
			//MEDAL POWER 17 아군공격력 증가II
			if (S_MEDALPOWER.value[17] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[17] * 0.5)  //100%일때 아군 공격력 증가 50%
			}


			//MEDAL POWER 26 아군공격력 증가III
			if (S_MEDALPOWER.value[26] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[26] * 0.25)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 35 아군공격력 증가IV
			if (S_MEDALPOWER.value[35] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[35] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//MEDAL POWER 40 아군공격력 증가V
			if (S_MEDALPOWER.value[40] > 0) //발동 되었다면
			{
				cur_ap = cur_ap * (1.0 + S_MEDALPOWER.value[40] * 0.5)  //100%일때 아군 공격력 증가 75%
			}

			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 캐릭터 공격력 증가 메달을 적용합니다.
			//MEDAL POWER 44 아군공격력 증가VI
			if (S_MEDALPOWER.value[44] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 캐릭터 공격력의 50%만큼만 증가하도록하자
				cur_ap = cur_ap + Math.floor(cur_ap * (S_MEDALPOWER.value[44] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			////////////////////////////////////////////////////////////////////////////////
			switch (char_num) {
				//이달의 캐릭터 이벤트 추가
				case 69: //제이1성
				case 70: //제이2성
				case 71: //제이3성
				case 72: //제이4성
				case 73: //제이5성
				case 74: //제이6성
				case 75: //제이7성

				//항상 추가하기 비비
				case 31: //비비1성
				case 32: //비비2성
				case 33: //비비3성
				case 34: //비비4성
				case 35: //비비5성
				case 36: //비비6성
					cur_ap = cur_ap * 2.0;
					break;
			}
			//////////////////////////////////////////////////////////////////////////////////

			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//벤시의 능력으로 에코의 능력을 올리자.20190109_yhlee 벤시 능력 추가
				//만약 슬롯에 벤시가 있다면 버프를 하자
				// switch(S_GAME.bensi_buff_charnum(char_num))
				// {
				// 	case 62://7성벤시
				// 		cur_ap = cur_ap * 4.0;
				// 		break;
				// 	case 61://6성 벤시
				// 		cur_ap = cur_ap * 3.0;
				// 		break;
				// 	case 60://5성 벤시
				// 		cur_ap = cur_ap * 2.0;
				// 		break;
				// }
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_ap = cur_ap * 4.0;
							break;
						case 61://6성 벤시
							cur_ap = cur_ap * 3.0;
							break;
						case 60://5성 벤시
							cur_ap = cur_ap * 2.0;
							break;
					}
				}
			}

			// return Math.floor(cur_ap);


			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0) {
				return Math.floor(cur_ap);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 1));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 1));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_ap = cur_ap + (cur_ap * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_ap = cur_ap + add_option_num;

			return Math.floor(cur_ap);
		}

		//체력 2배
		CAL.get_char_hp = function (char_num, level, char_index) {
			var hp_start = CHAR_OUR_TEAM[char_num].hp_start;
			var hp_end = CHAR_OUR_TEAM[char_num].hp_end;
			var level_num = (CHAR_OUR_TEAM[char_num].star + 1) * 10;
			var cur_hp = Math.round(hp_end / level_num * level);

			//20210603_yhlee 소캐릭터 추가로 소캐릭터의 경우 기본 HP가 무조건 1로 셋팅되도록 변경합니다.
			if (char_num >= 76 && char_num <= 81) cur_hp = 1;

			//MEDAL POWER 7 아군체력 증가
			if (S_MEDALPOWER.value[7] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[7] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 18 아군체력 증가
			if (S_MEDALPOWER.value[18] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[18] * 0.5)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 27 아군체력 증가 II
			if (S_MEDALPOWER.value[27] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[27] * 0.25)  //100%일때 아군 공격력 증가 25%
			}

			//MEDAL POWER 36 아군체력 증가 III
			if (S_MEDALPOWER.value[36] > 0) //발동 되었다면
			{
				cur_hp = cur_hp * (1.0 + S_MEDALPOWER.value[36] * 0.25)  //100%일때 아군 공격력 증가 25%
			}


			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$
			//20200424_yhlee 201스테이지 추가로 인하여 아군 체력 메달을 적용합니다.
			if (S_MEDALPOWER.value[42] > 0) //발동 되었다면
			{
				//100% 채워지면 현재 최대 피의 50%만큼만 증가하도록하자
				cur_hp = cur_hp + Math.floor(cur_hp * (S_MEDALPOWER.value[42] / 2));
			}
			//~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$~~$

			switch (char_num) { //제이캐릭터
				case 69: //제이1성
				case 70: //제이2성
				case 71: //제이3성
				case 72: //제이4성
				case 73: //제이5성
				case 74: //제이6성
				case 75: //제이7성
					cur_hp *= 2;
					break;
			}


			//20201110_yhlee 요일던전 추가로 요일별 컨셉 적용
			//토 : 아이템 적용X
			if (S_DAYDUNGEON_SELECT.cur_day == 6 && g_sceneinfo.cur_scene == gS_DAYDUNGEON)
				return Math.floor(cur_hp);


			if (g_sceneinfo.cur_scene != gS_BOSS) {
				//20190723_yhlee 200Stage 추가로 벤시 특수능력을 스테이지에 마춰서 적용합니다.
				if (check_ability_stage()) {
					switch (S_GAME.bensi_buff_charnum(char_num)) {
						case 62://7성벤시
							cur_hp = cur_hp * 4.0;
							break;
						case 61://6성 벤시
							cur_hp = cur_hp * 3.0;
							break;
						case 60://5성 벤시
							cur_hp = cur_hp * 2.0;
							break;
					}
				}

			}
			// return Math.floor(cur_hp);

			//20210603_yhlee 소캐릭터 추가로 HP가 0으로 표기되는 것을 방지하기위해 0일경우 1로 셋팅하도록 변경합니다.
			if (cur_hp < 1) cur_hp = 1;

			//20191001_yhlee 아이템 추가로 인하여 아이템 능력을 추가합니다
			//만약 아이템을 계산하지 않아도 된다면 현재 상태 그대로 리턴 합니다 .
			//0으로 넘어오는 경우는 캐릭터 뽑기 , PVP 대전에서 상대방의 능력치를 계산할때 입니다.
			if (char_index == 0 || char_index == undefined || char_index == null) {
				return Math.floor(cur_hp);
			}


			//아이템 능력치를 적용합니다.
			var base_option_num = 0;
			var add_option_num = 0;
			//CAL.char_use_item_base_option  기본 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//CAL.char_use_item_add_option	추가 아이템 옵션에 대한 옵션 수치를 리턴해주는 함수
			//  char_index   , 1       ==   숫자의 경우 아이템 옵션의 번호이다 .
			//아이템 옵션 번호    1=공격력 2=캐릭터 생산 속도 증가 3=체력  4=이동속도 5=공격거리	 6=캐릭터 생산 미네랄 감소 7=공격속도
			base_option_num = Number(CAL.char_use_item_base_option(char_index, 3));
			add_option_num = Number(CAL.char_use_item_add_option(char_index, 3));

			//base_option_num  값에는 400%   260% 이런식으로 오기때문에 100으로 나눠서 계산을합니다.
			if (base_option_num != 0)
				cur_hp = cur_hp + (cur_hp * (base_option_num / 100));

			//추가 옵션을 더합니다.
			cur_hp = cur_hp + add_option_num;

			return Math.floor(cur_hp);


		}



	}





	//공통사항====================================================================================================
	//S_MAINMENU.maketag = function() -- 서비스 해도 별 지장 없기에 KT 소스에서 수정함.
	S_MAINMENU.display_tip = function () {
		// var MAX_TIP = 19; //팁의 수
		//20210222_yhlee tip 수량 변경
		var MAX_TIP = 23; //팁의 수
		var tip = Math.floor(Math.random() * MAX_TIP) + 1;

		if (g.tutorial_mode == 1)	//최초 실행일 경우
			tip = 1;				//엘도라도를 꼭 찾아 주세요

		//일반팁일경우
		var text = eval('TXT.tip_' + tip);
		var tip_view = 1; //((Math.floor(Math.random()*10)+1) >= 9)? 1: 0; //10%확율로 tip을 보여 주자. -->무조건 보여 주자
		$('#TXT_MM_tip').css({
			'display': (tip_view == 1) ? 'block' : 'none',
			//'display': 'block', //test
			left: 219 + 'px',
			top: 83 + 'px',
			width: 847 + 'px',
			height: 59 + 'px',
			//background:'black',
			'background': 'url(./image/ui/1_mainmenu/mm_tipbox.png) no-repeat 0 0',
			'background-position': '0px 0px',
			//opacity: "0.7",
			'line-height': 59 + 12 + 'px',
			'font-size': (USER.lang == LANG.ENGLISH && tip == 7) ? '16px' : '18px',
			'text-align': 'center',
			//'text-shadow': '1px 1px 1px white',
			//'font-weight': 'bold',
			'border-radius': '5px',
			'color': 'white',
			position: 'absolute'
		});

		//상황에 맞은 팁

		//텍스트 보여 주기
		$('#TXT_MM_tip').text(/*"Tip: "+*/text);

		//이달의 캐릭터
		if (char_event_filename != null)
			utilDrawImage_no_wh_pos('Img_chevent_october', './image/' + char_event_filename, 1065, 73);

		//---------------------------------------------------------------------------------------------------------------------------------
		//20210820_yhlee 이벤트 자동화로 인하여 아래 부분을 추가합니다.
		//이달의 캐릭터는 자동화가 아니고 이벤트는 자동화라 싱크마추기가 힘들어 이달의캐릭,행운이벤트 롤링되는 부분은 하지않도록 합니다.
		// 이유는 이달의 캐릭터는 define에서 함수를 재정의하고 이벤트 자동화의 경우 소스에서 바로 적용되기 때문에 싱크 마추기가 힘들다.
		// 그러므로 소캐릭터 추가전에 이달의 캐릭터의 간판의 경우 이벤트가 있는 경우에 이달의 캐릭터 간판을 사용하지 않도록 합니다.
		if (LUCK_EVENT_FLAG == 1) {
			// 20221207_dblee_메인 화면에서 배너 이미지 깨지는 현상과 단축 리모콘 동작 오류 수정함.
			//행운이벤트 간판 이미지
			utilDrawImage_no_wh_pos('Img_chevent_october', './image/mm_eventshortcut_20200321_kt.png', 1065, 73);
		}

		//20210823_yhlee_4 아이템 뽑기 50% 할인
		if (AUTO_EVENT_FLAG[16] == 1) {
			// 20221207_dblee_메인 화면에서 배너 이미지 깨지는 현상과 단축 리모콘 동작 오류 수정함.
			utilDrawImage_no_wh_pos('Img_chevent_october', './image/mm_eventshortcut_item50sale_kt.png', 1065, 73);//아이템 이벤트
		}

		//20210823_yhlee_5 아이템 E -> D 등급업 100% 이벤트
		if (AUTO_EVENT_FLAG[17] == 1) {
			// 20221207_dblee_메인 화면에서 배너 이미지 깨지는 현상과 단축 리모콘 동작 오류 수정함.
			utilDrawImage_no_wh_pos('Img_chevent_october', './image/mm_eventshortcut_20200313_kt.png', 1065, 73);//아이템 이벤트
		}
		//---------------------------------------------------------------------------------------------------------------------------------

		//루비 받기 앱 홍보 이미지 왼쪽에 등록 20180828_yhlee
		// utilDrawImage_no_wh_pos('Img_rubytakeapp','./image/mm_adbox_kor.png',11,73);
	}


	//패키지 상품 매달 10 ~ 20일에 메인화면의 오른쪽에 배너를 추가하도록 합니다.
	ServerConnection.get_package_event_time(DEFINEJS_EVENT.packge_banner);
}




//매일 루비,골드 지급 이벤트
DEFINEJS_EVENT.every_day_ruby_gold = function () {
	var start = new Date("2017/12/29 00:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2018/01/04 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각

	if (start <= cur && cur <= end) {
		S_ATTENDANCE.reward = function () {

			//출석보상 진행 하면 된다.
			STORAGE.data1.chul_date = S_ATTENDANCE.today;
			STORAGE.data1.chul_num++;

			//var tmp = (STORAGE.data1.chul_num%7;
			var tmp = STORAGE.data1.chul_num % 7;
			var i = (tmp == 0) ? 7 : tmp;


			//여기 보상 시스템 구축 하면 된다.
			//어떤 보상을 줄 것인가?
			//var index = Math.floor((STORAGE.data1.chul_num-1)/7)+1;
			var index = Math.floor((STORAGE.data1.chul_num - 1) / 7) + 1;
			if (index > MAX_CHUL_NUM) //5개월치 모두 사용 했다면
			{
				index = MAX_CHUL_NUM; //5개월치를 했다면 마지막 최고의 보상을 계속 줘라.
			}
			switch (CHULARRAY[index].type[i]) //보상종류
			{
				case TY.GOLD:	// gold 보상
					var gold = CHULARRAY[index].value[i];

					// 2016-01-27 cnm 종료key이슈 때문에 바로 적용해 주기.
					// 모든 사업자 적용하기. 3.28.2016
					USER.gold += gold;
					break;
				case TY.RUBY:	// ruby 보상
					var ruby = CHULARRAY[index].value[i];

					// 2016-01-27 cnm 종료key이슈 때문에 바로 적용해 주기.
					// 모든 사업자 적용하기. 3.28.2016
					USER.ruby += ruby;
					break;
				case TY.CHAR:	//캐릭터 보상
					// var chnum = CHULARRAY[index].value[i];
					// STORAGE.add_char(chnum);
					//20181116_yhlee 출석 보상을 랜덤으로 변경해보자
					if (index == 20)//마지막 보상이냐? 그러면 캐릭보상을 랜덤으로 하자
					{
						//4성중에 랜덤으로 돌려서 캐릭터를 먹자
						var ran_char = Math.floor(Math.random() * (g.STAR[4].length - 1)) + 1;
						STORAGE.add_char(g.STAR[4][ran_char]);
						// utilNotice("출석 보상으로 "+eval('TXT.char_name_'+g.STAR[4][ran_char])+" 획득하였습니다.",3);
						//보상받은것 로컬 스토리지에 저장한다.
						STORAGE.save_all_info_to_storage("출석보상: 4성 랜덤 캐릭터(" + g.STAR[4][ran_char] + ")");
					}
					else {
						var chnum = CHULARRAY[index].value[i];
						STORAGE.add_char(chnum);
					}
					break;
				case TY.ITEM:	//아이템 보상 //아직 정해지지 않음
					var item = CHULARRAY[index].value[i];
					break;
				default: utilConsoleLog("Error in S_ATTENDANCE.press();:" + CHULARRAY[index].type[i]);
			}

			//보상받은것 로컬 스토리지에 저장한다. -- 이벤트 전에는 아래거 active 되어야 함.
			//STORAGE.save_all_info_to_storage("출석보상:골드("+CHULARRAY[index].value[i]+"):루비("+CHULARRAY[index].value[i]+"):캐릭터("+CHULARRAY[index].value[i]+")");

			USER.gold = USER.gold + 50000;
			STORAGE.save_all_info_to_storage("신년 이벤트 보상 : 골드(50,000)");
			utilNotice("신년 이벤트 보상 골드 50,000원이 지급되었습니다.", 3);
		}
	}
}

//매일 루비 지급 이벤트  -- 설날이벤트 02.08 ~ 02.14
DEFINEJS_EVENT.every_day_ruby = function () {
	var start = new Date("2022/05/04 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2022/05/09 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각

	if (start <= cur && cur <= end) {
		S_ATTENDANCE.reward = function () {

			//출석보상 진행 하면 된다.
			STORAGE.data1.chul_date = S_ATTENDANCE.today;
			STORAGE.data1.chul_num++;

			//var tmp = (STORAGE.data1.chul_num%7;
			var tmp = STORAGE.data1.chul_num % 7;
			var i = (tmp == 0) ? 7 : tmp;


			//여기 보상 시스템 구축 하면 된다.
			//어떤 보상을 줄 것인가?
			//var index = Math.floor((STORAGE.data1.chul_num-1)/7)+1;
			var index = Math.floor((STORAGE.data1.chul_num - 1) / 7) + 1;
			if (index > MAX_CHUL_NUM) //5개월치 모두 사용 했다면
			{
				index = MAX_CHUL_NUM; //5개월치를 했다면 마지막 최고의 보상을 계속 줘라.
			}
			switch (CHULARRAY[index].type[i]) //보상종류
			{
				case TY.GOLD:	// gold 보상
					var gold = CHULARRAY[index].value[i];

					// 2016-01-27 cnm 종료key이슈 때문에 바로 적용해 주기.
					// 모든 사업자 적용하기. 3.28.2016
					USER.gold += gold;
					break;
				case TY.RUBY:	// ruby 보상
					var ruby = CHULARRAY[index].value[i];

					// 2016-01-27 cnm 종료key이슈 때문에 바로 적용해 주기.
					// 모든 사업자 적용하기. 3.28.2016
					USER.ruby += ruby;
					break;
				case TY.CHAR:	//캐릭터 보상
					// var chnum = CHULARRAY[index].value[i];
					// STORAGE.add_char(chnum);
					//20181116_yhlee 출석 보상을 랜덤으로 변경해보자
					if (index == 20)//마지막 보상이냐? 그러면 캐릭보상을 랜덤으로 하자
					{
						//4성중에 랜덤으로 돌려서 캐릭터를 먹자
						var ran_char = Math.floor(Math.random() * (g.STAR[4].length - 1)) + 1;
						// STORAGE.add_char(g.STAR[4][ran_char]);
						//20190709_yhlee 우편함 추가로 인하여 보상은 REWARD로 모두 저장하도록 변경합니다.
						if (USER.lang == LANG.KOREA)
							ServerConnection.put_reward_char('CHAR', '출석보상', g.STAR[4][ran_char]);
						else
							ServerConnection.put_reward_char('CHAR', 'attendance reward', g.STAR[4][ran_char]);

						// utilNotice("출석 보상으로 "+eval('TXT.char_name_'+g.STAR[4][ran_char])+" 획득하였습니다.",3);
						//보상받은것 로컬 스토리지에 저장한다.
						STORAGE.save_all_info_to_storage("출석보상: 4성 랜덤 캐릭터(" + g.STAR[4][ran_char] + ")");
					}
					else {
						var chnum = CHULARRAY[index].value[i];
						// STORAGE.add_char(chnum);
						//20190709_yhlee 우편함 추가로 인하여 보상은 REWARD로 모두 저장하도록 변경합니다.
						if (USER.lang == LANG.KOREA)
							ServerConnection.put_reward_char('CHAR', '출석보상', chnum);
						else
							ServerConnection.put_reward_char('CHAR', 'attendance reward', chnum);
					}
					break;
				case TY.ITEM:	//아이템 보상 //아직 정해지지 않음
					var item = CHULARRAY[index].value[i];
					break;
				default: utilConsoleLog("Error in S_ATTENDANCE.press();:" + CHULARRAY[index].type[i]);
			}

			//보상받은것 로컬 스토리지에 저장한다. -- 이벤트 전에는 아래거 active 되어야 함.
			//STORAGE.save_all_info_to_storage("출석보상:골드("+CHULARRAY[index].value[i]+"):루비("+CHULARRAY[index].value[i]+"):캐릭터("+CHULARRAY[index].value[i]+")");

			// USER.gold = USER.gold + 50000;
			// STORAGE.save_all_info_to_storage("신년 이벤트 보상 : 골드(50,000)");
			// utilNotice("신년 이벤트 보상 골드 50,000원이 지급되었습니다.", 3);

			if (1) {
				USER.ruby = USER.ruby + 100;
				// S_ATTENDANCE.reward.ruby = 100;
				save_UserInfo_after_pay_to_server("100", "6주년 기념");
				STORAGE.save_all_info_to_storage("6주년 기념 보상 : 루비(100) + 출석보상");
				utilNotice("6주년 기념 보상 루비 100개가 지급되었습니다.", 2);
			}
			else {
				USER.ruby = USER.ruby + 10;
				// S_ATTENDANCE.reward.ruby = 10;
				save_UserInfo_after_pay_to_server("10", "설날 기념 보상");
				STORAGE.save_all_info_to_storage("설날 기념 보상 : 루비(10) + 출석보상");
				utilNotice("설날 기념 보상 루비 10개가 지급되었습니다.", 2);
			}
		}
	}
}




//PVP대전 입장료 반값(5000원 -> 2500원)
DEFINEJS_EVENT.pvp_enterance_sale = function () {
	//PVP대전 입장료 반값
	var start = new Date("2017/12/29 00:00:00").getTime(); //시작시간(타임스탬프)
	var end = new Date("2018/01/04 23:59:59").getTime(); //종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각

	if (start <= cur && cur <= end) {
		S_RANKING_PVP.make_screen_left = function () {
			//"TOP10"
			$('#Txt_RV_top10').text("TOP 5");
			$('#Txt_RV_top10').css({
				left: '109px',
				top: 117 + 34 + 'px',
				width: '98px',
				height: '26px',
				'line-height': '25px',
				'font-size': '24px',
				'text-align': 'center',
				'text-shadow': '1px 1px 1px black',
				'color': '#ffb200',//unfocus =>'#8e5b25', focus =>'#5e1f0e'
				position: 'absolute'
			});

			//"랭킹"
			$('#Txt_RV_left_rank').text(TXT.ranking);
			$('#Txt_RV_left_rank').css({
				left: '108px',
				top: 163 + 34 + 'px',
				width: '84px',
				height: '35px',
				'line-height': '34px',
				'font-size': '22px',
				'text-align': 'center',
				//'text-shadow':	'1px 1px 1px white',
				'color': '#672b0e',//unfocus =>'#8e5b25', focus =>'#5e1f0e'
				position: 'absolute'
			});

			//"아이디"
			if (gTARGET_PLATFORM == gPLATFORM.ENTRIX_CNM
				|| gTARGET_PLATFORM == gPLATFORM.ENTRIX_CJH
				|| gTARGET_PLATFORM == gPLATFORM.KT

			)
				$('#Txt_RV_left_id').text("이름");
			else
				$('#Txt_RV_left_id').text(TXT.id);
			$('#Txt_RV_left_id').css({
				left: '232px',
				top: 163 + 34 + 'px',
				width: '230px',
				height: '35px',
				'line-height': '34px',
				'font-size': '22px',
				'text-align': 'center',
				//'text-shadow':	'1px 1px 1px white',
				'color': '#672b0e',//unfocus =>'#8e5b25', focus =>'#5e1f0e'
				position: 'absolute'
			});
			//"레벨"
			$('#Txt_RV_left_level').text(TXT.level);
			$('#Txt_RV_left_level').css({
				left: '502px',
				top: 163 + 34 + 'px',
				width: '84px',
				height: '35px',
				'line-height': '34px',
				'font-size': '22px',
				'text-align': 'center',
				//'text-shadow':	'1px 1px 1px white',
				'color': '#672b0e',//unfocus =>'#8e5b25', focus =>'#5e1f0e'
				position: 'absolute'
			});

			//"점수"
			$('#Txt_RV_left_score').text(TXT.score);
			$('#Txt_RV_left_score').css({
				left: '626px',
				top: 163 + 34 + 'px',
				width: '230px',
				height: '35px',
				'line-height': '34px',
				'font-size': '22px',
				'text-align': 'center',
				//'text-shadow':	'1px 1px 1px white',
				'color': '#672b0e',//unfocus =>'#8e5b25', focus =>'#5e1f0e'
				position: 'absolute'
			});


			//$('#Txt_RV_info').text ("※ 매주 월요일 오전 5시에 초기화 됩니다. / ※ 보상지급 시기 : 매주 월요일 오전 5시");
			//$('#Txt_RV_info').text ("※ 보상 지급 및 랭킹 초기화 시기 : 매주 월요일 오전 5시");
			$('#Txt_RV_info').text("※ 보상 지급 및 랭킹 초기화 시기 : 매주 월요일 새벽 1시 ~ 새벽 6시"); //20170409_ywlee pvp대전 보상지급시기 표시 수정
			$('#Txt_RV_info').css({
				left: '71px',
				top: 577 + 'px',
				width: '822px',
				height: '35px',
				'line-height': '35px',
				'font-size': '18px',
				'text-align': 'center',
				'color': "#ffffff",
				position: 'absolute'
			});

			$('#Txt_RV_right1').text("PvP 결투장");
			$('#Txt_RV_right1').css({
				left: '998px',
				top: 296 + 'px',
				width: '158px',
				height: '43px',
				'line-height': '43px',
				'font-size': '28px',
				'text-align': 'center',
				'text-shadow': '1px 1px 1px black',
				'color': "#ffffff",
				position: 'absolute'
			});

			$('#Txt_RV_right2').text("보상");
			$('#Txt_RV_right2').css({
				left: '997px',
				top: 380 + 'px',
				width: '160px',
				height: '26px',
				'line-height': '26px',
				'font-size': '20px',
				'text-align': 'center',
				'color': "#ffb200",
				position: 'absolute'
			});

			//입장 가능 횟수
			var filename = './image/ui/13_ranking/pvp_freenumbox.png';
			$('#RV_enterance_num').text(TXT.pvp_free_enterance + STORAGE.data1.pvp_num + "회");
			$('#RV_enterance_num').css({
				left: '943px',
				top: 70 + 'px',
				width: '268px',
				height: '38px',
				"background": "url(" + filename + ") no-repeat 0 0",
				"background-position": "0px 0px",
				'line-height': '36px',
				'font-size': '19px',
				'text-align': 'center',
				'color': "#ffb200",
				position: 'absolute'
			});

			$('#RV_enterance_num_info1').text("* 일일 10회 무료 입장 가능");
			$('#RV_enterance_num_info1').css({
				left: 954 + 10 + 'px',
				top: 108 + 'px',
				width: '246px',
				height: '20px',
				'line-height': '20px',
				'font-size': '16px',
				'text-align': 'left',
				'color': "#672b0e",
				position: 'absolute'
			});
			$('#RV_enterance_num_info2').text("* 추가 입장시 5,000 골드 필요");
			$('#RV_enterance_num_info2').css({
				left: 954 + 10 + 'px',
				top: 108 + 20 + 'px',
				width: 246 + 'px',
				height: '20px',
				'line-height': '20px',
				'font-size': '16px',
				'text-align': 'left',
				'color': "#bf0202",
				position: 'absolute'
			});

			//PVP대전 입장료 반값 적용
			//--------------------------------------------------------------------------
			$('#RV_enterance_num_info2').text("* 추가 입장시 2,500 골드 필요");
			S_RANKING_PVP.need_gold = 2500;
			//--------------------------------------------------------------------------
		}
	} //end of if( start <= cur && cur <= end )
}



//업적(Quest) 2배 이벤트
DEFINEJS_EVENT.quest_double = function () {
	var start = new Date("2018/03/19 05:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2018/03/26 05:00:00").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각
	if (start <= cur && cur <= end) {
		for (i = 1; i <= QUEST_NUM; i++) {
			for (j = 1; j <= QUEST[i].num; j++) {
				QUEST[i].r_ruby[j] = QUEST[i].r_ruby[j] * 2;
				QUEST[i].r_gold[j] = QUEST[i].r_gold[j] * 2;
			}
		}
	}
}

//레벨업 이벤트 : 모든사용자 레벨업 할경우 먹인재료 등급 * 3개의 루비 지급
DEFINEJS_EVENT.levelup_ruby_event = function () {
	var start = new Date("2018/07/19 00:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2018/07/24 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각

	if (start <= cur && cur <= end) {
		S_CLEVELUP.yes = function () {
			bga('send', 'event', 'levelup', 'Char:' + STORAGE.data2[S_MAKETEAM.focus].ch_num, 'complete');

			//골드가 있는가 체크는 했음.
			//골드 차감
			USER.gold = USER.gold - S_CLEVELUP.need_gold;
			S_MAINMENU.make_screen_top(); // golde 차감 update


			//3. 강화진행
			//애니메이션
			S_CLEVELUP.flag_back_lock = 1; //애니메이션 시작 하니깐 history back key 먹게 하지 마라.
			S_CLEVELUP.effectRun(); //이벡트 실행 하라.

			//완료 화면에서 보여 주기 위핸 변하기 전의 값을 기억한다.
			var cur_level = STORAGE.data2[S_MAKETEAM.focus].cur_level;
			var max_level = STORAGE.data2[S_MAKETEAM.focus].max_level;
			var unit_num = STORAGE.data2[S_MAKETEAM.focus].ch_num;
			S_CLEVELUP_COMPLETE.before.mi = CAL.get_char_nm(unit_num, cur_level, max_level);
			S_CLEVELUP_COMPLETE.before.ap = CAL.get_char_ap(unit_num, cur_level);
			S_CLEVELUP_COMPLETE.before.hp = CAL.get_char_hp(unit_num, cur_level);

			var index = (S_CLEVELUP.focus >= S_MAKETEAM.focus) ? S_CLEVELUP.focus + 1 : S_CLEVELUP.focus; //여기 index가 S_MAKETEAM.focus 기준 index이다.

			//3.1같은캐릭이면 max_level을 5 올려 준다.
			if (STORAGE.data2[S_MAKETEAM.focus].ch_num == STORAGE.data2[index].ch_num) {
				var ch_num = STORAGE.data2[S_MAKETEAM.focus].ch_num;
				var star = CHAR_OUR_TEAM[ch_num].star;
				var star_max_level = (star + 3) * 10; // 4번 upgrade하면 1성은 최고 40level, 2성은 최고 50level 까지 upgrade할수 있다.
				var cur_max_level = STORAGE.data2[S_MAKETEAM.focus].max_level;

				if (cur_max_level <= star_max_level - 5) {
					STORAGE.data2[S_MAKETEAM.focus].max_level += 5;
					utilConsoleLog("Max Level changed: " + cur_max_level + "==>" + STORAGE.data2[S_MAKETEAM.focus].max_level);
				}
			}
			//3.2 강화가 얼마나 될 것인가?
			var exp = S_CLEVELUP.get_moreup_exp(index); //현재 선택된 캐릭터가 얼마나 경험치를 주는가?
			S_CLEVELUP.cal_moreup_exp(S_MAKETEAM.focus, exp); //구한 exp를 캐릭에 적용 시킨다.

			//20180718_ywlee 레벨업이벤트 (먹이는 별에 따른 루비 주기)-----시작----
			var ch_num = STORAGE.data2[index].ch_num;
			S_CLEVELUP_COMPLETE.lost_char_star_for_event = CHAR_OUR_TEAM[ch_num].star;
			//20180718_ywlee 레벨업이벤트 (먹이는 별에 따른 루비 주기)-----끝----

			//4. 강화 재료로 사용된 캐릭터 지우기
			STORAGE.del_char(index);

			//4.1 S_MAKETEAM.focus를 1뺄지 말지를 결정한다.
			if (S_MAKETEAM.focus > S_CLEVELUP.focus) {
				S_MAKETEAM.focus--;

				//2016-01-24 abs_focus도 빼 줘야, levelup_complete후에 다시 재자리 돌아 온다.
				if (S_MAKETEAM.abs_focus == 1) //막 팔기 하다가 첫번째에 focus가 가면
				{
					if (S_MAKETEAM.focus >= 5) {
						S_MAKETEAM.abs_focus = 5;
						S_MAKETEAM.scroll_cur_x = S_MAKETEAM.scroll_cur_x + 5 * (S_MAKETEAM.bottom_ch_w + S_MAKETEAM.bottom_ch_gap);
					}
					else {
						S_MAKETEAM.abs_focus = S_MAKETEAM.focus;
						S_MAKETEAM.scroll_cur_x = S_MAKETEAM.scroll_cur_x + S_MAKETEAM.focus * (S_MAKETEAM.bottom_ch_w + S_MAKETEAM.bottom_ch_gap);
					}
				}
				else
					S_MAKETEAM.abs_focus = S_MAKETEAM.abs_focus - 1;

			}
			S_MAKETEAM.bottom_ch_num--;

			//4.2 S_CLEVELUP.focus를 1뺄지 말지를 결정한다.
			S_CLEVELUP.bottom_ch_num = S_MAKETEAM.bottom_ch_num - 1;
			if (S_CLEVELUP.focus > S_CLEVELUP.bottom_ch_num) S_CLEVELUP.focus = S_CLEVELUP.bottom_ch_num;

			//5. 모든정보를 스토리지에 게억한다.
			STORAGE.save_all_info_to_storage("레벨업:" + unit_num);
		}

		S_CLEVELUP_COMPLETE.drawCenterScale = function () {
			utilScale_xy_center('CC_center', S_CLEVELUP_COMPLETE.scale.start, S_CLEVELUP_COMPLETE.scale.start);

			if (S_CLEVELUP_COMPLETE.scale.start >= S_CLEVELUP_COMPLETE.scale.end) {
				utilScale_xy_center('CC_center', 1.0, 1.0);
				gEnableKey = 1; //S_CLEVELUP.effectRun 에서  애니메이션 시작시 key lock을 여기서 풀어 준다.

				//20180718_ywlee 레벨업이벤트 (먹이는 별에 따른 루비 주기)-----시작----
				//if(USER.userpaid == 1)
				//{
				var ruby = S_CLEVELUP_COMPLETE.lost_char_star_for_event * 3;

				S_MAINMENU.make_screen_top_add_ruby(ruby); //star만큼 루비 보상하라.
				STORAGE.save_all_info_to_storage("루비보상:레벨업이벤트(" + S_CLEVELUP_COMPLETE.lost_char_star_for_event + "star):" + ruby + "개"); //모든 정보를 sotrage에 저장한다.
				save_UserInfo_after_pay_to_server(ruby, "레벨업이벤트(" + S_CLEVELUP_COMPLETE.lost_char_star_for_event + "star)");
				S_MAINMENU.make_screen_top();

				utilNotice("레벨업 이벤트로 루비 " + ruby + "개를 수령하였습니다.", 3.0);
				//}
				//20180718_ywlee 레벨업이벤트 (먹이는 별에 따른 루비 주기)-----끝----

			}
			else {
				S_CLEVELUP_COMPLETE.scale.start += S_CLEVELUP_COMPLETE.scale.gap;
				setTimeout(S_CLEVELUP_COMPLETE.drawCenterScale, EFFECT_INTERVAL);
			}
		}
	}
}


//특정캐릭터(진저맨 캐릭터) 뽑기확률 up
DEFINEJS_EVENT.pointed_char_gacha_up = function () {
	//2018.08.09 ~ 2018.08.31 진저맨 캐릭터 뽑기확률 UP
	var start = new Date("2018/08/08 00:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2018/08/31 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각

	var define_rnd = 20; //define_rnd확률로 특정 캐릭터가 뽑힌다.

	if (start <= cur && cur <= end) {
		S_GACHA_COMPLETE.get_gacha1 = function () {
			var rnd = Math.floor(Math.random() * 100 + 1); //1 ~ 100;

			if (rnd <= GACHA_PROBABILITY.gacha1[1]) //3성
			{
				GACHARESULT[1].star = 3;
			}
			else if (rnd <= (GACHA_PROBABILITY.gacha1[1] + GACHA_PROBABILITY.gacha1[2])) //2성
			{
				GACHARESULT[1].star = 2;
			}
			else {
				GACHARESULT[1].star = 1;
			}

			//20180615_ywlee 최초 무료 뽑일때는 2성 확정으로 주자,==> 처음시작해서 무료 뽑기까지 하면 2성 확정
			if (STORAGE.data1.chul_num == 1) GACHARESULT[1].star = 2;

			//나의 캐릭 중에서 해당 star를 찾는다. 그리고 랜덤으로 하나 부여 한다.
			var tmp_char = new Array(50);
			var count = 0;
			for (var i = 1; i <= MAX_OUR_TEAM_NUM; i++) {
				if (GACHARESULT[1].star == CHAR_OUR_TEAM[i].star) {
					count++;
					tmp_char[count] = i; //캐릭터 번호를 넣는다.
				}
			}

			var result = Math.floor(Math.random() * count + 1); //캐릭터 번호
			GACHARESULT[1].ch_num = tmp_char[result];

			//---진저맨 define_rnd %확률로 나오게하기 시작 ---
			var tmp_rnd = Math.floor(Math.random() * 100) + 1;
			if (tmp_rnd <= define_rnd) //나올 확률에 걸려 들었으면
			{
				if (GACHARESULT[1].star == 2) GACHARESULT[1].ch_num = 51; // 2성 진저맨
				else if (GACHARESULT[1].star == 3) GACHARESULT[1].ch_num = 52; // 3성 진저맨
			}
			//----진저맨 define_rnd %확률로 나오게하기 끝----


			//나의 스토리지에 추가.
			S_GACHA_COMPLETE.add_char();
		}

		S_GACHA_COMPLETE.get_gacha2 = function () {

			var rnd = Math.floor(Math.random() * 100 + 1);

			if (rnd <= GACHA_PROBABILITY.gacha2[1]) {
				GACHARESULT[1].star = 5;   //5성
			}
			else if (rnd <= (GACHA_PROBABILITY.gacha2[1] + GACHA_PROBABILITY.gacha2[2])) {
				GACHARESULT[1].star = 4;  //4성
			}
			else if (rnd <= (GACHA_PROBABILITY.gacha2[1] + GACHA_PROBABILITY.gacha2[2] + GACHA_PROBABILITY.gacha2[3])) {
				GACHARESULT[1].star = 3; //3성
			}
			else if (rnd <= (GACHA_PROBABILITY.gacha2[1] + GACHA_PROBABILITY.gacha2[2] + GACHA_PROBABILITY.gacha2[3] + GACHA_PROBABILITY.gacha2[4])) {
				GACHARESULT[1].star = 2;  //2성
			} else {
				GACHARESULT[1].star = 1; // 1성
			}

			//나의 캐릭 중에서 해당 star를 찾는다. 그리고 랜덤으로 하나 부여 한다.
			var tmp_char = new Array(50);
			var count = 0;
			for (var i = 1; i <= MAX_OUR_TEAM_NUM; i++) {
				if (GACHARESULT[1].star == CHAR_OUR_TEAM[i].star) {
					count++;
					tmp_char[count] = i; //캐릭터 번호를 넣는다.
				}
			}

			utilConsoleLog("Count =" + count);

			var result = Math.floor(Math.random() * count + 1); //캐릭터 번호
			GACHARESULT[1].ch_num = tmp_char[result];

			//---진저맨 define_rnd %확률로 나오게하기 시작 ---
			var tmp_rnd = Math.floor(Math.random() * 100) + 1;
			if (tmp_rnd <= define_rnd) //나올 확률에 걸려 들었으면
			{
				if (GACHARESULT[1].star == 2) GACHARESULT[1].ch_num = 51; // 2성 진저맨
				else if (GACHARESULT[1].star == 3) GACHARESULT[1].ch_num = 52; // 3성 진저맨
				else if (GACHARESULT[1].star == 4) GACHARESULT[1].ch_num = 53; // 4성 진저맨
				else if (GACHARESULT[1].star == 5) GACHARESULT[1].ch_num = 54; // 5성 진저맨
			}
			//----진저맨 define_rnd %확률로 나오게하기 끝----

			S_GACHA_COMPLETE.add_char();
		}

		S_GACHA_COMPLETE.get_gacha3 = function () {
			var rnd = Math.floor(Math.random() * 100 + 1);

			if (rnd <= GACHA_PROBABILITY.gacha3[1]) {
				GACHARESULT[1].star = 5; // 10%확율 : 5성
			} else if (rnd <= (GACHA_PROBABILITY.gacha3[1] + GACHA_PROBABILITY.gacha3[2])) {
				GACHARESULT[1].star = 4; // 35%확율 : 4성
			} else {
				GACHARESULT[1].star = 3; // 55%확율 : 3성
			}


			//나의 캐릭 중에서 해당 star를 찾는다. 그리고 랜덤으로 하나 부여 한다.
			var tmp_char = new Array(50);
			var count = 0;
			for (var i = 1; i <= MAX_OUR_TEAM_NUM; i++) {
				if (GACHARESULT[1].star == CHAR_OUR_TEAM[i].star) {
					count++;
					tmp_char[count] = i; //캐릭터 번호를 넣는다.
				}
			}

			utilConsoleLog("Count =" + count);

			var result = Math.floor(Math.random() * count + 1); //캐릭터 번호
			GACHARESULT[1].ch_num = tmp_char[result];


			//---진저맨 define_rnd %확률로 나오게하기 시작 ---
			var tmp_rnd = Math.floor(Math.random() * 100) + 1;
			if (tmp_rnd <= define_rnd) //나올 확률에 걸려 들었으면
			{
				if (GACHARESULT[1].star == 3) GACHARESULT[1].ch_num = 52; // 3성 진저맨
				else if (GACHARESULT[1].star == 4) GACHARESULT[1].ch_num = 53; // 4성 진저맨
				else if (GACHARESULT[1].star == 5) GACHARESULT[1].ch_num = 54; // 5성 진저맨
			}
			//----진저맨 define_rnd %확률로 나오게하기 끝----

			S_GACHA_COMPLETE.add_char();
		}

		S_GACHA_COMPLETE.get_gacha4 = function () {
			var rnd = new Array(GACHA_HOW_MANY + 1);

			for (var i = 1; i <= GACHA_HOW_MANY; i++) {
				rnd[i] = Math.floor(Math.random() * 100 + 1);


				if (rnd[i] <= GACHA_PROBABILITY.gacha4[1]) {
					GACHARESULT[i].star = 5; // 12%확율 : 5성
				} else if (rnd[i] <= (GACHA_PROBABILITY.gacha4[1] + GACHA_PROBABILITY.gacha4[2])) {
					GACHARESULT[i].star = 4; // 45%확율 : 4성
				} else {
					GACHARESULT[i].star = 3; // 43%확율 : 3성
				}


				//나의 캐릭 중에서 해당 star를 찾는다. 그리고 랜덤으로 하나 부여 한다.
				var tmp_char = new Array(50);
				var count = 0;
				for (var k = 1; k <= MAX_OUR_TEAM_NUM; k++) {
					if (GACHARESULT[i].star == CHAR_OUR_TEAM[k].star) {
						count++;
						tmp_char[count] = k; //캐릭터 번호를 넣는다.
					}
				}
				var result = Math.floor(Math.random() * count + 1); //캐릭터 번호

				GACHARESULT[i].ch_num = tmp_char[result];

				//---진저맨 define_rnd %확률로 나오게하기 시작 ---
				var tmp_rnd = Math.floor(Math.random() * 100) + 1;
				if (tmp_rnd <= define_rnd) //나올 확률에 걸려 들었으면
				{
					if (GACHARESULT[i].star == 3) GACHARESULT[i].ch_num = 52; // 3성 진저맨
					else if (GACHARESULT[i].star == 4) GACHARESULT[i].ch_num = 53; // 4성 진저맨
					else if (GACHARESULT[i].star == 5) GACHARESULT[i].ch_num = 54; // 5성 진저맨
				}
				//----진저맨 define_rnd %확률로 나오게하기 끝----

			}

			S_GACHA_COMPLETE.add_char();
		}

		S_GACHA_COMPLETE.get_gacha6 = function () {
			GACHARESULT[1].star = 5; //6성

			//나의 캐릭 중에서 해당 star를 찾는다. 그리고 랜덤으로 하나 부여 한다.
			var tmp_char = new Array(50);
			var count = 0;
			for (var i = 1; i <= MAX_OUR_TEAM_NUM; i++) {
				if (GACHARESULT[1].star == CHAR_OUR_TEAM[i].star) {
					count++;
					tmp_char[count] = i; //캐릭터 번호를 넣는다.
				}
			}

			utilConsoleLog("Count =" + count);

			var result = Math.floor(Math.random() * count + 1); //캐릭터 번호
			GACHARESULT[1].ch_num = tmp_char[result];

			//---진저맨 define_rnd %확률로 나오게하기 시작 ---
			var tmp_rnd = Math.floor(Math.random() * 100) + 1;
			if (tmp_rnd <= define_rnd) //나올 확률에 걸려 들었으면
			{
				GACHARESULT[1].ch_num = 54; // 6성 진저맨
			}
			//----진저맨 define_rnd %확률로 나오게하기 끝----

			S_GACHA_COMPLETE.add_char();
		}

		S_GACHA_COMPLETE.get_gacha7 = function () {
			GACHARESULT[1].star = 6; //6성

			//나의 캐릭 중에서 해당 star를 찾는다. 그리고 랜덤으로 하나 부여 한다.
			var tmp_char = new Array(50);
			var count = 0;
			for (var i = 1; i <= MAX_OUR_TEAM_NUM; i++) {
				if (GACHARESULT[1].star == CHAR_OUR_TEAM[i].star) {
					count++;
					tmp_char[count] = i; //캐릭터 번호를 넣는다.
				}
			}

			utilConsoleLog("Count =" + count);

			var result = Math.floor(Math.random() * count + 1); //캐릭터 번호
			GACHARESULT[1].ch_num = tmp_char[result];

			//---진저맨 define_rnd %확률로 나오게하기 시작 ---
			var tmp_rnd = Math.floor(Math.random() * 100) + 1;
			if (tmp_rnd <= define_rnd) //나올 확률에 걸려 들었으면
			{
				GACHARESULT[1].ch_num = 55; // 6성 진저맨
			}
			//----진저맨 define_rnd %확률로 나오게하기 끝----

			S_GACHA_COMPLETE.add_char();
		}
	}
}

//진저맨 도감 모두 모으면 루비 100개 증정
DEFINEJS_EVENT.bensi_charbook_reward = function () {
	var start = new Date("2019/01/22 00:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2019/02/28 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각

	if (start <= cur && cur <= end) {
		S_CHARBOOK_ALLY.reward_charbook_check = function () {

			if (ally_get_decx_char_number(S_CHARBOOK_ALLY.small_focus) != 6) {//6개를 수집을 못했으면 함수를 빠져나가라
				return;
			}

			//수집을 했다면 보상을 받았는지 확인해서 받지않았다면 보상을 받자
			if (ally_get_decx_reward(S_CHARBOOK_ALLY.small_focus) == 1) {
				var temp_num = "A" + S_CHARBOOK_ALLY.small_focus;

				if (USER.charbook_ally_reward == null || USER.charbook_ally_reward == "") { USER.charbook_ally_reward = temp_num + ""; }
				else { USER.charbook_ally_reward = USER.charbook_ally_reward + "," + temp_num; }

				//-----이벤트------
				if (S_CHARBOOK_ALLY.small_focus == 10) {
					S_MAINMENU.make_screen_top_add_ruby(100);
					utilNotice("벤시 도감을 완성하여 루비100개 수령합니다.", 3);
				}
				else {
					S_MAINMENU.make_screen_top_add_ruby(2);
					utilNotice(TXT.char_book_reward_text, 3);
				}
				//S_MAINMENU.make_screen_top_add_ruby(2);
				//utilNotice(TXT.char_book_reward_text,3);
				//------------------

				STORAGE.save_all_info_to_storage("아군 캐릭도감 완성 : " + temp_num); //모든 정보를 sotrage에 저장한다.
				save_UserInfo_after_pay_to_server(2, "아군 캐릭도감 완성 : " + temp_num);
				S_MAINMENU.make_screen_top();

				//보상을 받았다고 서버에 등록한다 .
				add_ally_reward(temp_num);

				utilDrawImage_no_wh_pos('CBA_big_char' + S_CHARBOOK_ALLY.small_focus + '_getruby_img', './image/ui/19_charbook/cb_rewardicon2.png', 1097, 7);
				$("#CBA_big_char" + S_CHARBOOK_ALLY.small_focus + "_getruby_text").text(TXT.char_book_reward_complete + "");

				//신규 new 표시를하자  보상을 받아서 비활성화
				utilDrawImage_no_wh_pos('CBA_small_card_' + S_CHARBOOK_ALLY.small_focus + '_new', '', S_CHARBOOK_ALLY.small_sx + ((i - 1) * 109) - 10, 513 - 10);
			}
		}

		//가장 코드가 적은 부분이라 가져옴. text로 우하단에 표시하기 위함임.
		S_CHARBOOK_ALLY.make_screen_menu = function () {
			$('#Txt_CBA_back').text(TXT.back);
			$('#CBA_start').text(TXT.gamestart);
			$('#CBA_start').css({ 'font-size': (USER.lang == LANG.ENGLISH) ? '22px' : '26px' });

			//-------이벤트시작---------
			var check_div = document.getElementById("CBA_temp_text");
			if (!check_div) //존재하지 않으면
			{
				var big_div = document.getElementById("S_CHARBOOK_ALLY_div");
				var tmp_div = document.createElement("div");
				tmp_div.id = "CBA_temp_text";
				big_div.appendChild(tmp_div);
			}

			$("#CBA_temp_text").css({
				left: '841px',
				top: '689px',
				width: '400px',
				height: '25px',
				color: '#faf800',
				//background : "yellow",
				'line-height': '25px',
				'font-size': '14px',
				'text-align': 'right',
				'text-shadow': '1px 1px 1px black',
				position: 'absolute'
			}).text("※이벤트기간(~2/28)에 벤시를 모두 모으면 루비100개 지급!!");


			//-------이벤트종료---------
		}
	}
}




//이름변경 공짜 이벤트 01.28 ~ 01.29  20190129_yhlee
DEFINEJS_EVENT.name_chabge_0ruby = function () {
	var start = new Date("2019/01/28 00:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2019/01/29 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각

	if (start <= cur && cur <= end) {
		g.name_change_ruby = 0;
	}
}






//20191226_yhlee PVP 랭킹 보상으로 아이템을 지급하는 이벤트
//PVP 랭킹 보상으로 아이템 지급 이벤트 해당하는 주 03.23 ~ 3.29
DEFINEJS_EVENT.pvp_item_reward = function () {
	//이 함수에서는 이벤트 기간중에 보여지는 event 이미지만 보여줄뿐 주간 보다 보상을 지급하는 php에서 지급합니다.
	// var start = new Date("2020/01/13 15:00:00").getTime();	//시작시간(타임스탬프)
	var start = new Date("2020/03/23 00:00:00").getTime();	//시작시간(타임스탬프)
	var end = new Date("2020/03/29 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();					   //현재시각

	if (start <= cur && cur <= end) {
		//이벤트중일경우 제일 적은 S_SELECTMAP.set_maxfocus 함수에서 이미지를 그립니다.
		//맵 선택화면에서 event 이미지 표시
		S_SELECTMAP.set_maxfocus = function () {
			S_SELECTMAP.maxfocus = STORAGE.get_maxmap();

			if (S_SELECTMAP.maxfocus > 5) S_SELECTMAP.page = 2;
			else S_SELECTMAP.page = 1;

			//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			//PVP 이벤트 관련 이미지를 그립니다.
			if (document.getElementById('Img_SM_pvp_event') == null) {
				var tmp_div = document.getElementById("S_SELECTMAP_div");
				var tmp_img = document.createElement("img"); //event 이미지
				tmp_img.id = "Img_SM_pvp_event";
				tmp_div.appendChild(tmp_img);
			}

			utilDrawImage_no_wh_pos('Img_SM_pvp_event', './image/sm_eventicon.png', SELECTMAP[11].fx + 5 + 3, SELECTMAP[11].fy + 5 - 21);
			//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		}

		//이벤트중일경우 제일 적은 S_RANKING_PVP.make_screen_menu 함수에서 이미지를 그립니다.
		//PVP 랭킹 화면에서 이벤트 관련 이미지 표시
		S_RANKING_PVP.make_screen_menu = function () {
			//이전, //게임시작
			$('#Txt_RV_back').text(TXT.back);
			$('#RV_start').text(TXT.rankingpvpstart);

			//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			//PVP 이벤트 관련 이미지를 그립니다.
			if (document.getElementById('RV_item_event1') == null) {
				var tmp_div = document.getElementById("S_RANKING_PVP_div");
				var tmp_img1 = document.createElement("img"); //event 이미지
				tmp_img1.id = "RV_item_event1";
				tmp_div.appendChild(tmp_img1);

				var tmp_img2 = document.createElement("img"); //칼문양 이미지
				tmp_img2.id = "RV_item_event2";
				tmp_div.appendChild(tmp_img2);
			}

			utilDrawImage_no_wh_pos('RV_item_event1', './image/sm_eventicon.png', 60 + 889, 94 + 166);
			utilDrawImage_no_wh_pos('RV_item_event2', './image/pvp_rewarditem_clock.png', 60 + 1107, 94 + 305);
			//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		}


		//메인화면에 배너에서 버튼 누르는경우 이벤트 항목으로 바로 가도록합니다
		//일단 이달의 캐릭터랑 롤링을 시켜보자
		S_MAINMENU.display_tip = function () {
			var MAX_TIP = 19; //팁의 수
			var tip = Math.floor(Math.random() * MAX_TIP) + 1;

			if (g.tutorial_mode == 1)	//최초 실행일 경우
				tip = 1;				//엘도라도를 꼭 찾아 주세요

			//일반팁일경우
			var text = eval('TXT.tip_' + tip);
			var tip_view = 1; //((Math.floor(Math.random()*10)+1) >= 9)? 1: 0; //10%확율로 tip을 보여 주자. -->무조건 보여 주자
			$('#TXT_MM_tip').css({
				'display': (tip_view == 1) ? 'block' : 'none',
				//'display': 'block', //test
				left: 219 + 'px',
				top: 83 + 'px',
				width: 847 + 'px',
				height: 59 + 'px',
				//background:'black',
				'background': 'url(./image/ui/1_mainmenu/mm_tipbox.png) no-repeat 0 0',
				'background-position': '0px 0px',
				//opacity: "0.7",
				'line-height': 59 + 12 + 'px',
				'font-size': (USER.lang == LANG.ENGLISH && tip == 7) ? '16px' : '18px',
				'text-align': 'center',
				//'text-shadow': '1px 1px 1px white',
				//'font-weight': 'bold',
				'border-radius': '5px',
				'color': 'white',
				position: 'absolute'
			});

			//상황에 맞은 팁

			//텍스트 보여 주기
			$('#TXT_MM_tip').text(/*"Tip: "+*/text);

			//이달의 캐릭터
			// if(char_event_filename != null)
			// 	utilDrawImage_no_wh_pos( 'Img_chevent_october'	,'./image/'+char_event_filename,1065,73);

			//이벤트 배너를 등록하기위해서 밑에 함수에서 롤링합니다
			S_MAINMENU.event_banner_timer();

			//루비 받기 앱 홍보 이미지 왼쪽에 등록 20180828_yhlee
			// utilDrawImage_no_wh_pos('Img_rubytakeapp','./image/mm_adbox_kor.png',11,73);
		}


		var event_timer = 0;
		var event_start_timestamp = 0;
		var event_timestamp_flag = 0;
		var event_change_time = 15000;//바뀌는 시간 15초
		S_MAINMENU.event_banner_timer = function () {
			if (g_sceneinfo.cur_scene != gS_MAINMENU) {
				clearInterval(event_timer);
				event_timer = null;
				event_timestamp_flag = 0;
				return;
			}


			switch (event_timestamp_flag) {
				case 0:
					event_start_timestamp = g.timestamp_due;
					event_timestamp_flag = 1;
					if (event_timer != null) {
						clearInterval(event_timer);
						event_timer = null;
					}
					event_timer = setTimeout(function () { S_MAINMENU.event_banner_timer() }, 100);
					break;
				case 1:
					if ((event_start_timestamp + event_change_time) >= g.timestamp_due) {
						utilDrawImage_no_wh_pos('Img_chevent_october', './image/mm_eventshortcut_20200323_kt.png', 1065, 73);//아이템 이벤트
						if (event_timer != null) {
							clearInterval(event_timer);
							event_timer = null;
						}
						event_timer = setTimeout(function () { S_MAINMENU.event_banner_timer() }, 1000);
					}
					else {
						event_start_timestamp = g.timestamp_due;
						event_timestamp_flag = 2;
						if (event_timer != null) {
							clearInterval(event_timer);
							event_timer = null;
						}
						event_timer = setTimeout(function () { S_MAINMENU.event_banner_timer() }, 100);
					}
					break;
				case 2:
					if ((event_start_timestamp + event_change_time) >= g.timestamp_due) {
						utilDrawImage_no_wh_pos('Img_chevent_october', './image/mm_chevent_march_all_kor.png', 1065, 73);//이달의 캐릭
						if (event_timer != null) {
							clearInterval(event_timer);
							event_timer = null;
						}
						event_timer = setTimeout(function () { S_MAINMENU.event_banner_timer() }, 1000);
					}
					else {
						event_start_timestamp = g.timestamp_due;
						event_timestamp_flag = 0;
						if (event_timer != null) {
							clearInterval(event_timer);
							event_timer = null;
						}
						event_timer = setTimeout(function () { S_MAINMENU.event_banner_timer() }, 100);
					}
					break;
			}
		}

		S_MAINMENU.keyDown = function () {
			var keyCode = event.keyCode;

			/*  컨셉 변경으로 주석 처리함
				if (gTARGET_PLATFORM == gPLATFORM.KT
				&& S_ERROR_NETWORK.code == 1
				&& (keyCode == KeyDefine.enter || keyCode == KeyDefine.RED)
				)
				{
					ChangeScene.start(g_sceneinfo.cur_scene,gS_ERROR_NETWORK,S_ERROR_NETWORK);
					return;
				}
			*/
			//utilConsoleLog ("Key pressed: " + keyCode + " in S_MAINMENU.keyDown()");
			switch (keyCode) {
				case KeyDefine.left:
					if (S_MAINMENU.focus >= 2 && S_MAINMENU.focus <= MAINMENU_NUM - 1) {
						S_MAINMENU.focus = S_MAINMENU.focus - 1;
						S_MAINMENU.drawFocus();
					}
					else if (S_MAINMENU.focus == 1) {
						// 컨셉이 햇갈려 해서 아래 내용 주석 처리 함. 2016.01.13
						//S_MAINMENU.focus = MAINMENU_NUM; //rotate를 위해
						//S_MAINMENU.drawFocus();
					} else if (S_MAINMENU.focus == MAINMENU_NUM) //mainmenu에 focus가 있는데 왼쪽누르면, .오른쪽 끝메뉴로 가라
					{
						// 컨셉이 햇갈려 해서 아래 내용 주석 처리 함. 2016.01.13
						//S_MAINMENU.focus = MAINMENU_NUM-1;
						//S_MAINMENU.drawFocus();
					}

					break;
				case KeyDefine.right:
					if (S_MAINMENU.focus < MAINMENU_NUM - 1) {
						S_MAINMENU.focus = S_MAINMENU.focus + 1; //set language 추가시 넣기
						S_MAINMENU.drawFocus();
					}
					else if (S_MAINMENU.focus == MAINMENU_NUM - 1) //rotate를 위해
					{
						// 컨셉이 햇갈려 해서 아래 내용 주석 처리 함. 2016.01.13
						//S_MAINMENU.focus = MAINMENU_NUM;
						//S_MAINMENU.drawFocus();
					} else if (S_MAINMENU.focus == MAINMENU_NUM) //mainmenu에 focus가 있는데 오른쪽 누르면, 제일 앞쪽 메뉴로 가라.
					{
						// 컨셉이 햇갈려 해서 아래 내용 주석 처리 함. 2016.01.13
						//S_MAINMENU.focus = 1;
						//S_MAINMENU.drawFocus();
					}
					break;

				case KeyDefine.up:
					if (S_MAINMENU.focus == MAINMENU_NUM) {
						S_MAINMENU.focus = S_MAINMENU.backup_focus;
						S_MAINMENU.drawFocus();
					}
					break;
				case KeyDefine.down:
					if (S_MAINMENU.focus < MAINMENU_NUM) {
						S_MAINMENU.backup_focus = S_MAINMENU.focus;
						S_MAINMENU.focus = MAINMENU_NUM;
						S_MAINMENU.drawFocus();
					}
					break;
				case KeyDefine.enter: // enter
					S_MAINMENU.menuRun();
					break;
				case KeyDefine.back: //back
					//KT의 경우 :   부싯돌게임 포탈로 이동하시겠습니까? 20170810_ywlee
					if (gTARGET_PLATFORM == gPLATFORM.KT) {
						//$('#Img_ST_card_focus_'+S_SETTING.focus).css({'display': "none" }); //focus 화면에 없어지게하기
						ChangeScene.start(g_sceneinfo.cur_scene, gS_POPUPYN, S_POPUPYN);
					}
					/*
										if (gTARGET_PLATFORM == gPLATFORM.KT) {
											// S_EXITPOPUP.start();
											return -1;
										}
					*/
					break;
				case KeyDefine.CHANNEL_UP:
				case KeyDefine.CHANNEL_DOWN:
					if (gTARGET_PLATFORM == gPLATFORM.KT) {
						// S_EXITPOPUP.start();
						return -1;
					}
					break;
				//		case KeyDefine.exit:
				//					tizen.application.getCurrentApplication().hide();
				//					break;

				case KeyDefine.space:
					if (gAPP_RELEASE != "TEST") return; // test일때는 space bar가 RED key로 동작
				case KeyDefine.RED:
					if (gTARGET_PLATFORM == gPLATFORM.ENTRIX_CNM
						|| gTARGET_PLATFORM == gPLATFORM.ENTRIX_CJH
						|| gTARGET_PLATFORM == gPLATFORM.KT
					) //이용안내.
					{

						S_MAINMENU.end(); //마우스 및 타이머 죽이기
						$("#MM_main_focus").css({ "display": "none" });
						$("#MM_sub_focus").css({ "display": "none" });
						//utilPush();//history back을 위해 현재 화면을 저장해 둔다.
						// $('#S_USERGUIDE_div').css({'display': "block"});// remove it 4.5.2016
						// S_USERGUIDE.init();// remove it 4.5.2016
						ChangeScene.start(g_sceneinfo.cur_scene, gS_USERGUIDE, S_USERGUIDE);
					}
					break;
				case KeyDefine.BLUE:
					if (gTARGET_PLATFORM == gPLATFORM.KT) // 부싯돌월드
					{

						var URL = "http://appsbusidol.cafe24.com/kt/get_location_url.php";
						var sendData = {};
						$.ajax({
							url: URL,
							type: 'POST',
							data: sendData,
							timeout: 5000, /* Timeout in ms */
							success: function (oData) {
								// util.log(" success:  check_ip_blocking_in_server return_code:"+oData);
								window.location = oData;
							},
							error: function (xhr) {
								ChangeScene.start(g_sceneinfo.cur_scene, gS_ERROR_NETWORK, S_ERROR_NETWORK);
							}
						});
					}
					break;
				//~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!
				//이벤트 때문에 블루 버튼을 추가합니다
				case 77:// m 버튼
					if (gAPP_RELEASE != "TEST") return; // test일때는 m키가  blue key로 동작
				case KeyDefine.PLAY:
				case 179:
					if (!USER.can_I_enter_PvP()) {
						utilNotice(TXT.not_enter_ranking_game, 1.2);
						return;
					}
					S_MAINMENU.end(); //마우스 및 타이머 죽이기
					$("#MM_main_focus").css({ "display": "none" });
					$("#MM_sub_focus").css({ "display": "none" });

					S_GAME.ranking_mode = 2;
					ChangeScene.start(g_sceneinfo.cur_scene, gS_RANKING_PVP, S_RANKING_PVP);
					break;
				//~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!
				case KeyDefine.LEVELUP:
					//case KeyDefine.NUM7: //테스트를 위해 스테이지 70까지 클리어 시켜 주기
					if (gAPP_RELEASE == "TEST") {
						if (USER.level <= 90) {
							USER.level = USER.level + 8;
							utilNotice("Test를 위해 사용자 Level을 +10으로 올렸습니다. 수고혀~~", 1.2);
							STORAGE.save_all_info_to_storage("테스트:사용자레벨업:+18"); //모든 정보를 sotrage에 저장한다.
							S_MAINMENU.make_screen_top();
						}
					}
					break;
				case KeyDefine.OPENSTAGE:
					//case KeyDefine.NUM8: //테스트를 위해 스테이지 99까지 클리어 시켜 주기
					if (gAPP_RELEASE == "TEST") {
						var open = MAX_STAGE_NUM - 1;

						for (var i = 1; i <= open; i++) {
							/*
							switch(Math.floor(Math.random()*4.5))
							{
								case 0:
								case 1: STORAGE.data3[i] = "A"; break;
								case 2: STORAGE.data3[i] ="B";	break;
								case 3: STORAGE.data3[i] ="C";	break;
								default: STORAGE.data3[i] ="D"; break;
							}
							*/
							STORAGE.data3[i] = "A";
						}

						STORAGE.data3[open + 1] = "T";
						for (var i = open + 2; i <= MAX_STAGE_NUM; i++) {
							STORAGE.data3[i] = "X";
						}
						STORAGE.save_all_info_to_storage("테스트:스테이지Open:" + open); //모든 정보를 sotrage에 저장한다.
						utilNotice("Test를 위해 " + open + "stage까지 열어 두었습니다. Good Game!~", 1.2);
						S_MEDALPOWER.cal_power();
					}
					break;
				case KeyDefine.SHOWMETHEMONEY:
					if (gAPP_RELEASE == "TEST") {
						//USER.gold = USER.gold + 100000;
						S_MAINMENU.make_screen_top_add_gold(100000);

						ServerConnection.add_bonus_point(100, "치트키 ");
						USER.bonus_point = USER.bonus_point + 100;

						//USER.ruby = USER.ruby + 100;
						S_MAINMENU.make_screen_top_add_ruby(100);
						utilNotice("골드 10000, 크리스탈 100개를 추가 하였습니다. 즐~게임", 1.5);
						STORAGE.save_all_info_to_storage("테스트:ShowMeTheMoney"); //모든 정보를 sotrage에 저장한다.
						save_UserInfo_after_pay_to_server(100, "치트키");
						S_MAINMENU.make_screen_top();
					}
					break;
				case KeyDefine.GAMEINIT:
					//case KeyDefine.NUM0: //테스트를 위해 숫자 0은 초기화
					if (gAPP_RELEASE == "TEST") {
						utilNotice("초기화 합니다. LocalStorage정보도 초기화 합니다.", 1.5);

						if (gTARGET_PLATFORM == gPLATFORM.ENTRIX_CNM
							|| gTARGET_PLATFORM == gPLATFORM.KT
						) {
							delete_user_in_server();
						}
						else {
							localStorage.clear(); //
							STORAGE.init_firstUser(); //최초 사용자일경우의 변수 값 설정 STORAGE.data1,data2,data3
							STORAGE.save_all_info_to_storage("테스트:초기화"); //모든 정보를 sotrage에 저장한다.
							get_id_from_server(); //서버로 부터 ID를 생성 받아라.
							getCountry_usingIP(); //나의 IP를 기준으로 나라 코드값을 받아라
							STORAGE.load_n_parse(); //저장한후 다시 환경 변수들을 불러 온다.
						}
						clearInterval(S_MAINMENU.interval);
						S_MAINMENU.interval = null;

						S_MAINMENU.init();
						//					S_MAINMENU.make_screen_top();
					}
					break;

				case KeyDefine.UPGRADE: // "u" 버턴
					if (gAPP_RELEASE == "TEST") {
						STORAGE.data1.upgrade[1] = 90;
						STORAGE.data1.upgrade[2] = 90;
						STORAGE.data1.upgrade[3] = 90;
						STORAGE.data1.upgrade[4] = 90;
						STORAGE.data1.upgrade[5] = 90;
						STORAGE.data1.upgrade[6] = 20;
						MAX_OUR_TEAM_NUM_ON_SCREEN = STORAGE.data1.upgrade[6]; //이부장님 지적
						STORAGE.save_all_info_to_storage("테스트:업그레이드"); //모든 정보를 sotrage에 저장한다.
						utilNotice("UPGRADE메뉴 모두 90으로~~ good game~~^^", 1.5);
					}
					break;
				case KeyDefine.NUM2:
				case KeyDefine.DEBUG: //테스트를 위해 debug창을 on/off한다.
					if (gAPP_RELEASE == "TEST") {
						// $('#LOGLOG').css({display:'block'});

						gEntrix.is_model = false;
						ChangeScene.start(g_sceneinfo.cur_scene, gS_ERROR_NETWORK, S_ERROR_NETWORK);
					}
					break;
				case KeyDefine.NUM1: //테스트를 위해 숫자 1은 ID 고정(IceHunter_862)
					// 20220727_dblee_시원한 여름날의 출석부 이벤트 - 이벤트 출석부 진입시 마다 데이터를 읽어 온다.
					// 데이터를 읽어 오면서 기간 종료 등 알려준다.
					if (glo.APP_FEATURE.ATTENDANCE_EVENT) {
						if (!$('#AE_main_icon').html()) return; // 아이콘이 없으면 동작하지 말라.
						loading_show();
						ServerConnection.attendance_event({ MODE: "SHOW" }, function (json_data) {
							loading_hide();

							if (json_data.TYPE == "EVENT_END") {
								if (USER.lang == LANG.KOREA)
									utilNotice(json_data.DESCRIPTION, 2);
								else
									utilNotice(json_data.DESCRIPTION_EN, 2);
							}
							else {
								S_MAINMENU.end();
								// 이벤트 종료 기간이면 화면을 보여준다.
								if (gTARGET_PLATFORM == gPLATFORM.TIZEN_TV || gTARGET_PLATFORM == gPLATFORM.LGWEBOS_TV || gTARGET_PLATFORM == gPLATFORM.KT) {
									ChangeScene.start(g_sceneinfo.cur_scene, gS_ATTENDANCE_EVENT, S_ATTENDANCE_EVENT);
								}
								else {
									utilPush();//history back을 위해 현재 화면을 저장해 둔다.
									$('#S_MAINMENU_div').css({ 'display': "none" });
									S_ATTENDANCE_EVENT.init();
								}
							}
						});
					}
					break;
				case KeyDefine.NUM3:
					if (gAPP_RELEASE == "TEST") {
						//첫구매이벤트 시작
						S_MAINMENU.end();
						$("#MM_main_focus").css({ "display": "none" });
						$("#MM_sub_focus").css({ "display": "none" });

						$('#S_EVENT_div').css({ 'display': "block" });
						S_EVENT.status = 2; // 첫 구매이벤트이다.
						S_EVENT.init();
					}
					break;
				case KeyDefine.NUM4: //테스트를 위해 100 level 클리어한 사용자 정보 가지고 오기.
					if (gAPP_RELEASE == "TEST") {
						utilNotice("우편함 테스트를 위해 우편함에 보상을 지급 합니다.", 3.0);

						ServerConnection.put_reward_char('GOLD', 'TEST GOLD 보상', 10);
						ServerConnection.put_reward_char('BP', 'TEST BP 보상', 5);
						ServerConnection.put_reward_char('RUBY', 'TEST RUBY 보상', 10);
						for (var i = 1; i <= 3; i++) {
							var rnd = Math.floor(Math.random() * 68 + 1); //1 ~ 100;
							utilConsoleLog("~~ 우편함에 캐릭터 보상 등록 ~~ " + rnd);
							ServerConnection.put_reward_char('CHAR', 'TEST CHAR 보상', rnd);
						}
					}
					break;

				case KeyDefine.NUM5: //테스트를 위해 100 level 클리어한 사용자 정보 가지고 오기.
					if (gAPP_RELEASE == "TEST") {
						utilNotice("119 Stage 클리어한 히어로에코님의 정보로 setting 합니다.", 3.0);
						var data1 = "23721596980,4946242,2571,1,KR,1,2,1,100,0,12449420,20180219,174,1519004730000,1:2:3:4:5,40:31:61:51:3,20171219_1:20180108_1:20180113_1:20180112_1:20180201_1,0";
						var data2 = "30:70:70:0,19:70:70:0,14:70:70:0,36:70:70:0,24:70:70:0,35:65:65:0,29:65:65:0,13:60:60:0,8:75:75:0,18:70:70:0,23:70:70:0,22:55:55:0,7:55:55:0,34:65:65:0,17:50:50:0,33:40:40:0,16:45:45:0,21:40:40:0,11:40:40:0,27:40:40:0,39:55:55:0,15:35:35:0,5:35:35:0,20:35:35:0,38:40:40:0,10:45:45:0,2:20:20:0,0:20:20:0,0:20:20:0,0:20:20:0";
						var data3 = "A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,D,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,T";
						update_user_to_server_test(data1, data2, data3);
						setTimeout(function () {
							history.go(0);
						}, 2000);
					}
					break;
				case KeyDefine.NUM6: //테스트를 위해 100 level 클리어한 사용자 정보 가지고 오기.
					if (gAPP_RELEASE == "TEST") {
						utilNotice("월드보스 1등, PVP 1~3등 유저 정보로 setting 합니다.", 3.0);
						var data1 = "17427616370,134428119,2558,1,KR,1,2,2,140,0,2575882,20190909,660,1567971743018,1:2:0:0:0,140:140:140:140:140:20:30:100,20190726_2:20190726_3:20190809_1:20190823_1:20190901_1,10";
						var data2 = "68:100:100:0:1,48:100:100:0:1,64:100:100:0:1,64:100:100:0:1,68:95:100:4200:1,67:80:95:3125:1,65:100:100:0:1,66:88:100:250:1,68:1:80:0:0,56:95:95:0:1,63:95:95:0:1,48:100:100:0:1,56:100:100:0:1,49:95:95:0:1,67:100:100:0:1,66:100:100:0:1,65:100:100:0:1,63:100:100:0:1,50:100:100:0:1,62:95:95:0:1,9:65:85:800:0,36:53:80:500:0,19:53:80:500:0,55:37:75:900:0,47:1:70:0:0,30:1:70:0:0,42:1:70:0:0,14:1:70:0:0,35:44:70:550:0,46:62:80:2400:0,23:31:65:250:0,54:1:60:0:0,13:44:70:550:0,41:31:65:250:0,60:54:75:800:0,18:54:75:800:0,29:31:65:250:0,41:1:60:0:0,41:1:60:0:0,8:1:60:0:0,8:1:60:0:0,46:1:60:0:0,46:1:60:0:0,17:50:70:300:0,28:50:70:300:0,59:50:70:300:0,34:50:70:300:0,45:50:70:300:0,53:50:70:300:0,12:43:65:750:0,22:50:70:300:0,28:50:70:300:0,40:50:70:300:0,34:50:70:300:0,7:50:70:300:0,7:50:70:300:0,59:50:70:300:0,7:24:55:1050:0,34:50:70:300:0,17:35:60:550:0,53:35:60:550:0,28:43:65:750:0,34:1:50:0:0,34:1:50:0:0,59:1:50:0:0,59:1:50:0:0,59:1:50:0:0,59:1:50:0:0,28:1:50:0:0,53:1:50:0:0,53:1:50:0:0,40:1:50:0:0,27:37:60:900:0,33:37:60:900:0,39:37:60:900:0,58:32:55:650:0,11:37:60:900:0,6:37:60:900:0,16:56:60:1950:0,33:37:60:900:0,33:32:55:650:0,52:37:60:900:0,27:26:50:500:0,21:37:60:900:0,39:37:60:900:0,16:18:45:500:0,11:32:55:650:0,6:18:45:500:0,44:32:55:650:0,52:32:55:650:0,21:1:40:0:0,58:1:40:0:0,26:21:45:500:0,57:40:40:0:0,10:1:30:0:0,5:1:30:0:0,15:1:30:0:0,4:6:25:0:0,1:1:20:0:0,37:1:20:0:0";
						var data3 = "A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A";
						update_user_to_server_test(data1, data2, data3);
						setTimeout(function () {
							history.go(0);
						}, 2000);
					}
					break;
				case KeyDefine.NUM9:
					if (gAPP_RELEASE == "TEST") {
						utilNotice("신규 추가 캐릭으로 셋팅 합니다.", 3.0);
						var data1 = "14875899400,7215480,121,1,KR,1,2,1,1,0,2838860,20180219,183,1518957608000,1:2:3:4:5,57:51:92:94:40,20171219_1:20180108_1:20180113_1:20180112_1:20180201_1,10";
						var data2 = "69:20:20:0,70:30:30:0,71:40:40:0,72:50:50:0,73:60:60:0,74:70:70:0,75:80:80:0,74:70:70:0,75:80:80:0,74:70:70:0,75:80:80:0,74:70:70:0,75:80:80:0,69:20:20:0,70:30:30:0,71:40:40:0,72:50:50:0,73:60:60:0,74:70:70:0,75:80:80:0,69:20:20:0,70:30:30:0,71:40:40:0,72:50:50:0,73:60:60:0,74:70:70:0,75:80:80:0,68:100:100:0:1,48:100:100:0:1,64:100:100:0:1";
						// var data2 = '51:50:50:0,52:60:60:0,53:70:70:0,54:80:80:0,55:90:90:0,56:90:90:0,56:79:80:0,56:80:80:0,56:80:80:0,56:80:80:0,56:80:80:0,56:80:80:0,56:80:80:0,30:90:90:0,30:90:90:0,30:90:90:0,30:90:90:0,30:90:90:0,30:90:90:0,30:90:90:0,30:90:90:0,50:1:80:0,50:1:80:0,50:1:80:0,50:1:80:0,24:90:90:0';
						// var data2 = "49:80:80:1:NO:0,50:80:80:1:NO:0,48:80:80:1:NO:0,47:70:70:1:NO:0,42:70:70:1:NO:0,36:70:70:1:NO:0,9:90:90:0:NO:0,14:90:90:0:NO:0,19:90:90:0:NO:0";
						// var data2 = '57:20:30:0,58:30:40:0,59:40:50:0,60:50:60:0,61:60:70:0,62:70:80:0,2:1:20:1,10:1:30:1,11:1:40:1,12:1:50:1,13:1:60:1,14:1:70:1';
						// var data3 = "A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A";
						var data3 = "T,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X,X";
						update_user_to_server_test(data1, data2, data3);
						setTimeout(function () {
							history.go(0);
						}, 2000);
					}
					break;
			}
		}




	}
};


//20190308_yhlee
//보스전이 베타 버전이면 true 아니면 false를 리턴합니다.
//정식후에는 false만을 리턴해야합니다.  현재 베타 버전에서는 true를 리턴합니다.
DEFINE.boss_beta_version_check = function () {
	//베타 버전이냐 아니냐에 따라서 보스 랭킹화면에서 텍스트가 변경된다 그러기 위해서 이함수를 사용합니다.
	return false;
}

//20190308_yhlee
//보스전에 입장 가능한지를 리턴합니다.  특정 오류가 있을경우 여기의 플러그를 -1로 변경하면 보스전 입장이 불가능합니다  1 은 입장 가능입니다.
DEFINE.boss_goin_check = function () {
	//혹시나 보스전에 문제가 생기면 -1을 주면 보스전에 진입을 하지못합니다.
	BOSS_GOIN_FLAG = 1;//입장 가능
	return;


	//베타버전 종료일
	var end = new Date("2019/03/28 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각
	if (end < cur)
		BOSS_GOIN_FLAG = -1;//입장 불가
	else
		BOSS_GOIN_FLAG = 1;//입장 가능
}

//20201110_yhlee
//요일던전이 베타 버전이면 true 아니면 false를 리턴합니다.
//정식후에는 false만을 리턴해야합니다.  현재 베타 버전에서는 true를 리턴합니다.
DEFINE.daydungeon_beta_version_check = function () {
	return false;// 정식버전

	//베타버전 종료일
	var end = new Date("2020/11/20 23:59:59").getTime();	//종료시간(타임스탬프)
	var cur = new Date().getTime();						//현재시각
	if (end < cur)
		return false;// 정식버전
	else
		return true;// 베타버전


}


DEFINEJS_EVENT.packge_banner = function () {
	var curtime = parseInt(g.timestamp_start, 10) + parseInt(g.timestamp_due, 10);//현재시간

	if (curtime == 0 || curtime == null) {
		setTimeout(DEFINEJS_EVENT.packge_banner, 500);
		return;
	}

	if (S_PACKAGE_ITEM.start_time <= curtime && curtime <= S_PACKAGE_ITEM.end_time) {
		utilConsoleLog("~~패키지 상품 구매 이벤트 진행중 ~~ DEFINEJS_EVENT.packge_banner()");

		//이달의 캐릭터 그려라는 명령을 줄때 가장 길이가 짧은 함수가 display_tip()이라서 여기것을 사용 함.
		S_MAINMENU.display_tip = function () {
			var MAX_TIP = 19; //팁의 수
			var tip = Math.floor(Math.random() * MAX_TIP) + 1;

			if (g.tutorial_mode == 1)	//최초 실행일 경우
				tip = 1;				//엘도라도를 꼭 찾아 주세요

			//일반팁일경우
			var text = eval('TXT.tip_' + tip);
			var tip_view = 1; //((Math.floor(Math.random()*10)+1) >= 9)? 1: 0; //10%확율로 tip을 보여 주자. -->무조건 보여 주자
			$('#TXT_MM_tip').css({
				'display': (tip_view == 1) ? 'block' : 'none',
				//'display': 'block', //test
				left: 219 + 'px',
				top: 83 + 'px',
				width: 847 + 'px',
				height: 59 + 'px',
				//background:'black',
				'background': 'url(./image/ui/1_mainmenu/mm_tipbox.png) no-repeat 0 0',
				'background-position': '0px 0px',
				//opacity: "0.7",
				'line-height': 59 + 12 + 'px',
				'font-size': (USER.lang == LANG.ENGLISH && tip == 7) ? '16px' : '18px',
				'text-align': 'center',
				//'text-shadow': '1px 1px 1px white',
				//'font-weight': 'bold',
				'border-radius': '5px',
				'color': 'white',
				position: 'absolute'
			});

			//상황에 맞은 팁

			//텍스트 보여 주기
			$('#TXT_MM_tip').text(/*"Tip: "+*/text);

			//패키지 홍보 배너 등록
			utilDrawImage_no_wh_pos('Img_chevent_october', './image/mm_eventshortcut_20200710_kt.png', 1065, 73);

			//루비 받기 앱 홍보 이미지 왼쪽에 등록 20180828_yhlee
			// utilDrawImage_no_wh_pos('Img_rubytakeapp','./image/mm_adbox_kor.png',11,73);
		}


		S_MAINMENU.keyDown = function () {
			var keyCode = event.keyCode;
			switch (keyCode) {
				case KeyDefine.left:
					if (S_MAINMENU.focus >= 2 && S_MAINMENU.focus <= MAINMENU_NUM - 1) {
						S_MAINMENU.focus = S_MAINMENU.focus - 1;
						S_MAINMENU.drawFocus();
					}

					break;
				case KeyDefine.right:
					if (S_MAINMENU.focus < MAINMENU_NUM - 1) {
						S_MAINMENU.focus = S_MAINMENU.focus + 1; //set language 추가시 넣기
						S_MAINMENU.drawFocus();
					}
					break;

				case KeyDefine.up:
					if (S_MAINMENU.focus == MAINMENU_NUM) {
						S_MAINMENU.focus = S_MAINMENU.backup_focus;
						S_MAINMENU.drawFocus();
					}
					break;
				case KeyDefine.down:
					if (S_MAINMENU.focus < MAINMENU_NUM) {
						S_MAINMENU.backup_focus = S_MAINMENU.focus;
						S_MAINMENU.focus = MAINMENU_NUM;
						S_MAINMENU.drawFocus();
					}
					break;
				case KeyDefine.enter: // enter
					S_MAINMENU.menuRun();
					break;
				case KeyDefine.back: //back
					//KT의 경우 :   부싯돌게임 포탈로 이동하시겠습니까? 20170810_ywlee
					if (gTARGET_PLATFORM == gPLATFORM.KT) {
						//$('#Img_ST_card_focus_'+S_SETTING.focus).css({'display': "none" }); //focus 화면에 없어지게하기
						ChangeScene.start(g_sceneinfo.cur_scene, gS_POPUPYN, S_POPUPYN);
					}
					break;
				case KeyDefine.CHANNEL_UP:
				case KeyDefine.CHANNEL_DOWN:
					if (gTARGET_PLATFORM == gPLATFORM.KT) {
						// S_EXITPOPUP.start();
						return -1;
					}
					break;
				case KeyDefine.space:
					if (gAPP_RELEASE != "TEST") return; // test일때는 space bar가 RED key로 동작
				case KeyDefine.RED:
					if (gTARGET_PLATFORM == gPLATFORM.ENTRIX_CNM
						|| gTARGET_PLATFORM == gPLATFORM.ENTRIX_CJH
						|| gTARGET_PLATFORM == gPLATFORM.KT
					) //이용안내.
					{

						S_MAINMENU.end(); //마우스 및 타이머 죽이기
						$("#MM_main_focus").css({ "display": "none" });
						$("#MM_sub_focus").css({ "display": "none" });
						ChangeScene.start(g_sceneinfo.cur_scene, gS_USERGUIDE, S_USERGUIDE);
					}
					break;
				case KeyDefine.BLUE:
					if (gTARGET_PLATFORM == gPLATFORM.KT) // 부싯돌월드
					{

						var URL = "http://appsbusidol.cafe24.com/kt/get_location_url.php";
						var sendData = {};
						$.ajax({
							url: URL,
							type: 'POST',
							data: sendData,
							timeout: 5000, /* Timeout in ms */
							success: function (oData) {
								// util.log(" success:  check_ip_blocking_in_server return_code:"+oData);
								window.location = oData;
							},
							error: function (xhr) {
								ChangeScene.start(g_sceneinfo.cur_scene, gS_ERROR_NETWORK, S_ERROR_NETWORK);
							}
						});
					}
					break;
				//~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!
				//이벤트 때문에 블루 버튼을 추가합니다
				case 77:// m 버튼
					if (gAPP_RELEASE != "TEST") return; // test일때는 m키가  blue key로 동작
				case KeyDefine.PLAY:
				case 179:
					S_MAINMENU.end(); //마우스 및 타이머 죽이기
					$("#MM_main_focus").css({ "display": "none" });
					$("#MM_sub_focus").css({ "display": "none" });

					// 20220104_dblee 패키지 상점 구현 (202201041752) - 기간한정 상품 단축키 오류
					var event_loop2 = function (json_data) {
						//진행중인 이벤트 모두 변수에 등록
						for (var i = 0; i < json_data.event_arr.length; i++) {
							AUTO_EVENT_FLAG[json_data.event_arr[i]] = 1;
						}

						//20210719_yhlee 자동화 이벤트 여부에 따라 변화되어야 하는 값에 대한 부분을 정의하는 함수를 따로 호출
						auto_event_value();

						util_fun.loadingSpinner.hide();
						gEnableKey = 1;

						bga('send', 'event', 'mainmenu', 'market(상점)', 'ok');
						utilPush();//history back을 위해 현재 화면을 저장해 둔다.
						S_MAINMENU.end();
						if (gTARGET_PLATFORM == gPLATFORM.TIZEN_TV || gTARGET_PLATFORM == gPLATFORM.KT) {
							if (glo.APP_FEATURE.PACKAGE_STORE) {
								ChangeScene.start(g_sceneinfo.cur_scene, gS_PACKAGE_STORE, S_PACKAGE_STORE);
							}
							else {
								ChangeScene.start(g_sceneinfo.cur_scene, gS_MARKETSTORE, S_MARKETSTORE);
							}
						}
						else {
							// 20220104_dblee 패키지 상점 구현 (202201041752)
							$('#S_MAINMENU_div').css({ 'display': "none" });
							if (glo.APP_FEATURE.PACKAGE_STORE) {
								$('#S_PACKAGE_STORE_div').css({ 'display': "block" });
								S_PACKAGE_STORE.init();
							}
							else {
								$('#S_MARKETSTORE_div').css({ 'display': "block" });
								S_MARKETSTORE.init();
							}
						}
					}
					util_fun.loadingSpinner.show();
					gEnableKey = 0;
					auto_event_system_init();//이벤트 진행 여부 배열 초기화
					auto_event_system_check(999, event_loop2);//999 - 전체 이벤트 정보를 모두 리턴합니다.
					break;
				//~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!

				//20210118_yhlee 멀티 계정 추가로 메인화면에서도 계정 변경 할수 있도록 추가
				case KeyDefine.NUM0:
					//계정 정보를 받아오고 , 받아온 계정정보에 대해 재화 정보를 다시 받아오고 파싱 후 화면을 넘기자.
					ServerConnection.get_select_id(function () {
						//서브 id들의 현재 정보를 가져옵니다.
						if (S_ACCOUNT_CHANGE.account_id[2] != '-') {
							//부계정들의 재화 정보를 가져옵니다.
							ServerConnection.get_account_data(function () {
								utilPush();
								$('#S_ACCOUNT_CHANGE_div').css({ 'display': "block" }); //순서를 한번 바꾸어 봤다. 깜빡임이 더 적지 않을까?
								S_ACCOUNT_CHANGE.preload();
								util_fun.loadingSpinner.hide();
								gEnableKey = 1;
							});
						}
						else {
							utilPush();
							$('#S_ACCOUNT_CHANGE_div').css({ 'display': "block" }); //순서를 한번 바꾸어 봤다. 깜빡임이 더 적지 않을까?
							S_ACCOUNT_CHANGE.preload();
							util_fun.loadingSpinner.hide();
							gEnableKey = 1;
						}
					});
					util_fun.loadingSpinner.show();
					gEnableKey = 0;
					break;
				case KeyDefine.LEVELUP:
					//case KeyDefine.NUM7: //테스트를 위해 스테이지 70까지 클리어 시켜 주기
					if (gAPP_RELEASE == "TEST") {
						if (USER.level <= 90) {
							USER.level = USER.level + 8;
							utilNotice("Test를 위해 사용자 Level을 +10으로 올렸습니다. 수고혀~~", 1.2);
							STORAGE.save_all_info_to_storage("테스트:사용자레벨업:+18"); //모든 정보를 sotrage에 저장한다.
							S_MAINMENU.make_screen_top();
						}
					}
					break;
				case KeyDefine.OPENSTAGE:
					//case KeyDefine.NUM8: //테스트를 위해 스테이지 99까지 클리어 시켜 주기
					if (gAPP_RELEASE == "TEST") {
						var open = MAX_STAGE_NUM - 1;

						for (var i = 1; i <= open; i++) {
							STORAGE.data3[i] = "A";
						}

						STORAGE.data3[open + 1] = "T";
						for (var i = open + 2; i <= MAX_STAGE_NUM; i++) {
							STORAGE.data3[i] = "X";
						}
						STORAGE.save_all_info_to_storage("테스트:스테이지Open:" + open); //모든 정보를 sotrage에 저장한다.
						utilNotice("Test를 위해 " + open + "stage까지 열어 두었습니다. Good Game!~", 1.2);
						S_MEDALPOWER.cal_power();
					}
					break;
				case KeyDefine.SHOWMETHEMONEY:
					if (gAPP_RELEASE == "TEST") {
						//USER.gold = USER.gold + 100000;
						S_MAINMENU.make_screen_top_add_gold(100000);

						ServerConnection.add_bonus_point(100, "치트키 ");
						USER.bonus_point = USER.bonus_point + 100;

						//USER.ruby = USER.ruby + 100;
						S_MAINMENU.make_screen_top_add_ruby(100);
						utilNotice("골드 10000, 크리스탈 100개를 추가 하였습니다. 즐~게임", 1.5);
						STORAGE.save_all_info_to_storage("테스트:ShowMeTheMoney"); //모든 정보를 sotrage에 저장한다.
						save_UserInfo_after_pay_to_server(100, "치트키");
						S_MAINMENU.make_screen_top();
					}
					break;
				case KeyDefine.GAMEINIT:
					if (gAPP_RELEASE == "TEST") {
						utilNotice("초기화 합니다. LocalStorage정보도 초기화 합니다.", 1.5);

						if (gTARGET_PLATFORM == gPLATFORM.ENTRIX_CNM
							|| gTARGET_PLATFORM == gPLATFORM.KT
						) {
							delete_user_in_server();
						}
						else {
							localStorage.clear(); //
							STORAGE.init_firstUser(); //최초 사용자일경우의 변수 값 설정 STORAGE.data1,data2,data3
							STORAGE.save_all_info_to_storage("테스트:초기화"); //모든 정보를 sotrage에 저장한다.
							get_id_from_server(); //서버로 부터 ID를 생성 받아라.
							getCountry_usingIP(); //나의 IP를 기준으로 나라 코드값을 받아라
							STORAGE.load_n_parse(); //저장한후 다시 환경 변수들을 불러 온다.
						}
						clearInterval(S_MAINMENU.interval);
						S_MAINMENU.interval = null;

						S_MAINMENU.init();
					}
					break;

				case KeyDefine.UPGRADE: // "u" 버턴
					if (gAPP_RELEASE == "TEST") {
						STORAGE.data1.upgrade[1] = 160;
						STORAGE.data1.upgrade[2] = 160;
						STORAGE.data1.upgrade[3] = 160;
						STORAGE.data1.upgrade[4] = 160;
						STORAGE.data1.upgrade[5] = 160;
						if (gTARGET_PLATFORM == gPLATFORM.KT)
							STORAGE.data1.upgrade[6] = 12;
						else
							STORAGE.data1.upgrade[6] = 20;
						STORAGE.data1.upgrade[7] = 160; //메테오 파워
						STORAGE.data1.upgrade[8] = 70; //아군저장소 업
						MAX_OUR_TEAM_NUM_ON_SCREEN = STORAGE.data1.upgrade[6]; //이부장님 지적
						STORAGE.save_all_info_to_storage("테스트:업그레이드"); //모든 정보를 sotrage에 저장한다.
						utilNotice("UPGRADE메뉴 모두 160으로~~ good game~~^^", 1.5);
					}
					break;
				case KeyDefine.NUM2:
				case KeyDefine.DEBUG: //테스트를 위해 debug창을 on/off한다.
					if (gAPP_RELEASE == "TEST") {

						gEntrix.is_model = false;
						ChangeScene.start(g_sceneinfo.cur_scene, gS_ERROR_NETWORK, S_ERROR_NETWORK);
					}
					break;
				case KeyDefine.NUM1: //테스트를 위해 숫자 1은 ID 고정(IceHunter_862)
					// 20220727_dblee_시원한 여름날의 출석부 이벤트 - 이벤트 출석부 진입시 마다 데이터를 읽어 온다.
					// 데이터를 읽어 오면서 기간 종료 등 알려준다.
					if (glo.APP_FEATURE.ATTENDANCE_EVENT) {
						if (!$('#AE_main_icon').html()) return; // 아이콘이 없으면 동작하지 말라.
						loading_show();
						ServerConnection.attendance_event({ MODE: "SHOW" }, function (json_data) {
							loading_hide();

							if (json_data.TYPE == "EVENT_END") {
								if (USER.lang == LANG.KOREA)
									utilNotice(json_data.DESCRIPTION, 2);
								else
									utilNotice(json_data.DESCRIPTION_EN, 2);
							}
							else {
								S_MAINMENU.end();
								// 이벤트 종료 기간이면 화면을 보여준다.
								if (gTARGET_PLATFORM == gPLATFORM.TIZEN_TV || gTARGET_PLATFORM == gPLATFORM.LGWEBOS_TV || gTARGET_PLATFORM == gPLATFORM.KT) {
									ChangeScene.start(g_sceneinfo.cur_scene, gS_ATTENDANCE_EVENT, S_ATTENDANCE_EVENT);
								}
								else {
									utilPush();//history back을 위해 현재 화면을 저장해 둔다.
									$('#S_MAINMENU_div').css({ 'display': "none" });
									S_ATTENDANCE_EVENT.init();
								}
							}
						});
					}
					break;
				case KeyDefine.NUM3:
					if (gAPP_RELEASE == "TEST") {
						//첫구매이벤트 시작
						S_MAINMENU.end();
						$("#MM_main_focus").css({ "display": "none" });
						$("#MM_sub_focus").css({ "display": "none" });

						$('#S_EVENT_div').css({ 'display': "block" });
						S_EVENT.status = 2; // 첫 구매이벤트이다.
						S_EVENT.init();
					}
					break;
				case KeyDefine.NUM4: //테스트를 위해 100 level 클리어한 사용자 정보 가지고 오기.
					if (gAPP_RELEASE == "TEST") {
						utilNotice("우편함 테스트를 위해 우편함에 보상을 지급 합니다.", 3.0);

						ServerConnection.put_reward_char('GOLD', 'TEST GOLD 보상', 10);
						ServerConnection.put_reward_char('BP', 'TEST BP 보상', 5);
						ServerConnection.put_reward_char('RUBY', 'TEST RUBY 보상', 10);
						for (var i = 1; i <= 3; i++) {
							var rnd = Math.floor(Math.random() * 68 + 1); //1 ~ 100;
							utilConsoleLog("~~ 우편함에 캐릭터 보상 등록 ~~ " + rnd);
							ServerConnection.put_reward_char('CHAR', 'TEST CHAR 보상', rnd);
						}
					}
					break;

				case KeyDefine.NUM5: //테스트를 위해 100 level 클리어한 사용자 정보 가지고 오기.
					if (gAPP_RELEASE == "TEST") {
						utilNotice("119 Stage 클리어한 히어로에코님의 정보로 setting 합니다.", 3.0);
						var data1 = "23721596980,4946242,2571,1,KR,1,2,1,100,0,12449420,20180219,174,1519004730000,1:2:3:4:5,40:31:61:51:3,20171219_1:20180108_1:20180113_1:20180112_1:20180201_1,0";
						var data2 = "30:70:70:0,19:70:70:0,14:70:70:0,36:70:70:0,24:70:70:0,35:65:65:0,29:65:65:0,13:60:60:0,8:75:75:0,18:70:70:0,23:70:70:0,22:55:55:0,7:55:55:0,34:65:65:0,17:50:50:0,33:40:40:0,16:45:45:0,21:40:40:0,11:40:40:0,27:40:40:0,39:55:55:0,15:35:35:0,5:35:35:0,20:35:35:0,38:40:40:0,10:45:45:0,2:20:20:0,0:20:20:0,0:20:20:0,0:20:20:0";
						var data3 = "A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,D,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,T";
						update_user_to_server_test(data1, data2, data3);
						setTimeout(function () {
							history.go(0);
						}, 2000);
					}
					break;
				case KeyDefine.NUM6: //테스트를 위해 100 level 클리어한 사용자 정보 가지고 오기.
					if (gAPP_RELEASE == "TEST") {
						utilNotice("월드보스 1등, PVP 1~3등 유저 정보로 setting 합니다.", 3.0);
						var data1 = "17427616370,134428119,2558,1,KR,1,2,2,140,0,2575882,20190909,660,1567971743018,1:2:0:0:0,140:140:140:140:140:20:30:100,20190726_2:20190726_3:20190809_1:20190823_1:20190901_1,10";
						var data2 = "68:100:100:0:1,48:100:100:0:1,64:100:100:0:1,64:100:100:0:1,68:95:100:4200:1,67:80:95:3125:1,65:100:100:0:1,66:88:100:250:1,68:1:80:0:0,56:95:95:0:1,63:95:95:0:1,48:100:100:0:1,56:100:100:0:1,49:95:95:0:1,67:100:100:0:1,66:100:100:0:1,65:100:100:0:1,63:100:100:0:1,50:100:100:0:1,62:95:95:0:1,9:65:85:800:0,36:53:80:500:0,19:53:80:500:0,55:37:75:900:0,47:1:70:0:0,30:1:70:0:0,42:1:70:0:0,14:1:70:0:0,35:44:70:550:0,46:62:80:2400:0,23:31:65:250:0,54:1:60:0:0,13:44:70:550:0,41:31:65:250:0,60:54:75:800:0,18:54:75:800:0,29:31:65:250:0,41:1:60:0:0,41:1:60:0:0,8:1:60:0:0,8:1:60:0:0,46:1:60:0:0,46:1:60:0:0,17:50:70:300:0,28:50:70:300:0,59:50:70:300:0,34:50:70:300:0,45:50:70:300:0,53:50:70:300:0,12:43:65:750:0,22:50:70:300:0,28:50:70:300:0,40:50:70:300:0,34:50:70:300:0,7:50:70:300:0,7:50:70:300:0,59:50:70:300:0,7:24:55:1050:0,34:50:70:300:0,17:35:60:550:0,53:35:60:550:0,28:43:65:750:0,34:1:50:0:0,34:1:50:0:0,59:1:50:0:0,59:1:50:0:0,59:1:50:0:0,59:1:50:0:0,28:1:50:0:0,53:1:50:0:0,53:1:50:0:0,40:1:50:0:0,27:37:60:900:0,33:37:60:900:0,39:37:60:900:0,58:32:55:650:0,11:37:60:900:0,6:37:60:900:0,16:56:60:1950:0,33:37:60:900:0,33:32:55:650:0,52:37:60:900:0,27:26:50:500:0,21:37:60:900:0,39:37:60:900:0,16:18:45:500:0,11:32:55:650:0,6:18:45:500:0,44:32:55:650:0,52:32:55:650:0,21:1:40:0:0,58:1:40:0:0,26:21:45:500:0,57:40:40:0:0,10:1:30:0:0,5:1:30:0:0,15:1:30:0:0,4:6:25:0:0,1:1:20:0:0,37:1:20:0:0";
						var data3 = "A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A";
						update_user_to_server_test(data1, data2, data3);
						setTimeout(function () {
							history.go(0);
						}, 2000);
					}
					break;
				case KeyDefine.NUM8:
					if (gAPP_RELEASE == "TEST") {
						utilNotice("200클리어,아이템 C, 보유 유저 유저 정보로 setting 합니다.", 3.0);
						CUR_HARD_STAGE_NUM = 201;//현재 도전중이 하드모드 스테이지 번호
						HARD_MODE_JEWEL = "1,1,1,1,1,1,1,1,1,1";//하드모드에서 획득한 보석 정보
						ServerConnection.update_HardMode_to_server("[치트키] : " + (CUR_HARD_STAGE_NUM - 1) + " Stage 클리어 사용자로 셋팅");
						var data1 = gEntrix.host_id + ",140889720,1498,1,KR,1,2,1,10,0,2575882,20210224,664,1567971743018,1:2:3:4:5,140:140:128:140:140:20:140:100:100,20190726_3:20190809_1:20190823_1:20190901_1:20210216_1,10";
						// var data2 = '48:100:100:0,47:80:80:0,42:90:90:0,49:100:100:0,50:100:100:0,24:90:90:0,51:1:30:1,52:1:40:2,53:26:50:373,54:29:60:901,55:34:70:173,56:1:80:0,14:90:90:0,36:90:90:0,36:90:90:0,30:90:90:0,35:80:80:0,41:80:80:0,18:75:75:0,23:70:70:0,35:70:70:0,46:65:65:0,8:80:80:0,13:75:75:0,29:80:80:0,8:60:60:0,45:65:65:0,7:60:60:0,28:65:65:0,22:50:50:0,17:1:50:0,21:32:55:650,44:51:55:1700,33:32:55:650,39:48:50:200,16:44:45:500,27:37:60:900';
						// var data2 = '68:100:100:0:1,48:100:100:0:1,64:100:100:0:1,64:100:100:0:1,68:95:100:4200:1,67:100:100:0:1,65:100:100:0:1,66:100:100:0:1,68:1:80:0:0,56:100:100:0:1,63:100:100:0:1,48:100:100:0:169:20:20:0,70:30:30:0,71:40:40:0,72:50:50:0,73:60:60:0,74:90:90:0,75:100:100:0,74:70:70:0,75:80:80:0,74:70:70:0,75:80:80:0,74:70:70:0,75:80:80:0,74:70:70:0,75:80:80:0';
						var data2 = '66:100:100:0:1,48:100:100:0:1,63:100:100:0:1,67:100:100:0:1,65:100:100:0:1,50:100:100:0:1,56:100:100:0:1,62:100:100:0:1,64:100:100:0:1,67:100:100:0:1,68:100:100:0:1,75:100:100:0:1,63:80:80:0:1,56:80:80:0:1,56:80:80:0:1,56:100:100:0:1,56:80:80:0:1,67:80:80:0:1,64:80:80:0:1,64:100:100:0:1,68:100:100:0:1,68:80:80:0:1,65:80:80:0:1,50:85:85:0:1,49:100:100:0:1,62:100:100:0:1,74:75:75:0:1,36:80:80:0:1,55:75:75:0:1,24:75:75:0:1,19:80:80:0:1,9:70:70:0:1,42:70:70:0:1,30:80:80:0:1,41:75:75:0:0,35:80:80:0:0,23:80:80:0:0,46:75:75:0:0,46:80:80:0:0,73:60:60:0:0,73:80:80:0:0,18:70:70:0:0,13:60:60:0:0,60:60:60:0:0,8:75:75:0:0,54:70:70:0:0,29:75:75:0:0,72:65:65:0:0,53:55:55:0:0,59:55:55:0:0,45:60:60:0:0,40:50:50:0:0,40:1:50:0:0,34:55:55:0:0,34:1:50:0:0,22:65:65:0:0,22:1:50:0:0,12:60:60:0:0,17:65:65:0:0,7:70:70:0:0,7:1:50:0:0,7:1:50:0:0,28:65:65:0:0,28:1:50:0:0,28:1:50:0:0,44:40:40:0:0,39:60:60:0:0,21:60:60:0:0,21:40:40:0:0,58:40:40:0:0,27:60:60:0:0,71:60:60:0:0,71:40:40:0:0,16:45:45:0:0,52:50:50:0:0,33:40:40:0:0,6:50:50:0:0,11:55:55:0:0,15:35:35:0:0,43:35:35:0:0,20:35:35:0:0,5:30:30:0:0,10:40:40:0:0,51:35:35:0:0,38:50:50:0:0,38:30:30:0:0,32:45:45:0:0,26:41:45:1950:0,37:25:25:0:0';
						var data3 = "A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A,A";
						update_user_to_server_test(data1, data2, data3);


						var item_data = "251:0:HP-25649:0:0,141:2:AD-128:0:0,142:4:AD-117:0:1,142:1:HP-6500:0:1,142:5:AS-7:0:1,141:0:PS-18:0:0,142:0:AD-116:0:1,142:3:AD-134:0:1,242:2:AS-7:0:1,241:3:AD-124:0:1,242:5:AS-7:0:1,242:4:AS-7:0:1,241:1:PS-20:0:0,341:5:SP-18:0:1,341:4:HP-5556:0:0,342:3:AD-131:0:1,341:0:AP-732:0:1,343:1:AP-1126:0:1,341:2:SP-20:0:1,443:3:AD-131:0:1,443:5:MR-80:0:1,443:2:AD-124:0:1,443:4:MR-77:0:1,441:0:MR-66:0:0,443:1:SP-19:0:1,441:0:AD-131:0:1,233:0:SP-15:0:0,331:0:AD-99:0:0,332:0:AD-85:0:0,331:0:SP-15:0:0,433:0:AD-100:0:0,432:0:HP-1079:0:0,121:0:MR-38:0:0,123:0:PS-8:0:0,121:0:PS-10:0:0,221:0:AP-54:0:0,221:0:AP-82:0:0,222:0:AP-67:0:0,222:0:PS-7:0:0,223:0:PS-8:0:0,222:0:MR-28:0:0,323:0:HP-472:0:0,321:0:MR-22:0:0,421:0:AP-82:0:0,422:0:MR-34:0:0,421:0:HP-551:0:0,111:0:AD-27:0:0,311:0:SP-3:0:0,312:0:HP-188:0:0,412:0:AS-4:0:0";
						var tmp_data_item = item_data.split('||');
						//-------------------------------------------------------------
						//아이템 리스트들은 대입합니다.
						var tmp_data = tmp_data_item[0].split(',');
						for (var i = 0; i < tmp_data.length; i++) {
							//넘어오는 값 111:1:ML-200:12:0,132:1:HP-500:15:0,421:1:SP-10:5:0,221:1:CP-200:0:0,101:0:ML-150:2:1
							// tmp_item[0] = 아이템 번호
							// tmp_item[1] = 장착 인덱스 < 여기서 인덱스는 소켓의 인덱스와 동일
							// tmp_item[2] = 보조옵션이름 - 보조옵션수치
							// tmp_item[3] = 보조옵션 재설정 횟수
							// tmp_item[4] = 잠금여부   1 잠금 0 잠기지않음
							var tmp_item = tmp_data[i].split(':');
							var tmp_item_option = tmp_item[2].split('-');

							STORAGE.item[i + 1].item_num = Number(tmp_item[0]);
							STORAGE.item[i + 1].socket_index = Number(tmp_item[1]);
							STORAGE.item[i + 1].add_option = tmp_item_option[0];
							STORAGE.item[i + 1].add_option_num = Number(tmp_item_option[1]);
							STORAGE.item[i + 1].add_option_reset_num = Number(tmp_item[3]);
							STORAGE.item[i + 1].lock = Number(tmp_item[4]);
						}
						//아이템 목록에서 보여주기 위해 view 배열에 대입합니다.
						S_ITEM.view_item_all();
						//------------------------------------------------------------
						ServerConnection.update_item_to_server("[치트키] : " + (CUR_HARD_STAGE_NUM - 1) + " Stage 클리어 사용자로 셋팅");

						setTimeout(function () {
							history.go(0);
						}, 2000);
					}
					break;
			}
		}

	}

};





/****************************************************************************************************************************************/

/****************************************************************************************************************************************/
//////////////////////////////////////////
/////////// 서버 점검중 //////////////////
//////////////////////////////////////////
//값이 1이면 서버 비상 점검 중이다.
//서버 점검 완료후 값을 꼭 0으로 되돌려 놓을 것!!
///////////////////////////////////////////////////////////////////////////////////////
var SERVER_TESTING = 0; // 반드시 0 이어야 서비스가 됨, 1 이면 서비스 안됨!!! 주의!!!

var str_SERVER_TEST =
	[
		"", //0번지는 역시 버린다.
		"[[ 엘도라도 서버 긴급 점검 ]]",
		"",
		"더 나은 서비스를 위해 긴급 서버 점검 중 입니다.",
		"",
		"예상시간 : 9월 13일 18:00 ~ 9월 14일 15:00",
		"",
		"감사합니다."
	];
