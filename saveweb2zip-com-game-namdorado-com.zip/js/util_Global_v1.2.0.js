/*************************************************
 * Global 변수 선언
 *
 * @history 2016.05.16 IP_BLOCKING_URL 추가함.
 *           	2016.06.16	1606171040 - stage clear시 사용자 레벨 경험치 수치 조정함.
 *           					첫 clear이면 100%, 반복이면 50%
 *
 *************************************************/

/* Scene 추가 */
//var gS_LOADING = "S_LOADING";
var gS_TOPLEVEL = "S_TOPLEVEL";
var gS_LOGIN = "S_LOGIN";
var gS_CLOUD_RANKING = "S_CLOUD_RANKING";
var gS_RECONNECT = "S_RECONNECT";
var gS_LOGO = "S_LOGO";
var gS_SYNOPSIS = "S_SYNOPSIS";
var gS_GONGJI = "S_GONGJI";
var gS_ATTENDANCE = "S_ATTENDANCE";
var gS_PAYGUIDE = "S_PAYGUIDE";

var gS_MAINMENU = "S_MAINMENU";
var gS_EVENT = "S_EVENT";
var gS_USERGUIDE = "S_USERGUIDE";
var gS_SELECTMAP = "S_SELECTMAP";
var gS_SELECTSTAGE = "S_SELECTSTAGE";
var gS_USERPAID = "S_USERPAID";//특정 스테이지이상 유료 결제 유도 //20160923_ywlee userpaid
//20190104_yhlee 자동 플레이 추가
var gS_AUTOPLAY_PAID = "S_AUTOPLAY_PAID";

var gS_RANKING = "S_RANKING";
var gS_RANKING_PVP = "S_RANKING_PVP";
var gS_RANKING_NVN = "S_RANKING_NVN";//20170602_yhlee 국가 결투장 추가합니다.
var gS_POPUP_REWARD_VIEW = "S_POPUP_REWARD_VIEW";//20170522_yhlee 개인별/국가별 보상 보기 팝업
var gS_MEDALPOWER = "S_MEDALPOWER";
var gS_MAKETEAM = "S_MAKETEAM";
var gS_CLEVELUP = "S_CLEVELUP";
var gS_CLEVELUP_COMPLETE = "S_CLEVELUP_COMPLETE";
var gS_TRAINING_COMPLETE = "S_TRAINING_COMPLETE";
var gS_EVOLUTION_COMPLETE = "S_EVOLUTION_COMPLETE";
var gS_UPGRADE = "S_UPGRADE";
var gS_UPGRADE_COMPLETE = "S_UPGRADE_COMPLETE";
var gS_GACHA = "S_GACHA";
var gS_GACHA_COMPLETE = "S_GACHA_COMPLETE";
var gS_GACHARESULT = "S_GACHARESULT";
var gS_MARKETSTORE = "S_MARKETSTORE";
var gS_MARKETSTORE_PAYMENT = "S_MARKETSTORE_PAYMENT";
var gS_MARKETSTORE_PAYMENT_PRELOAD = "S_MARKETSTORE_PAYMENT_PRELOAD";
var gS_GAME = "S_GAME";
//var gS_POPUPQUIT			= "S_POPUPQUIT";
var gS_POPUPYN = "S_POPUPYN";
//20170510_yhlee 국기설정 부분을 추가합니다.
var gS_POPUP_COUNTRY_SETTING = "S_POPUP_COUNTRY_SETTING";

var gS_EXITPOPUP = "S_EXITPOPUP";
var gS_STAGECLEAR = "S_STAGECLEAR";
var gS_STAGEFAIL = "S_STAGEFAIL";
var gS_QUEST = "S_QUEST";
var gS_QUESTDETAIL = "S_QUESTDETAIL";
var gS_SETTING = "S_SETTING";
var gS_INPUT_NICKNAME = "S_INPUT_NICKNAME";
//20181220_yhlee 엑솔라 결제를 추가합니다
var gS_INPUT_PAY = "S_INPUT_PAY";
var gS_EVENTPAGE = "S_EVENTPAGE";

//20170704_yhlee  도감 추가로 인하여 추가합니다.
var gS_CHARBOOK_ALLY = "S_CHARBOOK_ALLY";
var gS_CHARBOOK_ALLY_POPUP = "S_CHARBOOK_ALLY_POPUP";
var gS_CHARBOOK_ENEMY = "S_CHARBOOK_ENEMY";

//20190308_yhlee 월드 보스 추가
var gS_BOSS = "S_BOSS";
var gS_RANKING_BOSS = "S_RANKING_BOSS";
var gS_BOSSFAIL = "S_BOSSFAIL";
var gS_BOSSCLEAR = "S_BOSSCLEAR";

var gS_PAYMENT_CNM = "S_PAYMENT_CNM";
var gS_ERROR_NETWORK = "S_ERROR_NETWORK";
// BUSIDOL_PATMENT  사용하는 화면
var gS_BUSIDOL_PATMENT_SELECT = "S_BUSIDOL_PATMENT_SELECT";
var gS_TV_CODE = "S_TV_CODE";
var gS_B_P_ERROR = "S_B_P_ERROR";
var gS_B_P_BACK = "S_B_P_BACK";
var gS_B_P_COMPLETED = "S_B_P_COMPLETED";
// 결제내역리스트  for KT
var gS_BILLING_HISTORY = "S_BILLING_HISTORY";

//20190510_yhlee 아이디 선택 추가
var gS_ID_CHOICE = "S_ID_CHOICE";

//20190709_yhlee 우편함 추가
var gS_MAILBOX = "S_MAILBOX";

//20191001_yhlee 아이템 추가
var gS_ITEM = "S_ITEM";
var gS_ITEM_UPGRADE = "S_ITEM_UPGRADE";
var gS_ITEM_UPGRADE_COMPLETE = "S_ITEM_UPGRADE_COMPLETE";
var gS_ITEM_GACHA = "S_ITEM_GACHA";
var gS_ITEM_GACHA_COMPLETE = "S_ITEM_GACHA_COMPLETE";

//20191119_yhlee 하드모드 추가
var gS_SELECTMAP_HARD = "S_SELECTMAP_HARD";
var gS_SELECTSTAGE_HARD = "S_SELECTSTAGE_HARD";
var gS_HARDMODE_JEWEL = "S_HARDMODE_JEWEL";

//20200526_yhlee 패키키 상품 추가
var gS_PACKAGE_ITEM = "S_PACKAGE_ITEM";

//20201110_yhlee 요일던전추가
var gS_DAYDUNGEON_SELECT = "S_DAYDUNGEON_SELECT";
var gS_DAYDUNGEON = "S_DAYDUNGEON";
var gS_DAYDUNGEON_CLEAR = "S_DAYDUNGEON_CLEAR";
var gS_DAYDUNGEON_FAIL = "S_DAYDUNGEON_FAIL";

//20210118_yhlee 멀티 계정 추가
var gS_ACCOUNT_CHANGE = "S_ACCOUNT_CHANGE";

//20210503_yhlee 모바일 연동 추가
var gS_MOBILE_LINK = "S_MOBILE_LINK";
var gS_POPUP_LOGIN_FROM_MOBILE = "S_POPUP_LOGIN_FROM_MOBILE";

// 20210712_dblee 확률 공개
var gS_PERCENTAGE_SHOW = "S_PERCENTAGE_SHOW";

// 20220104_dblee 패키지 상점 구현 (202201041752)
var gS_PACKAGE_STORE = "S_PACKAGE_STORE";
var gS_POPUP_PACKAGE_STORE = "S_POPUP_PACKAGE_STORE";


// 20220727_dblee_시원한 여름날의 출석부 이벤트
var gS_ATTENDANCE_EVENT = "S_ATTENDANCE_EVENT";


/*
 * Target Platform define
 */
var gPLATFORM =
{
	NORMAL: 0, //PC, USB version임.
	GAMING_TV: 1,
	LGWEBOS_TV: 2,
	TIZEN_TV: 3, //삼성전자
	ENTRIX_CNM: 4, //엔트릭스 CNM향
	ENTRIX_CJH: 5, //엔트릭스 CJH향
	KT: 6 // KT PLATFORM 추가함.  3.25.2016

}


var LANG =
{
	KOREA: 1,
	ENGLISH: 2,
	VIETNAM: 3,
	SPAIN: 4,
	RUSSIA: 5
};


LANG.codes =
{
	KOREA: 'kr',
	ENGLISH: 'en',
	VIETNAM: 'vn',
	SPAIN: 'sp',
	RUSSIA: 'ru'
};

var TXT = {}

TXT.get_lang_code = function () {
	for (const [key, value] of Object.entries(LANG.codes)) {
		if (key == USER.lang) {
			return value;
		}
	}
	return 'eng';
}

///////////////////////////////////////
// 버전 발행시 꼭 체크 해야 하는 사항//
///////////////////////////////////////

////// 1 플랫폼설정 ///////////////////////////////////////
var gTARGET_PLATFORM = ""; // "" 이면 자동으로 찾아준다. "" 아니면 지정된 PLATFORM으로 설정된다. // KT PLATFORM 추가함.  3.25.2016
// gTARGET_PLATFORM = gPLATFORM.LGWEBOS_TV;
// gTARGET_PLATFORM = gPLATFORM.TIZEN_TV;
// gTARGET_PLATFORM = gPLATFORM.NORMAL;
gTARGET_PLATFORM = gPLATFORM.KT;  // 강제 지정 방법. // KT PLATFORM 추가함.  3.25.2016



////// 2. log 지우기 //////////////////////////////////////
// var gAPP_RELEASE = "TEST";	//로그를 보이게 한다. utilConsoleLog()에서 조정
var gAPP_RELEASE = "RELEASE";	//모든 로그를 보이지 않게 한다.
var gAppEnableLog = false;

////// 3. 앱명 설정 ////////////////////////////////////////
var gAPP_INFO =
{
	APP_NAME: "ELDORADO_KT",
	JS_MIN_VER: "not used",	// eldorado-kt-v1.1.0.min
	VERSION: "V1.2.0",

	// notOpenVersion : "20210506_mobile_link" //엘도라도M 연동
	// notOpenVersion : "20210629_cow_char_add" // 소캐릭터추가
	// notOpenVersion : "20210810_enemy_ap_hp_low" // 적군 캐릭터 AP,HP 90%하양 조정
	// notOpenVersion : "20210823_event_auto" // 이벤트 자동화 소스 적용
	// notOpenVersion : "20210929_mobile_connection_guide" // 이벤트 자동화 소스 적용
	// notOpenVersion : "20211130_boss_day_change" // 월드보스 생성일 금요일 > 일요일로 변경
	// notOpenVersion : "20220322_package" // 패키지 상품 적용
	// notOpenVersion : "20220427_package" // 재구매 컨셉 변경
	// notOpenVersion : "20220512_zoom_in" // 확대 기본
	// notOpenVersion : "20220706_206stage" // 260스테이지 추가
	// notOpenVersion : "20220725_error" // 오류 수정
	// notOpenVersion : "20220817_event_att" // 이벤트 출석부
	notOpenVersion: "20230306_gacha" // 엘도라도 뽑기 개선안 적용
}


/**
 * 화면에 log 표시 하도록 한다.
 */
var gApp_LOGO = false;

//-----------------------------꼭! 이 라인까지체크하고 버전 발행 할 것!! ----------------------------------------------

/**
 * 1606201126
 * 아군 생산량 증가
 * 적군 생산량 증가.
 */
var MAX_OUR_TEAM_UNIT = 10; // 10
var MAX_YOUR_TEAM_UNIT = 6; // 6

var MAX_USER_GET_CHAR = 30; //사용자가 보유할 수 있는 나의 캐릭 수

/**
 * 1606171040
 * Tizen에서 define.js에 변수를 추가하면 추가한 변수가 인식이 안되네..
 * 그래서 Global 에 추가함.
 * stage clear시 사용자 레벨 경험치 수치 조정 변수인데, 반복 clear시
 * 원래 경험치에서 얼마만큼 줄래이다.
 * 0 ~ 1 사이 값.
 * 결정된 값은 0.5이지만, 비활성화 시 1. 활성화 되면 0.5로 수정.
 */
var gUEF_RSC = 0.2;  // User Experience Factor   Repeat Stage Clear 의 약어


/**
 * 마우스 기능 On/Off 변수.
 * gMOUSE_TYPE
 * 	0 : 강제 지정 값
 * 	1 : gAPP_RELEASE TEST 이고 getDevice 값이 PC이면 true, 그렇지 않으면 false이다.
 * @date : 3.25.2016
 */
var gMOUSE_TYPE = 0;
var gMOUSE_USE = true;


/**
 * Busidol Pay 적용여부 결정하는 함수
 */
var gBUSIDOL_PAY_USE = false;
var gTV_Code = 0;
var gRuby_Plus = 0;
// 1606131853
var gENABLE_IMAGE_LOAD_SERVER = false;   //
var gB_PAY_COUNTRY = [];	//  ED_VIET define.js 위치. 배열 값이 없으면 All country.  있으면 해당 국가만 적용.
var gIMAGE_LOAD_URL = "./";
var gLOCAL_SET = "";


var SERVER_URL = "http://eldoradokt.cafe24.com/ELDORADO_KT/";					//main이 되는 서버위치 임.
var SERVER_URL_N = "https://game.namdorado.com/";
//var SERVER_URL_N = "http://192.168.1.10:8000/";					//main이 되는 서버위치 임.
var REMAIN_COUNTER_URL = SERVER_URL_N + "Counter/day_counter";	//고전 누적 체크
//var WEBSOCKET_URL = "ws://192.168.1.10:7979";
var WEBSOCKET_URL = "wss://socket.namdorado.com:7979";
var WEBSOCKET_CHAT_URL = "wss://socket.namdorado.com:7878";

var NETWORK_TIME_OUT = 30000; // 20170307.dblee
var PING_TIME_OUT = 15000; // KT 표준 네트워크 응답 시간 5초 20170307.dblee

var g_sceneinfo =
{
	cur_scene: gS_MAINMENU, //현재 나의 scen의 값을 가지고 있다.
	before_scene: gS_MAINMENU
};


/* User 정보 - 게임 진행시에 필요한 사용자 정보*/
/*
var gUSER =
{
	//level: 1,
	//score: 0,
	lang: LANG.KOREA  //기본언어 설정
};
*/

var gVALIDATE = 1; // { 1,0 }유효성 확인 변수, 0--> 게임 진행 안됨, 1 --> 게임 진행
//var gVERSION ="TV_DEFENCE_20150704"; //버전명

var gEnableKey = 1; // key입력을 받아라 : 1, 받지마라 : 0

var gKeyPressTime = 100;// btn이 눌려져 있는 시간: 300미리 세컨드
var gKeyUpTime = 50;	//btn이 눌려 졌다가 올라오는 시간 200미리 세컨드
var gKeyScale = 1.05;	// btn이 눌려질때 얼마나 확대 할 것인가.

var SCREEN_WIDTH = 1280;
var SCREEN_HEIGHT = 720;

/* //define.js로 이동
//global변수의 선언
var g =
{
	blink :
		{
			//변수
			value:0,	// focus의 깜빡임을 나타낼 변수  0 --> opacity:0, 1--> opacity :1
			scene:null,	// blink를 호출한 scenario, 이변수를 기반으로 blink를 종료 한다.
			timer:null,

			//상수
			SHOW_TIMER:	700,	//blink관련 보여지는 시간
			HIDE_TIMER:	300	//blink관련 안보이게 하는 시간
		},
	REWARD_TIME_MS : 12 * 60 * 60 * 1000, //보상시간정의 12시간임.

	STAR : [ //별들에 대한 캐릭터 번호 정의 -- 진화에 대한 표식 이며, 스테이지 클리어시 보상기준이 된다.
			[], //empty
			[0,1, 2, 3, 4,25,31,37,0], //1성
			[0,5,10,15,20,26,32,38,43],//2성
			[0,6,11,16,21,27,33,39,44],//3성
			[0,7,12,17,22,28,34,40,45],//4성
			[0,8,13,18,23,29,35,41,46],//5성
			[0,9,14,19,24,30,36,42,47],//6성
			[0,0,0,0,0,0,0,0,48],	   //7성
		],

	//ywlee_20160526
	MONTH_MAX_PAYMENT : 500000, //월결제 한도 50만원 --> 구매한도 수정시, MS_popup_txt1를 검색하여 함께 수정 해 줘야 함.

	METOR_POWER : 500,		//metor 공격 당했을 경우 damage정도
	tutorial_mode : 0,		//0 -> normal mode, tutorial mode
	flag_over1time : 0,		//게임시작하고 1시간이 지나면 이 flag가 1이 된다.

	flag_pay_once: 0, // 1번이라도 결제 성공 하면 pay_once의 값이 1로 된다.

	//사용자 보상관련 get_reward.php를 호출해서 값이 setting됨.
	REWARD :
	{
		status : 0,		//0-->초기값,  1-->보상받을게 있다. 2---> 보상지불완료했다., 3---> 보상받을게 없다.
		why : "",		//보상사유 (PvP대전 보상)
		what: "",		//보상내용 (예: RUBY, GOLD, CHAR)
		what_value:0	//보상숫자
	},

	timestamp_flag: 0, //서버에 timestamp요청할때 0으로 하고 요청하고, 요청완료되면 1로 바뀜.
	timestamp_start: 0, //실제 서버에서 받아온 timestamp값을 기록한다. timestamp_flag가0일때는 의미없는 data임. --> 게임 시작시 최초 1회만 불려짐
	timestamp_due: 0  //게임시작부터 흐른시간 1초에 한번씩 증가 된다.
}
*/

// entrix를 위한 global변수 선언, 하지만 KT에도 사용함.
var gEntrix =
{
	host_id: "BKT00000001",//"test_host_id",  // SAID for KT, 11 length. ex)TT151222132
	cont_id: "", //  가입자
	SOCode: 1, //  SO Code
	user_name: "이름없음",
	user_phone: "053-000-0000",
	user_address: "대구시 동구 동대구로 489",
	zipcode: "",
	dp_id: "1075872",
	svc_id: "SV10000589",
	appl_id: "SV10000590",
	ch_no: "765",
	item_id: ["IC10000109", "IC10000110", "IC10000111", "IC10000112", "IC10000113"],
	service_center: "000-0000-0000", //고객 센터 번호

	pin_number: "0000",	// KT 구매 PIN
	is_model: true,		// 지원하는 KT 단말기

	return_code: 0, //
	pw_check_result: 0, // 0 --> 결과 대기중  1 ---> 결제성공, 2 --> 결제 오류(비밀번호 틀림), 3 --> 결제오류 ( 가입, 결제 제한)
	menu_key_pressed: false,	// true --> 메뉴키 누름    false -->  종료키 누름

	kt_model_name: "OTV-SMT-E5015"//"OTV-SMT-E5015" //KT셋탑일경우 모델명확인,'OTV-SMT-E5015'/'IC1000'''IC1100'  --- util_KT.js파일에서 셋팅됨

}


//========================================================
//
//				게임 진행에 필요한 global 변수들
//
//========================================================

//아직은 때가 아닌가 보다.
